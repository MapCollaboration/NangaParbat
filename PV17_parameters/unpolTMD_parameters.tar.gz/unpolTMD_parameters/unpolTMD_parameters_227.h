   double precision :: N1d= 0.16037E+00
   double precision :: N1u= 0.16037E+00
   double precision :: N1s= 0.16037E+00
   double precision :: al= 0.26890E+01
   double precision :: si= 0.14157E+00
   double precision :: N3fv= 0.89231E+00
   double precision :: N3unfv= 0.89231E+00
   double precision :: N3Ks= 0.89231E+00
   double precision :: N3Ku= 0.89231E+00
   double precision :: be= 0.23266E+01
   double precision :: ga= 0.26593E+01
   double precision :: de= 0.63105E-01
   double precision :: g2= 0.13776E+00
   double precision :: lamF= 0.43851E+01
   double precision :: N4= 0.14897E+00
   double precision :: lam= 0.64702E+01

!  replica 227 (flav_dep 1)