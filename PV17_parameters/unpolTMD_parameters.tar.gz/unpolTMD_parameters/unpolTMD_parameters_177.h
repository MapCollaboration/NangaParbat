   double precision :: N1d= 0.29084E+00
   double precision :: N1u= 0.29084E+00
   double precision :: N1s= 0.29084E+00
   double precision :: al= 0.29990E+01
   double precision :: si= 0.16938E+00
   double precision :: N3fv= 0.81720E+00
   double precision :: N3unfv= 0.81720E+00
   double precision :: N3Ks= 0.81720E+00
   double precision :: N3Ku= 0.81720E+00
   double precision :: be= 0.21424E+01
   double precision :: ga= 0.28562E+01
   double precision :: de= 0.62373E-01
   double precision :: g2= 0.12930E+00
   double precision :: lamF= 0.46472E+01
   double precision :: N4= 0.13369E+00
   double precision :: lam= 0.41353E+00

!  replica 177 (flav_dep 1)