   double precision :: N1d= 0.22000E+00
   double precision :: N1u= 0.22000E+00
   double precision :: N1s= 0.22000E+00
   double precision :: al= 0.29698E+01
   double precision :: si= 0.14855E+00
   double precision :: N3fv= 0.85903E+00
   double precision :: N3unfv= 0.85903E+00
   double precision :: N3Ks= 0.85903E+00
   double precision :: N3Ku= 0.85903E+00
   double precision :: be= 0.15085E+01
   double precision :: ga= 0.19672E+01
   double precision :: de= 0.16610E+00
   double precision :: g2= 0.12562E+00
   double precision :: lamF= 0.49786E+01
   double precision :: N4= 0.13574E+00
   double precision :: lam= 0.20374E+01

!  replica 210 (flav_dep 1)