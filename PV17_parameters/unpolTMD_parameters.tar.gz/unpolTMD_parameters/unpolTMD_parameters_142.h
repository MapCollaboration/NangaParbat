   double precision :: N1d= 0.22884E+00
   double precision :: N1u= 0.22884E+00
   double precision :: N1s= 0.22884E+00
   double precision :: al= 0.23455E+01
   double precision :: si= 0.17738E+00
   double precision :: N3fv= 0.96876E+00
   double precision :: N3unfv= 0.96876E+00
   double precision :: N3Ks= 0.96876E+00
   double precision :: N3Ku= 0.96876E+00
   double precision :: be= 0.24312E+01
   double precision :: ga= 0.23307E+01
   double precision :: de= 0.81658E-01
   double precision :: g2= 0.12346E+00
   double precision :: lamF= 0.48527E+01
   double precision :: N4= 0.14949E+00
   double precision :: lam= 0.17115E+00

!  replica 142 (flav_dep 1)