   double precision :: N1d= 0.19068E+00
   double precision :: N1u= 0.19068E+00
   double precision :: N1s= 0.19068E+00
   double precision :: al= 0.28425E+01
   double precision :: si= 0.16526E+00
   double precision :: N3fv= 0.85932E+00
   double precision :: N3unfv= 0.85932E+00
   double precision :: N3Ks= 0.85932E+00
   double precision :: N3Ku= 0.85932E+00
   double precision :: be= 0.89083E+00
   double precision :: ga= 0.16350E+01
   double precision :: de= 0.15123E+00
   double precision :: g2= 0.12939E+00
   double precision :: lamF= 0.48199E+01
   double precision :: N4= 0.13836E+00
   double precision :: lam= 0.43355E+01

!  replica 284 (flav_dep 1)