   double precision :: N1d= 0.29109E+00
   double precision :: N1u= 0.29109E+00
   double precision :: N1s= 0.29109E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.22367E+00
   double precision :: N3fv= 0.85525E+00
   double precision :: N3unfv= 0.85525E+00
   double precision :: N3Ks= 0.85525E+00
   double precision :: N3Ku= 0.85525E+00
   double precision :: be= 0.54841E+00
   double precision :: ga= 0.14199E+01
   double precision :: de= 0.24965E-01
   double precision :: g2= 0.12429E+00
   double precision :: lamF= 0.46390E+01
   double precision :: N4= 0.13688E+00
   double precision :: lam= 0.11611E+00

!  replica 153 (flav_dep 1)