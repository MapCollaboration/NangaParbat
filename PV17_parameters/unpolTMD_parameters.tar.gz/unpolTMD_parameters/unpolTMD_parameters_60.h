   double precision :: N1d= 0.24572E+00
   double precision :: N1u= 0.24572E+00
   double precision :: N1s= 0.24572E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.18807E+00
   double precision :: N3fv= 0.82448E+00
   double precision :: N3unfv= 0.82448E+00
   double precision :: N3Ks= 0.82448E+00
   double precision :: N3Ku= 0.82448E+00
   double precision :: be= 0.25395E+01
   double precision :: ga= 0.31951E+01
   double precision :: de= 0.51860E-01
   double precision :: g2= 0.13221E+00
   double precision :: lamF= 0.56781E+01
   double precision :: N4= 0.13073E+00
   double precision :: lam= 0.20236E+01

!  replica 60 (flav_dep 1)