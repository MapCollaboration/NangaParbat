   double precision :: N1d= 0.32156E+00
   double precision :: N1u= 0.32156E+00
   double precision :: N1s= 0.32156E+00
   double precision :: al= 0.29238E+01
   double precision :: si= 0.17800E+00
   double precision :: N3fv= 1.99423E-01
   double precision :: N3unfv= 1.99423E-01
   double precision :: N3Ks= 1.99423E-01
   double precision :: N3Ku= 1.99423E-01
   double precision :: be= 0.18249E+01
   double precision :: ga= 0.25350E+01
   double precision :: de= 0.10246E+00
   double precision :: g2= 0.12456E+00
   double precision :: lamF= 0.51395E+01
   double precision :: N4= 3.17775E-02
   double precision :: lam= 0.27300E+00

!  replica 287 (flav_dep 1)