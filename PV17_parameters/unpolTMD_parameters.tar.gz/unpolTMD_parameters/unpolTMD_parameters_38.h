   double precision :: N1d= 0.35859E+00
   double precision :: N1u= 0.35859E+00
   double precision :: N1s= 0.35859E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.14722E+00
   double precision :: N3fv= 1.95148E-01
   double precision :: N3unfv= 1.95148E-01
   double precision :: N3Ks= 1.95148E-01
   double precision :: N3Ku= 1.95148E-01
   double precision :: be= 0.10373E+01
   double precision :: ga= 0.20449E+01
   double precision :: de= 0.25627E+00
   double precision :: g2= 0.13110E+00
   double precision :: lamF= 0.77584E+01
   double precision :: N4= 2.81375E-02
   double precision :: lam= 0.20000E-01

!  replica 38 (flav_dep 1)