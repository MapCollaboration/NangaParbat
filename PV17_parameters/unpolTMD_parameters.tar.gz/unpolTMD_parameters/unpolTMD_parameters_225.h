   double precision :: N1d= 0.16200E+00
   double precision :: N1u= 0.16200E+00
   double precision :: N1s= 0.16200E+00
   double precision :: al= 0.29935E+01
   double precision :: si= 0.16865E+00
   double precision :: N3fv= 0.95483E+00
   double precision :: N3unfv= 0.95483E+00
   double precision :: N3Ks= 0.95483E+00
   double precision :: N3Ku= 0.95483E+00
   double precision :: be= 0.13770E+01
   double precision :: ga= 0.14886E+01
   double precision :: de= 0.24711E+00
   double precision :: g2= 0.13124E+00
   double precision :: lamF= 0.48292E+01
   double precision :: N4= 0.15113E+00
   double precision :: lam= 0.24159E+01

!  replica 225 (flav_dep 1)