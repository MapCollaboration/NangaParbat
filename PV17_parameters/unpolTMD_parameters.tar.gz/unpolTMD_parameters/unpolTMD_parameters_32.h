   double precision :: N1d= 0.43183E+00
   double precision :: N1u= 0.43183E+00
   double precision :: N1s= 0.43183E+00
   double precision :: al= 0.29392E+01
   double precision :: si= 0.15675E+00
   double precision :: N3fv= 0.64562E+00
   double precision :: N3unfv= 0.64562E+00
   double precision :: N3Ks= 0.64562E+00
   double precision :: N3Ku= 0.64562E+00
   double precision :: be= 0.19702E+01
   double precision :: ga= 0.48439E+01
   double precision :: de= 0.19600E-01
   double precision :: g2= 0.12450E+00
   double precision :: lamF= 0.13618E+02
   double precision :: N4= 0.88135E-01
   double precision :: lam= 0.44710E+00

!  replica 32 (flav_dep 1)