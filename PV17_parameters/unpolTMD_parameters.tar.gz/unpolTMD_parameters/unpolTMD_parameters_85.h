   double precision :: N1d= 0.20620E+00
   double precision :: N1u= 0.20620E+00
   double precision :: N1s= 0.20620E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.18331E+00
   double precision :: N3fv= 0.89117E+00
   double precision :: N3unfv= 0.89117E+00
   double precision :: N3Ks= 0.89117E+00
   double precision :: N3Ku= 0.89117E+00
   double precision :: be= 0.10686E+01
   double precision :: ga= 0.15224E+01
   double precision :: de= 0.31189E+00
   double precision :: g2= 0.13200E+00
   double precision :: lamF= 0.55199E+01
   double precision :: N4= 0.13719E+00
   double precision :: lam= 0.18376E+01

!  replica 85 (flav_dep 1)