   double precision :: N1d= 0.39196E+00
   double precision :: N1u= 0.39196E+00
   double precision :: N1s= 0.39196E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.18259E+00
   double precision :: N3fv= 1.90330E-01
   double precision :: N3unfv= 1.90330E-01
   double precision :: N3Ks= 1.90330E-01
   double precision :: N3Ku= 1.90330E-01
   double precision :: be= 0.16663E+01
   double precision :: ga= 0.25213E+01
   double precision :: de= 0.12826E+00
   double precision :: g2= 0.12614E+00
   double precision :: lamF= 0.60395E+01
   double precision :: N4= 3.02125E-02
   double precision :: lam= 0.24530E-01

!  replica 183 (flav_dep 1)