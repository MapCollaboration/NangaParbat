   double precision :: N1d= 0.34911E+00
   double precision :: N1u= 0.34911E+00
   double precision :: N1s= 0.34911E+00
   double precision :: al= 0.29230E+01
   double precision :: si= 0.19619E+00
   double precision :: N3fv= 2.04272E-01
   double precision :: N3unfv= 2.04272E-01
   double precision :: N3Ks= 2.04272E-01
   double precision :: N3Ku= 2.04272E-01
   double precision :: be= 0.94696E+00
   double precision :: ga= 0.19408E+01
   double precision :: de= 0.12576E+00
   double precision :: g2= 0.12032E+00
   double precision :: lamF= 0.58818E+01
   double precision :: N4= 3.17450E-02
   double precision :: lam= 0.10674E+00

!  replica 59 (flav_dep 1)