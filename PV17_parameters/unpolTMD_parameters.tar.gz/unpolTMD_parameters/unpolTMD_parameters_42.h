   double precision :: N1d= 0.25456E+00
   double precision :: N1u= 0.25456E+00
   double precision :: N1s= 0.25456E+00
   double precision :: al= 0.29935E+01
   double precision :: si= 0.14978E+00
   double precision :: N3fv= 1.99095E-01
   double precision :: N3unfv= 1.99095E-01
   double precision :: N3Ks= 1.99095E-01
   double precision :: N3Ku= 1.99095E-01
   double precision :: be= 0.16410E+01
   double precision :: ga= 0.22600E+01
   double precision :: de= 0.94164E-01
   double precision :: g2= 0.14962E+00
   double precision :: lamF= 0.33362E+01
   double precision :: N4= 3.41725E-02
   double precision :: lam= 0.18035E+00

!  replica 42 (flav_dep 1)