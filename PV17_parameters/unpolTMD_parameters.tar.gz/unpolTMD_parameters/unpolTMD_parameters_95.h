   double precision :: N1d= 0.24386E+00
   double precision :: N1u= 0.24386E+00
   double precision :: N1s= 0.24386E+00
   double precision :: al= 0.29710E+01
   double precision :: si= 0.10991E+00
   double precision :: N3fv= 2.25460E-01
   double precision :: N3unfv= 2.25460E-01
   double precision :: N3Ks= 2.25460E-01
   double precision :: N3Ku= 2.25460E-01
   double precision :: be= 0.15629E+01
   double precision :: ga= 0.19587E+01
   double precision :: de= 0.17311E+00
   double precision :: g2= 0.13548E+00
   double precision :: lamF= 0.56671E+01
   double precision :: N4= 3.55875E-02
   double precision :: lam= 0.41710E-01

!  replica 95 (flav_dep 1)