   double precision :: N1d= 0.25714E+00
   double precision :: N1u= 0.25714E+00
   double precision :: N1s= 0.25714E+00
   double precision :: al= 0.29989E+01
   double precision :: si= 0.15241E+00
   double precision :: N3fv= 0.87371E+00
   double precision :: N3unfv= 0.87371E+00
   double precision :: N3Ks= 0.87371E+00
   double precision :: N3Ku= 0.87371E+00
   double precision :: be= 0.15722E+01
   double precision :: ga= 0.20754E+01
   double precision :: de= 0.17152E+00
   double precision :: g2= 0.12245E+00
   double precision :: lamF= 0.58513E+01
   double precision :: N4= 0.13639E+00
   double precision :: lam= 0.79265E+00

!  replica 77 (flav_dep 1)