   double precision :: N1d= 0.22191E+00
   double precision :: N1u= 0.22191E+00
   double precision :: N1s= 0.22191E+00
   double precision :: al= 0.29953E+01
   double precision :: si= 0.19602E+00
   double precision :: N3fv= 2.33767E-01
   double precision :: N3unfv= 2.33767E-01
   double precision :: N3Ks= 2.33767E-01
   double precision :: N3Ku= 2.33767E-01
   double precision :: be= 0.19873E+01
   double precision :: ga= 0.19766E+01
   double precision :: de= 0.16547E+00
   double precision :: g2= 0.11891E+00
   double precision :: lamF= 0.58632E+01
   double precision :: N4= 3.50775E-02
   double precision :: lam= 0.15418E+01

!  replica 124 (flav_dep 1)