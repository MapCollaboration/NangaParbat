   double precision :: N1d= 0.28866E+00
   double precision :: N1u= 0.28866E+00
   double precision :: N1s= 0.28866E+00
   double precision :: al= 0.29596E+01
   double precision :: si= 0.19098E+00
   double precision :: N3fv= 2.14920E-01
   double precision :: N3unfv= 2.14920E-01
   double precision :: N3Ks= 2.14920E-01
   double precision :: N3Ku= 2.14920E-01
   double precision :: be= 0.61448E+00
   double precision :: ga= 0.13531E+01
   double precision :: de= 0.23904E+00
   double precision :: g2= 0.12460E+00
   double precision :: lamF= 0.57413E+01
   double precision :: N4= 3.23775E-02
   double precision :: lam= 0.19248E+00

!  replica 192 (flav_dep 1)