   double precision :: N1d= 0.28227E+00
   double precision :: N1u= 0.28227E+00
   double precision :: N1s= 0.28227E+00
   double precision :: al= 0.29951E+01
   double precision :: si= 0.15503E+00
   double precision :: N3fv= 2.05900E-01
   double precision :: N3unfv= 2.05900E-01
   double precision :: N3Ks= 2.05900E-01
   double precision :: N3Ku= 2.05900E-01
   double precision :: be= 0.12943E+01
   double precision :: ga= 0.22276E+01
   double precision :: de= 0.96662E-01
   double precision :: g2= 0.12946E+00
   double precision :: lamF= 0.52025E+01
   double precision :: N4= 3.26350E-02
   double precision :: lam= 0.39798E+00

!  replica 86 (flav_dep 1)