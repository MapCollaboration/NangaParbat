   double precision :: N1d= 0.25145E+00
   double precision :: N1u= 0.25145E+00
   double precision :: N1s= 0.25145E+00
   double precision :: al= 0.23241E+01
   double precision :: si= 0.72931E-01
   double precision :: N3fv= 2.09847E-01
   double precision :: N3unfv= 2.09847E-01
   double precision :: N3Ks= 2.09847E-01
   double precision :: N3Ku= 2.09847E-01
   double precision :: be= 0.17585E+01
   double precision :: ga= 0.22328E+01
   double precision :: de= 0.11208E+00
   double precision :: g2= 0.13971E+00
   double precision :: lamF= 0.43718E+01
   double precision :: N4= 3.46225E-02
   double precision :: lam= 0.13955E+00

!  replica 54 (flav_dep 1)