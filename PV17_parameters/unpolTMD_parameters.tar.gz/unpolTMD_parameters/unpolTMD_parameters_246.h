   double precision :: N1d= 0.19049E+00
   double precision :: N1u= 0.19049E+00
   double precision :: N1s= 0.19049E+00
   double precision :: al= 0.29987E+01
   double precision :: si= 0.19356E+00
   double precision :: N3fv= 0.92442E+00
   double precision :: N3unfv= 0.92442E+00
   double precision :: N3Ks= 0.92442E+00
   double precision :: N3Ku= 0.92442E+00
   double precision :: be= 0.19398E+01
   double precision :: ga= 0.22913E+01
   double precision :: de= 0.85942E-01
   double precision :: g2= 0.12091E+00
   double precision :: lamF= 0.42564E+01
   double precision :: N4= 0.14861E+00
   double precision :: lam= 0.36145E+01

!  replica 246 (flav_dep 1)