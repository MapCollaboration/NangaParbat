   double precision :: N1d= 0.30183E+00
   double precision :: N1u= 0.30183E+00
   double precision :: N1s= 0.30183E+00
   double precision :: al= 0.29968E+01
   double precision :: si= 0.15449E+00
   double precision :: N3fv= 2.08075E-01
   double precision :: N3unfv= 2.08075E-01
   double precision :: N3Ks= 2.08075E-01
   double precision :: N3Ku= 2.08075E-01
   double precision :: be= 0.20714E+01
   double precision :: ga= 0.27542E+01
   double precision :: de= 0.72582E-01
   double precision :: g2= 0.12360E+00
   double precision :: lamF= 0.50220E+01
   double precision :: N4= 3.32325E-02
   double precision :: lam= 0.30294E+00

!  replica 11 (flav_dep 1)