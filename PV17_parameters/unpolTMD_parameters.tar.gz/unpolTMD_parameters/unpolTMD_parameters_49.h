   double precision :: N1d= 0.22589E+00
   double precision :: N1u= 0.22589E+00
   double precision :: N1s= 0.22589E+00
   double precision :: al= 0.29808E+01
   double precision :: si= 0.17700E+00
   double precision :: N3fv= 0.86149E+00
   double precision :: N3unfv= 0.86149E+00
   double precision :: N3Ks= 0.86149E+00
   double precision :: N3Ku= 0.86149E+00
   double precision :: be= 0.18487E+01
   double precision :: ga= 0.22170E+01
   double precision :: de= 0.12267E+00
   double precision :: g2= 0.12728E+00
   double precision :: lamF= 0.47687E+01
   double precision :: N4= 0.13981E+00
   double precision :: lam= 0.22117E+01

!  replica 49 (flav_dep 1)