   double precision :: N1d= 0.39858E+00
   double precision :: N1u= 0.39858E+00
   double precision :: N1s= 0.39858E+00
   double precision :: al= 0.17394E+01
   double precision :: si= 0.88773E-01
   double precision :: N3fv= 0.66315E+00
   double precision :: N3unfv= 0.66315E+00
   double precision :: N3Ks= 0.66315E+00
   double precision :: N3Ku= 0.66315E+00
   double precision :: be= 0.21268E+01
   double precision :: ga= 0.38467E+01
   double precision :: de= 0.45030E-01
   double precision :: g2= 0.13086E+00
   double precision :: lamF= 0.74232E+01
   double precision :: N4= 0.10254E+00
   double precision :: lam= 0.31124E+00

!  replica 158 (flav_dep 1)