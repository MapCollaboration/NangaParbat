   double precision :: N1d= 0.39858E+00
   double precision :: N1u= 0.39858E+00
   double precision :: N1s= 0.39858E+00
   double precision :: al= 0.17394E+01
   double precision :: si= 0.88773E-01
   double precision :: N3fv= 1.65788E-01
   double precision :: N3unfv= 1.65788E-01
   double precision :: N3Ks= 1.65788E-01
   double precision :: N3Ku= 1.65788E-01
   double precision :: be= 0.21268E+01
   double precision :: ga= 0.38467E+01
   double precision :: de= 0.45030E-01
   double precision :: g2= 0.13086E+00
   double precision :: lamF= 0.74232E+01
   double precision :: N4= 2.56350E-02
   double precision :: lam= 0.31124E+00

!  replica 158 (flav_dep 1)