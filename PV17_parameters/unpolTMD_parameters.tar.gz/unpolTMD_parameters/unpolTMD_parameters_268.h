   double precision :: N1d= 0.24965E+00
   double precision :: N1u= 0.24965E+00
   double precision :: N1s= 0.24965E+00
   double precision :: al= 0.29994E+01
   double precision :: si= 0.12675E+00
   double precision :: N3fv= 0.90787E+00
   double precision :: N3unfv= 0.90787E+00
   double precision :: N3Ks= 0.90787E+00
   double precision :: N3Ku= 0.90787E+00
   double precision :: be= 0.17652E+01
   double precision :: ga= 0.22229E+01
   double precision :: de= 0.10089E+00
   double precision :: g2= 0.12444E+00
   double precision :: lamF= 0.48532E+01
   double precision :: N4= 0.14551E+00
   double precision :: lam= 0.28291E+00

!  replica 268 (flav_dep 1)