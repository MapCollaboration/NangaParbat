   double precision :: N1d= 0.24965E+00
   double precision :: N1u= 0.24965E+00
   double precision :: N1s= 0.24965E+00
   double precision :: al= 0.29994E+01
   double precision :: si= 0.12675E+00
   double precision :: N3fv= 2.26967E-01
   double precision :: N3unfv= 2.26967E-01
   double precision :: N3Ks= 2.26967E-01
   double precision :: N3Ku= 2.26967E-01
   double precision :: be= 0.17652E+01
   double precision :: ga= 0.22229E+01
   double precision :: de= 0.10089E+00
   double precision :: g2= 0.12444E+00
   double precision :: lamF= 0.48532E+01
   double precision :: N4= 3.63775E-02
   double precision :: lam= 0.28291E+00

!  replica 268 (flav_dep 1)