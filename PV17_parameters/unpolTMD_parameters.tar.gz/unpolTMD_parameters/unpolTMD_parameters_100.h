   double precision :: N1d= 0.31492E+00
   double precision :: N1u= 0.31492E+00
   double precision :: N1s= 0.31492E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.97710E-01
   double precision :: N3fv= 1.97947E-01
   double precision :: N3unfv= 1.97947E-01
   double precision :: N3Ks= 1.97947E-01
   double precision :: N3Ku= 1.97947E-01
   double precision :: be= 0.66288E+00
   double precision :: ga= 0.18721E+01
   double precision :: de= 0.83333E-01
   double precision :: g2= 0.13550E+00
   double precision :: lamF= 0.66254E+01
   double precision :: N4= 2.99700E-02
   double precision :: lam= 0.70480E-01

!  replica 100 (flav_dep 1)