   double precision :: N1d= 0.31580E+00
   double precision :: N1u= 0.31580E+00
   double precision :: N1s= 0.31580E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14984E+00
   double precision :: N3fv= 2.05510E-01
   double precision :: N3unfv= 2.05510E-01
   double precision :: N3Ks= 2.05510E-01
   double precision :: N3Ku= 2.05510E-01
   double precision :: be= 0.11969E+01
   double precision :: ga= 0.20739E+01
   double precision :: de= 0.20502E+00
   double precision :: g2= 0.12756E+00
   double precision :: lamF= 0.69089E+01
   double precision :: N4= 3.14175E-02
   double precision :: lam= 0.22792E+00

!  replica 80 (flav_dep 1)