   double precision :: N1d= 0.23979E+00
   double precision :: N1u= 0.23979E+00
   double precision :: N1s= 0.23979E+00
   double precision :: al= 0.29967E+01
   double precision :: si= 0.15892E+00
   double precision :: N3fv= 0.88104E+00
   double precision :: N3unfv= 0.88104E+00
   double precision :: N3Ks= 0.88104E+00
   double precision :: N3Ku= 0.88104E+00
   double precision :: be= 0.14995E+01
   double precision :: ga= 0.18703E+01
   double precision :: de= 0.22353E+00
   double precision :: g2= 0.11966E+00
   double precision :: lamF= 0.60135E+01
   double precision :: N4= 0.13040E+00
   double precision :: lam= 0.15577E+01

!  replica 8 (flav_dep 1)