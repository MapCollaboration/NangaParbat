   double precision :: N1d= 0.27919E+00
   double precision :: N1u= 0.27919E+00
   double precision :: N1s= 0.27919E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.16517E+00
   double precision :: N3fv= 0.85005E+00
   double precision :: N3unfv= 0.85005E+00
   double precision :: N3Ks= 0.85005E+00
   double precision :: N3Ku= 0.85005E+00
   double precision :: be= 0.19771E+01
   double precision :: ga= 0.24357E+01
   double precision :: de= 0.82035E-01
   double precision :: g2= 0.13377E+00
   double precision :: lamF= 0.40481E+01
   double precision :: N4= 0.14166E+00
   double precision :: lam= 0.30339E-04

!  replica 115 (flav_dep 1)