   double precision :: N1d= 0.21930E+00
   double precision :: N1u= 0.21930E+00
   double precision :: N1s= 0.21930E+00
   double precision :: al= 0.29953E+01
   double precision :: si= 0.20193E+00
   double precision :: N3fv= 2.11250E-01
   double precision :: N3unfv= 2.11250E-01
   double precision :: N3Ks= 2.11250E-01
   double precision :: N3Ku= 2.11250E-01
   double precision :: be= 0.11251E+01
   double precision :: ga= 0.17707E+01
   double precision :: de= 0.13976E+00
   double precision :: g2= 0.12827E+00
   double precision :: lamF= 0.41063E+01
   double precision :: N4= 3.52275E-02
   double precision :: lam= 0.22550E+01

!  replica 110 (flav_dep 1)