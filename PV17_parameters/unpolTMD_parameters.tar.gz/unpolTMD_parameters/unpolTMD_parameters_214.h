   double precision :: N1d= 0.31193E+00
   double precision :: N1u= 0.31193E+00
   double precision :: N1s= 0.31193E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.16321E+00
   double precision :: N3fv= 1.83353E-01
   double precision :: N3unfv= 1.83353E-01
   double precision :: N3Ks= 1.83353E-01
   double precision :: N3Ku= 1.83353E-01
   double precision :: be= 0.12967E+01
   double precision :: ga= 0.24980E+01
   double precision :: de= 0.12211E+00
   double precision :: g2= 0.13581E+00
   double precision :: lamF= 0.60809E+01
   double precision :: N4= 2.88925E-02
   double precision :: lam= 0.73944E+00

!  replica 214 (flav_dep 1)