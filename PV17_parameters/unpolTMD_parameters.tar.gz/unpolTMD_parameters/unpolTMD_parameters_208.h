   double precision :: N1d= 0.28541E+00
   double precision :: N1u= 0.28541E+00
   double precision :: N1s= 0.28541E+00
   double precision :: al= 0.20353E+01
   double precision :: si= 0.15056E+00
   double precision :: N3fv= 2.10850E-01
   double precision :: N3unfv= 2.10850E-01
   double precision :: N3Ks= 2.10850E-01
   double precision :: N3Ku= 2.10850E-01
   double precision :: be= 0.19350E+01
   double precision :: ga= 0.21692E+01
   double precision :: de= 0.10860E+00
   double precision :: g2= 0.12179E+00
   double precision :: lamF= 0.33800E+01
   double precision :: N4= 3.56275E-02
   double precision :: lam= 0.27439E+00

!  replica 208 (flav_dep 1)