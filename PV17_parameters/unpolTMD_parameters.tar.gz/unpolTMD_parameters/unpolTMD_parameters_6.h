   double precision :: N1d= 0.30608E+00
   double precision :: N1u= 0.30608E+00
   double precision :: N1s= 0.30608E+00
   double precision :: al= 0.29089E+01
   double precision :: si= 0.13713E+00
   double precision :: N3fv= 0.84318E+00
   double precision :: N3unfv= 0.84318E+00
   double precision :: N3Ks= 0.84318E+00
   double precision :: N3Ku= 0.84318E+00
   double precision :: be= 0.92988E+00
   double precision :: ga= 0.18013E+01
   double precision :: de= 0.19499E+00
   double precision :: g2= 0.12656E+00
   double precision :: lamF= 0.65831E+01
   double precision :: N4= 0.12771E+00
   double precision :: lam= 0.13810E+00

!  replica 6 (flav_dep 1)