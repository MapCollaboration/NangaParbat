   double precision :: N1d= 0.35457E+00
   double precision :: N1u= 0.35457E+00
   double precision :: N1s= 0.35457E+00
   double precision :: al= 0.29908E+01
   double precision :: si= 0.16582E+00
   double precision :: N3fv= 1.99345E-01
   double precision :: N3unfv= 1.99345E-01
   double precision :: N3Ks= 1.99345E-01
   double precision :: N3Ku= 1.99345E-01
   double precision :: be= 0.19068E+01
   double precision :: ga= 0.28304E+01
   double precision :: de= 0.94776E-01
   double precision :: g2= 0.12860E+00
   double precision :: lamF= 0.66388E+01
   double precision :: N4= 3.06225E-02
   double precision :: lam= 0.68167E-01

!  replica 14 (flav_dep 1)