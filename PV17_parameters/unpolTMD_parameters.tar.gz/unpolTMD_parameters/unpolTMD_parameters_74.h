   double precision :: N1d= 0.18481E+00
   double precision :: N1u= 0.18481E+00
   double precision :: N1s= 0.18481E+00
   double precision :: al= 0.27703E+01
   double precision :: si= 0.12377E+00
   double precision :: N3fv= 2.07550E-01
   double precision :: N3unfv= 2.07550E-01
   double precision :: N3Ks= 2.07550E-01
   double precision :: N3Ku= 2.07550E-01
   double precision :: be= 0.10720E+01
   double precision :: ga= 0.19521E+01
   double precision :: de= 0.48897E-01
   double precision :: g2= 0.13020E+00
   double precision :: lamF= 0.35104E+01
   double precision :: N4= 3.61150E-02
   double precision :: lam= 0.46758E+01

!  replica 74 (flav_dep 1)