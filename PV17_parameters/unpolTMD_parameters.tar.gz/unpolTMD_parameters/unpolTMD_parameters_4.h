   double precision :: N1d= 0.29207E+00
   double precision :: N1u= 0.29207E+00
   double precision :: N1s= 0.29207E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.20938E+00
   double precision :: N3fv= 0.88479E+00
   double precision :: N3unfv= 0.88479E+00
   double precision :: N3Ks= 0.88479E+00
   double precision :: N3Ku= 0.88479E+00
   double precision :: be= 0.12813E+01
   double precision :: ga= 0.17696E+01
   double precision :: de= 0.19545E+00
   double precision :: g2= 0.12546E+00
   double precision :: lamF= 0.52660E+01
   double precision :: N4= 0.13858E+00
   double precision :: lam= 0.30312E-01

!  replica 4 (flav_dep 1)