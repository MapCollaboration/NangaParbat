   double precision :: N1d= 0.32237E+00
   double precision :: N1u= 0.32237E+00
   double precision :: N1s= 0.32237E+00
   double precision :: al= 0.29991E+01
   double precision :: si= 0.16761E+00
   double precision :: N3fv= 2.12407E-01
   double precision :: N3unfv= 2.12407E-01
   double precision :: N3Ks= 2.12407E-01
   double precision :: N3Ku= 2.12407E-01
   double precision :: be= 0.21548E+01
   double precision :: ga= 0.28034E+01
   double precision :: de= 0.70409E-01
   double precision :: g2= 0.12426E+00
   double precision :: lamF= 0.56171E+01
   double precision :: N4= 3.39600E-02
   double precision :: lam= 0.62876E-01

!  replica 103 (flav_dep 1)