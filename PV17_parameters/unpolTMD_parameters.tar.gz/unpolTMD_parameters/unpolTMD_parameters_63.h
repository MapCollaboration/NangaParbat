   double precision :: N1d= 0.19603E+00
   double precision :: N1u= 0.19603E+00
   double precision :: N1s= 0.19603E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.19551E+00
   double precision :: N3fv= 2.62150E-01
   double precision :: N3unfv= 2.62150E-01
   double precision :: N3Ks= 2.62150E-01
   double precision :: N3Ku= 2.62150E-01
   double precision :: be= 0.17533E+01
   double precision :: ga= 0.17552E+01
   double precision :: de= 0.13664E+00
   double precision :: g2= 0.12039E+00
   double precision :: lamF= 0.52759E+01
   double precision :: N4= 4.02025E-02
   double precision :: lam= 0.11905E+00

!  replica 63 (flav_dep 1)