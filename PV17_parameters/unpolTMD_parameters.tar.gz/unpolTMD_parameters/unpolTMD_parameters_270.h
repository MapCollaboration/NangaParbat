   double precision :: N1d= 0.26480E+00
   double precision :: N1u= 0.26480E+00
   double precision :: N1s= 0.26480E+00
   double precision :: al= 0.29993E+01
   double precision :: si= 0.14613E+00
   double precision :: N3fv= 0.91641E+00
   double precision :: N3unfv= 0.91641E+00
   double precision :: N3Ks= 0.91641E+00
   double precision :: N3Ku= 0.91641E+00
   double precision :: be= 0.12211E+01
   double precision :: ga= 0.14842E+01
   double precision :: de= 0.31855E+00
   double precision :: g2= 0.11803E+00
   double precision :: lamF= 0.53944E+01
   double precision :: N4= 0.14125E+00
   double precision :: lam= 0.70478E-01

!  replica 270 (flav_dep 1)