   double precision :: N1d= 0.25729E+00
   double precision :: N1u= 0.25729E+00
   double precision :: N1s= 0.25729E+00
   double precision :: al= 0.29934E+01
   double precision :: si= 0.17116E+00
   double precision :: N3fv= 0.88908E+00
   double precision :: N3unfv= 0.88908E+00
   double precision :: N3Ks= 0.88908E+00
   double precision :: N3Ku= 0.88908E+00
   double precision :: be= 0.17347E+01
   double precision :: ga= 0.21916E+01
   double precision :: de= 0.94544E-01
   double precision :: g2= 0.12796E+00
   double precision :: lamF= 0.41202E+01
   double precision :: N4= 0.14845E+00
   double precision :: lam= 0.22052E+00

!  replica 44 (flav_dep 1)