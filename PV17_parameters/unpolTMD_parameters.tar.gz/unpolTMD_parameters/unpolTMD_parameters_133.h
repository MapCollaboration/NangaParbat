   double precision :: N1d= 0.17684E+00
   double precision :: N1u= 0.17684E+00
   double precision :: N1s= 0.17684E+00
   double precision :: al= 0.28562E+01
   double precision :: si= 0.14275E+00
   double precision :: N3fv= 0.88265E+00
   double precision :: N3unfv= 0.88265E+00
   double precision :: N3Ks= 0.88265E+00
   double precision :: N3Ku= 0.88265E+00
   double precision :: be= 0.10215E+01
   double precision :: ga= 0.16748E+01
   double precision :: de= 0.17334E+00
   double precision :: g2= 0.13770E+00
   double precision :: lamF= 0.51052E+01
   double precision :: N4= 0.13807E+00
   double precision :: lam= 0.32941E+01

!  replica 133 (flav_dep 1)