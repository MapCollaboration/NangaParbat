   double precision :: N1d= 0.31764E+00
   double precision :: N1u= 0.31764E+00
   double precision :: N1s= 0.31764E+00
   double precision :: al= 0.29996E+01
   double precision :: si= 0.16911E+00
   double precision :: N3fv= 2.17083E-01
   double precision :: N3unfv= 2.17083E-01
   double precision :: N3Ks= 2.17083E-01
   double precision :: N3Ku= 2.17083E-01
   double precision :: be= 0.17203E+01
   double precision :: ga= 0.21811E+01
   double precision :: de= 0.17007E+00
   double precision :: g2= 0.11834E+00
   double precision :: lamF= 0.65991E+01
   double precision :: N4= 3.28875E-02
   double precision :: lam= 0.84552E-01

!  replica 47 (flav_dep 1)