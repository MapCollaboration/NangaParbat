   double precision :: N1d= 0.22523E+00
   double precision :: N1u= 0.22523E+00
   double precision :: N1s= 0.22523E+00
   double precision :: al= 0.29993E+01
   double precision :: si= 0.16383E+00
   double precision :: N3fv= 2.09588E-01
   double precision :: N3unfv= 2.09588E-01
   double precision :: N3Ks= 2.09588E-01
   double precision :: N3Ku= 2.09588E-01
   double precision :: be= 0.26051E+01
   double precision :: ga= 0.31973E+01
   double precision :: de= 0.38107E-01
   double precision :: g2= 0.13058E+00
   double precision :: lamF= 0.40347E+01
   double precision :: N4= 3.33150E-02
   double precision :: lam= 0.20641E+01

!  replica 220 (flav_dep 1)