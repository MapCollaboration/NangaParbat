   double precision :: N1d= 0.27373E+00
   double precision :: N1u= 0.27373E+00
   double precision :: N1s= 0.27373E+00
   double precision :: al= 0.29564E+01
   double precision :: si= 0.19921E+00
   double precision :: N3fv= 2.42578E-01
   double precision :: N3unfv= 2.42578E-01
   double precision :: N3Ks= 2.42578E-01
   double precision :: N3Ku= 2.42578E-01
   double precision :: be= 0.21405E+01
   double precision :: ga= 0.23490E+01
   double precision :: de= 0.10142E+00
   double precision :: g2= 0.11169E+00
   double precision :: lamF= 0.63510E+01
   double precision :: N4= 3.62250E-02
   double precision :: lam= 0.30842E+00

!  replica 23 (flav_dep 1)