   double precision :: N1d= 0.30679E+00
   double precision :: N1u= 0.30679E+00
   double precision :: N1s= 0.30679E+00
   double precision :: al= 0.26058E+01
   double precision :: si= 0.17036E+00
   double precision :: N3fv= 2.26603E-01
   double precision :: N3unfv= 2.26603E-01
   double precision :: N3Ks= 2.26603E-01
   double precision :: N3Ku= 2.26603E-01
   double precision :: be= 0.22019E+01
   double precision :: ga= 0.25000E+01
   double precision :: de= 0.10348E+00
   double precision :: g2= 0.12167E+00
   double precision :: lamF= 0.67093E+01
   double precision :: N4= 3.39150E-02
   double precision :: lam= 0.12268E+00

!  replica 166 (flav_dep 1)