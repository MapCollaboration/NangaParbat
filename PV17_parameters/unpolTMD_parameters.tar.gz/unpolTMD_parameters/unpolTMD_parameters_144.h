   double precision :: N1d= 0.36081E+00
   double precision :: N1u= 0.36081E+00
   double precision :: N1s= 0.36081E+00
   double precision :: al= 0.29185E+01
   double precision :: si= 0.19276E+00
   double precision :: N3fv= 1.90163E-01
   double precision :: N3unfv= 1.90163E-01
   double precision :: N3Ks= 1.90163E-01
   double precision :: N3Ku= 1.90163E-01
   double precision :: be= 0.17478E+01
   double precision :: ga= 0.22325E+01
   double precision :: de= 0.19243E+00
   double precision :: g2= 0.12100E+00
   double precision :: lamF= 0.55743E+01
   double precision :: N4= 2.96750E-02
   double precision :: lam= 0.39094E+00

!  replica 144 (flav_dep 1)