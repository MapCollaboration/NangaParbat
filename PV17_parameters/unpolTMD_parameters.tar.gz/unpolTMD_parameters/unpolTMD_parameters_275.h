   double precision :: N1d= 0.29413E+00
   double precision :: N1u= 0.29413E+00
   double precision :: N1s= 0.29413E+00
   double precision :: al= 0.18770E+01
   double precision :: si= 0.14593E+00
   double precision :: N3fv= 0.86793E+00
   double precision :: N3unfv= 0.86793E+00
   double precision :: N3Ks= 0.86793E+00
   double precision :: N3Ku= 0.86793E+00
   double precision :: be= 0.84588E+00
   double precision :: ga= 0.18407E+01
   double precision :: de= 0.36151E-01
   double precision :: g2= 0.11971E+00
   double precision :: lamF= 0.49829E+01
   double precision :: N4= 0.13881E+00
   double precision :: lam= 0.31597E+00

!  replica 275 (flav_dep 1)