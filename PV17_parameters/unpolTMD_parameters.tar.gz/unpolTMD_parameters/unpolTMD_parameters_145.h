   double precision :: N1d= 0.22306E+00
   double precision :: N1u= 0.22306E+00
   double precision :: N1s= 0.22306E+00
   double precision :: al= 0.29971E+01
   double precision :: si= 0.18576E+00
   double precision :: N3fv= 2.29433E-01
   double precision :: N3unfv= 2.29433E-01
   double precision :: N3Ks= 2.29433E-01
   double precision :: N3Ku= 2.29433E-01
   double precision :: be= 0.17138E+01
   double precision :: ga= 0.19001E+01
   double precision :: de= 0.12221E+00
   double precision :: g2= 0.12569E+00
   double precision :: lamF= 0.36691E+01
   double precision :: N4= 3.93400E-02
   double precision :: lam= 0.41349E+00

!  replica 145 (flav_dep 1)