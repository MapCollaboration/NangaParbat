   double precision :: N1d= 0.22306E+00
   double precision :: N1u= 0.22306E+00
   double precision :: N1s= 0.22306E+00
   double precision :: al= 0.29971E+01
   double precision :: si= 0.18576E+00
   double precision :: N3fv= 0.91773E+00
   double precision :: N3unfv= 0.91773E+00
   double precision :: N3Ks= 0.91773E+00
   double precision :: N3Ku= 0.91773E+00
   double precision :: be= 0.17138E+01
   double precision :: ga= 0.19001E+01
   double precision :: de= 0.12221E+00
   double precision :: g2= 0.12569E+00
   double precision :: lamF= 0.36691E+01
   double precision :: N4= 0.15736E+00
   double precision :: lam= 0.41349E+00

!  replica 145 (flav_dep 1)