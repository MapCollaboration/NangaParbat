   double precision :: N1d= 0.35300E+00
   double precision :: N1u= 0.35300E+00
   double precision :: N1s= 0.35300E+00
   double precision :: al= 0.29973E+01
   double precision :: si= 0.17172E+00
   double precision :: N3fv= 0.77314E+00
   double precision :: N3unfv= 0.77314E+00
   double precision :: N3Ks= 0.77314E+00
   double precision :: N3Ku= 0.77314E+00
   double precision :: be= 0.18816E+01
   double precision :: ga= 0.27918E+01
   double precision :: de= 0.77944E-01
   double precision :: g2= 0.12854E+00
   double precision :: lamF= 0.50898E+01
   double precision :: N4= 0.12541E+00
   double precision :: lam= 0.35317E-01

!  replica 207 (flav_dep 1)