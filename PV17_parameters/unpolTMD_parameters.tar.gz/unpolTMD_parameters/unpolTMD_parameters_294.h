   double precision :: N1d= 0.32110E+00
   double precision :: N1u= 0.32110E+00
   double precision :: N1s= 0.32110E+00
   double precision :: al= 0.29751E+01
   double precision :: si= 0.14316E+00
   double precision :: N3fv= 0.80043E+00
   double precision :: N3unfv= 0.80043E+00
   double precision :: N3Ks= 0.80043E+00
   double precision :: N3Ku= 0.80043E+00
   double precision :: be= 0.16109E+01
   double precision :: ga= 0.24493E+01
   double precision :: de= 0.13929E+00
   double precision :: g2= 0.12852E+00
   double precision :: lamF= 0.66157E+01
   double precision :: N4= 0.12164E+00
   double precision :: lam= 0.22819E+00

!  replica 294 (flav_dep 1)