   double precision :: N1d= 0.29491E+00
   double precision :: N1u= 0.29491E+00
   double precision :: N1s= 0.29491E+00
   double precision :: al= 0.17864E+01
   double precision :: si= 0.76857E-01
   double precision :: N3fv= 0.77160E+00
   double precision :: N3unfv= 0.77160E+00
   double precision :: N3Ks= 0.77160E+00
   double precision :: N3Ku= 0.77160E+00
   double precision :: be= 0.71085E+00
   double precision :: ga= 0.19335E+01
   double precision :: de= 0.16474E+00
   double precision :: g2= 0.12953E+00
   double precision :: lamF= 0.73351E+01
   double precision :: N4= 0.11303E+00
   double precision :: lam= 0.86189E+00

!  replica 117 (flav_dep 1)