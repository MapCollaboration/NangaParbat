   double precision :: N1d= 0.26134E+00
   double precision :: N1u= 0.26134E+00
   double precision :: N1s= 0.26134E+00
   double precision :: al= 0.26528E+01
   double precision :: si= 0.12212E+00
   double precision :: N3fv= 0.80919E+00
   double precision :: N3unfv= 0.80919E+00
   double precision :: N3Ks= 0.80919E+00
   double precision :: N3Ku= 0.80919E+00
   double precision :: be= 0.19909E+01
   double precision :: ga= 0.27119E+01
   double precision :: de= 0.95043E-01
   double precision :: g2= 0.13306E+00
   double precision :: lamF= 0.61040E+01
   double precision :: N4= 0.12418E+00
   double precision :: lam= 0.12107E+01

!  replica 281 (flav_dep 1)