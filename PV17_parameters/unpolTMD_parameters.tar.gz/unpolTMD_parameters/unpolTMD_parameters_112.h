   double precision :: N1d= 0.24153E+00
   double precision :: N1u= 0.24153E+00
   double precision :: N1s= 0.24153E+00
   double precision :: al= 0.29995E+01
   double precision :: si= 0.14324E+00
   double precision :: N3fv= 2.22575E-01
   double precision :: N3unfv= 2.22575E-01
   double precision :: N3Ks= 2.22575E-01
   double precision :: N3Ku= 2.22575E-01
   double precision :: be= 0.17780E+01
   double precision :: ga= 0.21979E+01
   double precision :: de= 0.11699E+00
   double precision :: g2= 0.13347E+00
   double precision :: lamF= 0.49989E+01
   double precision :: N4= 3.62775E-02
   double precision :: lam= 0.38405E+00

!  replica 112 (flav_dep 1)