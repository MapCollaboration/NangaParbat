   double precision :: N1d= 0.27805E+00
   double precision :: N1u= 0.27805E+00
   double precision :: N1s= 0.27805E+00
   double precision :: al= 0.29993E+01
   double precision :: si= 0.16928E+00
   double precision :: N3fv= 1.99670E-01
   double precision :: N3unfv= 1.99670E-01
   double precision :: N3Ks= 1.99670E-01
   double precision :: N3Ku= 1.99670E-01
   double precision :: be= 0.16624E+01
   double precision :: ga= 0.24634E+01
   double precision :: de= 0.11856E+00
   double precision :: g2= 0.13176E+00
   double precision :: lamF= 0.58774E+01
   double precision :: N4= 3.07225E-02
   double precision :: lam= 0.91054E+00

!  replica 143 (flav_dep 1)