   double precision :: N1d= 0.24821E+00
   double precision :: N1u= 0.24821E+00
   double precision :: N1s= 0.24821E+00
   double precision :: al= 0.28146E+01
   double precision :: si= 0.14141E+00
   double precision :: N3fv= 2.23548E-01
   double precision :: N3unfv= 2.23548E-01
   double precision :: N3Ks= 2.23548E-01
   double precision :: N3Ku= 2.23548E-01
   double precision :: be= 0.23015E+01
   double precision :: ga= 0.26118E+01
   double precision :: de= 0.76484E-01
   double precision :: g2= 0.12467E+00
   double precision :: lamF= 0.52755E+01
   double precision :: N4= 3.53325E-02
   double precision :: lam= 0.69506E+00

!  replica 41 (flav_dep 1)