   double precision :: N1d= 0.34968E+00
   double precision :: N1u= 0.34968E+00
   double precision :: N1s= 0.34968E+00
   double precision :: al= 0.29913E+01
   double precision :: si= 0.17741E+00
   double precision :: N3fv= 1.99148E-01
   double precision :: N3unfv= 1.99148E-01
   double precision :: N3Ks= 1.99148E-01
   double precision :: N3Ku= 1.99148E-01
   double precision :: be= 0.11552E+01
   double precision :: ga= 0.22233E+01
   double precision :: de= 0.17994E+00
   double precision :: g2= 0.12176E+00
   double precision :: lamF= 0.72870E+01
   double precision :: N4= 3.00175E-02
   double precision :: lam= 0.37000E+00

!  replica 114 (flav_dep 1)