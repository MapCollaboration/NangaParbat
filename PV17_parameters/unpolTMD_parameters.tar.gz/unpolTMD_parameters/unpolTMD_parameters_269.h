   double precision :: N1d= 0.27242E+00
   double precision :: N1u= 0.27242E+00
   double precision :: N1s= 0.27242E+00
   double precision :: al= 0.29988E+01
   double precision :: si= 0.22716E+00
   double precision :: N3fv= 2.39852E-01
   double precision :: N3unfv= 2.39852E-01
   double precision :: N3Ks= 2.39852E-01
   double precision :: N3Ku= 2.39852E-01
   double precision :: be= 0.22285E+01
   double precision :: ga= 0.23127E+01
   double precision :: de= 0.98063E-01
   double precision :: g2= 0.12128E+00
   double precision :: lamF= 0.56969E+01
   double precision :: N4= 3.65875E-02
   double precision :: lam= 0.47278E-02

!  replica 269 (flav_dep 1)