   double precision :: N1d= 0.35640E+00
   double precision :: N1u= 0.35640E+00
   double precision :: N1s= 0.35640E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.17641E+00
   double precision :: N3fv= 1.87380E-01
   double precision :: N3unfv= 1.87380E-01
   double precision :: N3Ks= 1.87380E-01
   double precision :: N3Ku= 1.87380E-01
   double precision :: be= 0.22465E+01
   double precision :: ga= 0.34026E+01
   double precision :: de= 0.60375E-01
   double precision :: g2= 0.12373E+00
   double precision :: lamF= 0.72706E+01
   double precision :: N4= 2.81800E-02
   double precision :: lam= 0.49679E+00

!  replica 233 (flav_dep 1)