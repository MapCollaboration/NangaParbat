   double precision :: N1d= 0.22226E+00
   double precision :: N1u= 0.22226E+00
   double precision :: N1s= 0.22226E+00
   double precision :: al= 0.29968E+01
   double precision :: si= 0.15421E+00
   double precision :: N3fv= 0.92329E+00
   double precision :: N3unfv= 0.92329E+00
   double precision :: N3Ks= 0.92329E+00
   double precision :: N3Ku= 0.92329E+00
   double precision :: be= 0.15901E+01
   double precision :: ga= 0.20776E+01
   double precision :: de= 0.10600E+00
   double precision :: g2= 0.11997E+00
   double precision :: lamF= 0.48019E+01
   double precision :: N4= 0.14963E+00
   double precision :: lam= 0.13041E+01

!  replica 266 (flav_dep 1)