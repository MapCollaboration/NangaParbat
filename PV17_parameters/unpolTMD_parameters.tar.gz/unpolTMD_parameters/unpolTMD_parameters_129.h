   double precision :: N1d= 0.30522E+00
   double precision :: N1u= 0.30522E+00
   double precision :: N1s= 0.30522E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.18533E+00
   double precision :: N3fv= 0.81890E+00
   double precision :: N3unfv= 0.81890E+00
   double precision :: N3Ks= 0.81890E+00
   double precision :: N3Ku= 0.81890E+00
   double precision :: be= 0.13022E+01
   double precision :: ga= 0.21499E+01
   double precision :: de= 0.16142E+00
   double precision :: g2= 0.12636E+00
   double precision :: lamF= 0.61424E+01
   double precision :: N4= 0.12390E+00
   double precision :: lam= 0.45288E+00

!  replica 129 (flav_dep 1)