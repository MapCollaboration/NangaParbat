   double precision :: N1d= 0.27335E+00
   double precision :: N1u= 0.27335E+00
   double precision :: N1s= 0.27335E+00
   double precision :: al= 0.29984E+01
   double precision :: si= 0.17462E+00
   double precision :: N3fv= 0.81757E+00
   double precision :: N3unfv= 0.81757E+00
   double precision :: N3Ks= 0.81757E+00
   double precision :: N3Ku= 0.81757E+00
   double precision :: be= 0.15142E+01
   double precision :: ga= 0.21411E+01
   double precision :: de= 0.13562E+00
   double precision :: g2= 0.14169E+00
   double precision :: lamF= 0.46241E+01
   double precision :: N4= 0.13714E+00
   double precision :: lam= 0.28754E+00

!  replica 184 (flav_dep 1)