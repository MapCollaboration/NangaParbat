   double precision :: N1d= 0.28228E+00
   double precision :: N1u= 0.28228E+00
   double precision :: N1s= 0.28228E+00
   double precision :: al= 0.29983E+01
   double precision :: si= 0.19140E+00
   double precision :: N3fv= 0.87358E+00
   double precision :: N3unfv= 0.87358E+00
   double precision :: N3Ks= 0.87358E+00
   double precision :: N3Ku= 0.87358E+00
   double precision :: be= 0.17752E+01
   double precision :: ga= 0.19624E+01
   double precision :: de= 0.14613E+00
   double precision :: g2= 0.12466E+00
   double precision :: lamF= 0.42301E+01
   double precision :: N4= 0.14346E+00
   double precision :: lam= 0.87431E-01

!  replica 257 (flav_dep 1)