   double precision :: N1d= 0.33148E+00
   double precision :: N1u= 0.33148E+00
   double precision :: N1s= 0.33148E+00
   double precision :: al= 0.29969E+01
   double precision :: si= 0.16462E+00
   double precision :: N3fv= 1.99595E-01
   double precision :: N3unfv= 1.99595E-01
   double precision :: N3Ks= 1.99595E-01
   double precision :: N3Ku= 1.99595E-01
   double precision :: be= 0.77212E+00
   double precision :: ga= 0.20851E+01
   double precision :: de= 0.24946E-01
   double precision :: g2= 0.12909E+00
   double precision :: lamF= 0.61024E+01
   double precision :: N4= 3.20350E-02
   double precision :: lam= 0.14115E+00

!  replica 274 (flav_dep 1)