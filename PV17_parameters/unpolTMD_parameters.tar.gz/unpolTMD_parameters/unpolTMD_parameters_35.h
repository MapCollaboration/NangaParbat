   double precision :: N1d= 0.25949E+00
   double precision :: N1u= 0.25949E+00
   double precision :: N1s= 0.25949E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.17483E+00
   double precision :: N3fv= 2.07918E-01
   double precision :: N3unfv= 2.07918E-01
   double precision :: N3Ks= 2.07918E-01
   double precision :: N3Ku= 2.07918E-01
   double precision :: be= 0.16132E+01
   double precision :: ga= 0.24590E+01
   double precision :: de= 0.12190E+00
   double precision :: g2= 0.12716E+00
   double precision :: lamF= 0.65550E+01
   double precision :: N4= 3.13725E-02
   double precision :: lam= 0.15018E+01

!  replica 35 (flav_dep 1)