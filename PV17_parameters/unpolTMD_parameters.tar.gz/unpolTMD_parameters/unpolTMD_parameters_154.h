   double precision :: N1d= 0.26380E+00
   double precision :: N1u= 0.26380E+00
   double precision :: N1s= 0.26380E+00
   double precision :: al= 0.28652E+01
   double precision :: si= 0.16083E+00
   double precision :: N3fv= 2.32948E-01
   double precision :: N3unfv= 2.32948E-01
   double precision :: N3Ks= 2.32948E-01
   double precision :: N3Ku= 2.32948E-01
   double precision :: be= 0.21131E+01
   double precision :: ga= 0.24496E+01
   double precision :: de= 0.10203E+00
   double precision :: g2= 0.10607E+00
   double precision :: lamF= 0.63789E+01
   double precision :: N4= 3.53125E-02
   double precision :: lam= 0.11185E+01

!  replica 154 (flav_dep 1)