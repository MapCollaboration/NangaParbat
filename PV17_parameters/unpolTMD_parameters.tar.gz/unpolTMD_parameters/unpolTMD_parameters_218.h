   double precision :: N1d= 0.36113E+00
   double precision :: N1u= 0.36113E+00
   double precision :: N1s= 0.36113E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.18799E+00
   double precision :: N3fv= 0.81500E+00
   double precision :: N3unfv= 0.81500E+00
   double precision :: N3Ks= 0.81500E+00
   double precision :: N3Ku= 0.81500E+00
   double precision :: be= 0.28262E+01
   double precision :: ga= 0.34706E+01
   double precision :: de= 0.36110E-01
   double precision :: g2= 0.12381E+00
   double precision :: lamF= 0.53547E+01
   double precision :: N4= 0.12843E+00
   double precision :: lam= 0.34226E-02

!  replica 218 (flav_dep 1)