   double precision :: N1d= 0.28500E+00
   double precision :: N1u= 0.28500E+00
   double precision :: N1s= 0.28500E+00
   double precision :: al= 0.29791E+01
   double precision :: si= 0.20065E+00
   double precision :: N3fv= 2.20180E-01
   double precision :: N3unfv= 2.20180E-01
   double precision :: N3Ks= 2.20180E-01
   double precision :: N3Ku= 2.20180E-01
   double precision :: be= 0.14117E+01
   double precision :: ga= 0.18977E+01
   double precision :: de= 0.18994E+00
   double precision :: g2= 0.13001E+00
   double precision :: lamF= 0.57184E+01
   double precision :: N4= 3.42450E-02
   double precision :: lam= 0.16957E+00

!  replica 242 (flav_dep 1)