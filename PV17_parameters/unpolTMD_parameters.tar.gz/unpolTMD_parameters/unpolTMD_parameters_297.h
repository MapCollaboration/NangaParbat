   double precision :: N1d= 0.54809E-04
   double precision :: N1u= 0.54809E-04
   double precision :: N1s= 0.54809E-04
   double precision :: al= 0.26003E+01
   double precision :: si= -0.43285E+00
   double precision :: N3fv= 2.84450E-01
   double precision :: N3unfv= 2.84450E-01
   double precision :: N3Ks= 2.84450E-01
   double precision :: N3Ku= 2.84450E-01
   double precision :: be= 0.20253E+01
   double precision :: ga= 0.11736E+01
   double precision :: de= 0.18234E+00
   double precision :: g2= 0.14099E+00
   double precision :: lamF= 0.30207E+01
   double precision :: N4= 4.53625E-02
   double precision :: lam= 0.34423E+00

!  replica 297 (flav_dep 1)