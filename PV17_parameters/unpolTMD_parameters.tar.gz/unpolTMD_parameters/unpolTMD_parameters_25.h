   double precision :: N1d= 0.22149E+00
   double precision :: N1u= 0.22149E+00
   double precision :: N1s= 0.22149E+00
   double precision :: al= 0.29987E+01
   double precision :: si= 0.15800E+00
   double precision :: N3fv= 2.14432E-01
   double precision :: N3unfv= 2.14432E-01
   double precision :: N3Ks= 2.14432E-01
   double precision :: N3Ku= 2.14432E-01
   double precision :: be= 0.16806E+01
   double precision :: ga= 0.21681E+01
   double precision :: de= 0.16061E+00
   double precision :: g2= 0.13142E+00
   double precision :: lamF= 0.59618E+01
   double precision :: N4= 3.29675E-02
   double precision :: lam= 0.20694E+01

!  replica 25 (flav_dep 1)