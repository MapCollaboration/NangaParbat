   double precision :: N1d= 0.31149E+00
   double precision :: N1u= 0.31149E+00
   double precision :: N1s= 0.31149E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.18955E+00
   double precision :: N3fv= 0.82236E+00
   double precision :: N3unfv= 0.82236E+00
   double precision :: N3Ks= 0.82236E+00
   double precision :: N3Ku= 0.82236E+00
   double precision :: be= 0.19608E+01
   double precision :: ga= 0.24965E+01
   double precision :: de= 0.11061E+00
   double precision :: g2= 0.12500E+00
   double precision :: lamF= 0.57355E+01
   double precision :: N4= 0.12760E+00
   double precision :: lam= 0.41403E+00

!  replica 283 (flav_dep 1)