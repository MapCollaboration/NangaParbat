   double precision :: N1d= 0.29128E+00
   double precision :: N1u= 0.29128E+00
   double precision :: N1s= 0.29128E+00
   double precision :: al= 0.29912E+01
   double precision :: si= 0.19238E+00
   double precision :: N3fv= 2.20367E-01
   double precision :: N3unfv= 2.20367E-01
   double precision :: N3Ks= 2.20367E-01
   double precision :: N3Ku= 2.20367E-01
   double precision :: be= 0.23819E+01
   double precision :: ga= 0.27757E+01
   double precision :: de= 0.63388E-01
   double precision :: g2= 0.11987E+00
   double precision :: lamF= 0.51894E+01
   double precision :: N4= 3.44375E-02
   double precision :: lam= 0.32331E+00

!  replica 58 (flav_dep 1)