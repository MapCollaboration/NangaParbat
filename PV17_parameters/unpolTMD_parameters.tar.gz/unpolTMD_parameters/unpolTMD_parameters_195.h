   double precision :: N1d= 0.38286E+00
   double precision :: N1u= 0.38286E+00
   double precision :: N1s= 0.38286E+00
   double precision :: al= 0.23238E+01
   double precision :: si= 0.10152E+00
   double precision :: N3fv= 0.72814E+00
   double precision :: N3unfv= 0.72814E+00
   double precision :: N3Ks= 0.72814E+00
   double precision :: N3Ku= 0.72814E+00
   double precision :: be= 0.21436E+01
   double precision :: ga= 0.32380E+01
   double precision :: de= 0.62488E-01
   double precision :: g2= 0.13042E+00
   double precision :: lamF= 0.59462E+01
   double precision :: N4= 0.11463E+00
   double precision :: lam= 0.35508E-01

!  replica 195 (flav_dep 1)