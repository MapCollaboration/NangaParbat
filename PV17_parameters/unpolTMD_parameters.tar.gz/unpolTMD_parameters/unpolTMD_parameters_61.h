   double precision :: N1d= 0.21100E+00
   double precision :: N1u= 0.21100E+00
   double precision :: N1s= 0.21100E+00
   double precision :: al= 0.29990E+01
   double precision :: si= 0.17607E+00
   double precision :: N3fv= 2.23513E-01
   double precision :: N3unfv= 2.23513E-01
   double precision :: N3Ks= 2.23513E-01
   double precision :: N3Ku= 2.23513E-01
   double precision :: be= 0.66830E+00
   double precision :: ga= 0.13949E+01
   double precision :: de= 0.78125E-01
   double precision :: g2= 0.12190E+00
   double precision :: lamF= 0.45185E+01
   double precision :: N4= 3.68625E-02
   double precision :: lam= 0.20914E+01

!  replica 61 (flav_dep 1)