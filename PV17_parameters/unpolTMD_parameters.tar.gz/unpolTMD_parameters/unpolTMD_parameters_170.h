   double precision :: N1d= 0.29178E+00
   double precision :: N1u= 0.29178E+00
   double precision :: N1s= 0.29178E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.17007E+00
   double precision :: N3fv= 0.79851E+00
   double precision :: N3unfv= 0.79851E+00
   double precision :: N3Ks= 0.79851E+00
   double precision :: N3Ku= 0.79851E+00
   double precision :: be= 0.20864E+01
   double precision :: ga= 0.23175E+01
   double precision :: de= 0.27798E+00
   double precision :: g2= 0.12257E+00
   double precision :: lamF= 0.95538E+01
   double precision :: N4= 0.10463E+00
   double precision :: lam= 0.14764E+01

!  replica 170 (flav_dep 1)