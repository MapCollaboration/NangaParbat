   double precision :: N1d= 0.39670E+00
   double precision :: N1u= 0.39670E+00
   double precision :: N1s= 0.39670E+00
   double precision :: al= 0.29950E+01
   double precision :: si= 0.14564E+00
   double precision :: N3fv= 1.90550E-01
   double precision :: N3unfv= 1.90550E-01
   double precision :: N3Ks= 1.90550E-01
   double precision :: N3Ku= 1.90550E-01
   double precision :: be= 0.22030E+01
   double precision :: ga= 0.34105E+01
   double precision :: de= 0.64390E-01
   double precision :: g2= 0.12798E+00
   double precision :: lamF= 0.84194E+01
   double precision :: N4= 2.79800E-02
   double precision :: lam= 0.19803E-02

!  replica 293 (flav_dep 1)