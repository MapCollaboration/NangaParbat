   double precision :: N1d= 0.32375E+00
   double precision :: N1u= 0.32375E+00
   double precision :: N1s= 0.32375E+00
   double precision :: al= 0.29995E+01
   double precision :: si= 0.19186E+00
   double precision :: N3fv= 2.08627E-01
   double precision :: N3unfv= 2.08627E-01
   double precision :: N3Ks= 2.08627E-01
   double precision :: N3Ku= 2.08627E-01
   double precision :: be= 0.14269E+01
   double precision :: ga= 0.21136E+01
   double precision :: de= 0.12998E+00
   double precision :: g2= 0.12517E+00
   double precision :: lamF= 0.48012E+01
   double precision :: N4= 3.36225E-02
   double precision :: lam= 0.18896E-01

!  replica 286 (flav_dep 1)