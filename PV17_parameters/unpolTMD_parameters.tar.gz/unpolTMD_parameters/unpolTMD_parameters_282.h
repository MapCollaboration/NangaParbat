   double precision :: N1d= 0.37072E+00
   double precision :: N1u= 0.37072E+00
   double precision :: N1s= 0.37072E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14486E+00
   double precision :: N3fv= 1.92050E-01
   double precision :: N3unfv= 1.92050E-01
   double precision :: N3Ks= 1.92050E-01
   double precision :: N3Ku= 1.92050E-01
   double precision :: be= 0.15301E+01
   double precision :: ga= 0.25269E+01
   double precision :: de= 0.17265E+00
   double precision :: g2= 0.12391E+00
   double precision :: lamF= 0.80546E+01
   double precision :: N4= 2.79900E-02
   double precision :: lam= 0.11415E+00

!  replica 282 (flav_dep 1)