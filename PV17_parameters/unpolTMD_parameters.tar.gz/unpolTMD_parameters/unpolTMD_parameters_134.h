   double precision :: N1d= 0.27354E+00
   double precision :: N1u= 0.27354E+00
   double precision :: N1s= 0.27354E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.19321E+00
   double precision :: N3fv= 2.21263E-01
   double precision :: N3unfv= 2.21263E-01
   double precision :: N3Ks= 2.21263E-01
   double precision :: N3Ku= 2.21263E-01
   double precision :: be= 0.14424E+01
   double precision :: ga= 0.19341E+01
   double precision :: de= 0.19909E+00
   double precision :: g2= 0.11606E+00
   double precision :: lamF= 0.59485E+01
   double precision :: N4= 3.38175E-02
   double precision :: lam= 0.77485E+00

!  replica 134 (flav_dep 1)