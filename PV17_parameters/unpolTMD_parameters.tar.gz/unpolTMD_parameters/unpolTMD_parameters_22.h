   double precision :: N1d= 0.25353E+00
   double precision :: N1u= 0.25353E+00
   double precision :: N1s= 0.25353E+00
   double precision :: al= 0.29988E+01
   double precision :: si= 0.13432E+00
   double precision :: N3fv= 0.87991E+00
   double precision :: N3unfv= 0.87991E+00
   double precision :: N3Ks= 0.87991E+00
   double precision :: N3Ku= 0.87991E+00
   double precision :: be= 0.18707E+01
   double precision :: ga= 0.22267E+01
   double precision :: de= 0.94035E-01
   double precision :: g2= 0.13179E+00
   double precision :: lamF= 0.39490E+01
   double precision :: N4= 0.14435E+00
   double precision :: lam= 0.22458E-02

!  replica 22 (flav_dep 1)