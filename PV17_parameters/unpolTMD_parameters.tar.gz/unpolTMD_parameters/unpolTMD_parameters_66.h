   double precision :: N1d= 0.24835E+00
   double precision :: N1u= 0.24835E+00
   double precision :: N1s= 0.24835E+00
   double precision :: al= 0.24866E+01
   double precision :: si= 0.12381E+00
   double precision :: N3fv= 2.22135E-01
   double precision :: N3unfv= 2.22135E-01
   double precision :: N3Ks= 2.22135E-01
   double precision :: N3Ku= 2.22135E-01
   double precision :: be= 0.15682E+01
   double precision :: ga= 0.19161E+01
   double precision :: de= 0.13698E+00
   double precision :: g2= 0.12932E+00
   double precision :: lamF= 0.40866E+01
   double precision :: N4= 3.68475E-02
   double precision :: lam= 0.11673E+00

!  replica 66 (flav_dep 1)