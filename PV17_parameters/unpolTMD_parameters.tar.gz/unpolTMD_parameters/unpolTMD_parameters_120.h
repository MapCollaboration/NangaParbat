   double precision :: N1d= 0.37937E+00
   double precision :: N1u= 0.37937E+00
   double precision :: N1s= 0.37937E+00
   double precision :: al= 0.29993E+01
   double precision :: si= 0.14479E+00
   double precision :: N3fv= 0.72027E+00
   double precision :: N3unfv= 0.72027E+00
   double precision :: N3Ks= 0.72027E+00
   double precision :: N3Ku= 0.72027E+00
   double precision :: be= 0.10849E+01
   double precision :: ga= 0.29334E+01
   double precision :: de= 0.36454E-01
   double precision :: g2= 0.12541E+00
   double precision :: lamF= 0.85082E+01
   double precision :: N4= 0.10810E+00
   double precision :: lam= 0.30131E+00

!  replica 120 (flav_dep 1)