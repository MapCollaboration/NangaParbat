   double precision :: N1d= 0.37971E+00
   double precision :: N1u= 0.37971E+00
   double precision :: N1s= 0.37971E+00
   double precision :: al= 0.16442E+01
   double precision :: si= 0.97627E-01
   double precision :: N3fv= 1.96825E-01
   double precision :: N3unfv= 1.96825E-01
   double precision :: N3Ks= 1.96825E-01
   double precision :: N3Ku= 1.96825E-01
   double precision :: be= 0.22184E+01
   double precision :: ga= 0.29456E+01
   double precision :: de= 0.82865E-01
   double precision :: g2= 0.12284E+00
   double precision :: lamF= 0.67295E+01
   double precision :: N4= 3.01850E-02
   double precision :: lam= 0.12676E+00

!  replica 13 (flav_dep 1)