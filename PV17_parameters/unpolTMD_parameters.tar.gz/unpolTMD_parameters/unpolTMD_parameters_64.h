   double precision :: N1d= 0.38080E+00
   double precision :: N1u= 0.38080E+00
   double precision :: N1s= 0.38080E+00
   double precision :: al= 0.29926E+01
   double precision :: si= 0.14916E+00
   double precision :: N3fv= 1.85097E-01
   double precision :: N3unfv= 1.85097E-01
   double precision :: N3Ks= 1.85097E-01
   double precision :: N3Ku= 1.85097E-01
   double precision :: be= 0.14736E+01
   double precision :: ga= 0.23763E+01
   double precision :: de= 0.33002E+00
   double precision :: g2= 0.12541E+00
   double precision :: lamF= 0.92363E+01
   double precision :: N4= 2.55150E-02
   double precision :: lam= 0.16943E+00

!  replica 64 (flav_dep 1)