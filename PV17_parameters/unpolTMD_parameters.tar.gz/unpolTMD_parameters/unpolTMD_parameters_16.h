   double precision :: N1d= 0.31429E+00
   double precision :: N1u= 0.31429E+00
   double precision :: N1s= 0.31429E+00
   double precision :: al= 0.27472E+01
   double precision :: si= 0.15247E+00
   double precision :: N3fv= 0.83376E+00
   double precision :: N3unfv= 0.83376E+00
   double precision :: N3Ks= 0.83376E+00
   double precision :: N3Ku= 0.83376E+00
   double precision :: be= 0.25393E+01
   double precision :: ga= 0.32941E+01
   double precision :: de= 0.46483E-01
   double precision :: g2= 0.12325E+00
   double precision :: lamF= 0.60733E+01
   double precision :: N4= 0.12832E+00
   double precision :: lam= 0.37103E+00

!  replica 16 (flav_dep 1)