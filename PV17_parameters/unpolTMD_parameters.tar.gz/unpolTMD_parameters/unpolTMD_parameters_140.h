   double precision :: N1d= 0.27591E+00
   double precision :: N1u= 0.27591E+00
   double precision :: N1s= 0.27591E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.14965E+00
   double precision :: N3fv= 0.86026E+00
   double precision :: N3unfv= 0.86026E+00
   double precision :: N3Ks= 0.86026E+00
   double precision :: N3Ku= 0.86026E+00
   double precision :: be= 0.15513E+01
   double precision :: ga= 0.18629E+01
   double precision :: de= 0.16494E+00
   double precision :: g2= 0.12709E+00
   double precision :: lamF= 0.42126E+01
   double precision :: N4= 0.14147E+00
   double precision :: lam= 0.60929E-01

!  replica 140 (flav_dep 1)