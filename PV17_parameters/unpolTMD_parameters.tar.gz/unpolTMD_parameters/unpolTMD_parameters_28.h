   double precision :: N1d= 0.28319E+00
   double precision :: N1u= 0.28319E+00
   double precision :: N1s= 0.28319E+00
   double precision :: al= 0.29674E+01
   double precision :: si= 0.16193E+00
   double precision :: N3fv= 2.23265E-01
   double precision :: N3unfv= 2.23265E-01
   double precision :: N3Ks= 2.23265E-01
   double precision :: N3Ku= 2.23265E-01
   double precision :: be= 0.21230E+01
   double precision :: ga= 0.23723E+01
   double precision :: de= 0.95749E-01
   double precision :: g2= 0.12099E+00
   double precision :: lamF= 0.49320E+01
   double precision :: N4= 3.51250E-02
   double precision :: lam= 0.90413E-01

!  replica 28 (flav_dep 1)