   double precision :: N1d= 0.29442E+00
   double precision :: N1u= 0.29442E+00
   double precision :: N1s= 0.29442E+00
   double precision :: al= 0.29932E+01
   double precision :: si= 0.17225E+00
   double precision :: N3fv= 2.03420E-01
   double precision :: N3unfv= 2.03420E-01
   double precision :: N3Ks= 2.03420E-01
   double precision :: N3Ku= 2.03420E-01
   double precision :: be= 0.12322E+01
   double precision :: ga= 0.19274E+01
   double precision :: de= 0.28612E+00
   double precision :: g2= 0.12476E+00
   double precision :: lamF= 0.70246E+01
   double precision :: N4= 2.97500E-02
   double precision :: lam= 0.75343E+00

!  replica 217 (flav_dep 1)