   double precision :: N1d= 0.33235E+00
   double precision :: N1u= 0.33235E+00
   double precision :: N1s= 0.33235E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.16155E+00
   double precision :: N3fv= 0.79078E+00
   double precision :: N3unfv= 0.79078E+00
   double precision :: N3Ks= 0.79078E+00
   double precision :: N3Ku= 0.79078E+00
   double precision :: be= 0.20143E+01
   double precision :: ga= 0.29923E+01
   double precision :: de= 0.92079E-01
   double precision :: g2= 0.12278E+00
   double precision :: lamF= 0.79821E+01
   double precision :: N4= 0.11523E+00
   double precision :: lam= 0.57163E+00

!  replica 107 (flav_dep 1)