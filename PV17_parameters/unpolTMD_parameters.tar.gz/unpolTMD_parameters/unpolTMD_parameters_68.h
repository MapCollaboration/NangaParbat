   double precision :: N1d= 0.38477E+00
   double precision :: N1u= 0.38477E+00
   double precision :: N1s= 0.38477E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14343E+00
   double precision :: N3fv= 1.91625E-01
   double precision :: N3unfv= 1.91625E-01
   double precision :: N3Ks= 1.91625E-01
   double precision :: N3Ku= 1.91625E-01
   double precision :: be= 0.16898E+01
   double precision :: ga= 0.28338E+01
   double precision :: de= 0.12583E+00
   double precision :: g2= 0.12532E+00
   double precision :: lamF= 0.86011E+01
   double precision :: N4= 2.76725E-02
   double precision :: lam= 0.55588E-01

!  replica 68 (flav_dep 1)