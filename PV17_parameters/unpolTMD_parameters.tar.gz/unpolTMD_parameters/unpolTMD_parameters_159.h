   double precision :: N1d= 0.29136E+00
   double precision :: N1u= 0.29136E+00
   double precision :: N1s= 0.29136E+00
   double precision :: al= 0.28975E+01
   double precision :: si= 0.18727E+00
   double precision :: N3fv= 0.83579E+00
   double precision :: N3unfv= 0.83579E+00
   double precision :: N3Ks= 0.83579E+00
   double precision :: N3Ku= 0.83579E+00
   double precision :: be= 0.74271E+00
   double precision :: ga= 0.15595E+01
   double precision :: de= 0.42606E-01
   double precision :: g2= 0.11861E+00
   double precision :: lamF= 0.38099E+01
   double precision :: N4= 0.14055E+00
   double precision :: lam= 0.26756E+00

!  replica 159 (flav_dep 1)