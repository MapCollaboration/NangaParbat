   double precision :: N1d= 0.21951E+00
   double precision :: N1u= 0.21951E+00
   double precision :: N1s= 0.21951E+00
   double precision :: al= 0.29710E+01
   double precision :: si= 0.18284E+00
   double precision :: N3fv= 2.31970E-01
   double precision :: N3unfv= 2.31970E-01
   double precision :: N3Ks= 2.31970E-01
   double precision :: N3Ku= 2.31970E-01
   double precision :: be= 0.23041E+01
   double precision :: ga= 0.24832E+01
   double precision :: de= 0.79860E-01
   double precision :: g2= 0.12603E+00
   double precision :: lamF= 0.53353E+01
   double precision :: N4= 3.56000E-02
   double precision :: lam= 0.12676E+01

!  replica 5 (flav_dep 1)