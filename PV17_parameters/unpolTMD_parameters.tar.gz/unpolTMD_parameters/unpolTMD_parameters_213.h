   double precision :: N1d= 0.14938E+00
   double precision :: N1u= 0.14938E+00
   double precision :: N1s= 0.14938E+00
   double precision :: al= 0.29570E+01
   double precision :: si= 0.21303E+00
   double precision :: N3fv= 2.49575E-01
   double precision :: N3unfv= 2.49575E-01
   double precision :: N3Ks= 2.49575E-01
   double precision :: N3Ku= 2.49575E-01
   double precision :: be= 0.17846E+01
   double precision :: ga= 0.17665E+01
   double precision :: de= 0.13608E+00
   double precision :: g2= 0.11837E+00
   double precision :: lamF= 0.41395E+01
   double precision :: N4= 4.06225E-02
   double precision :: lam= 0.47598E+01

!  replica 213 (flav_dep 1)