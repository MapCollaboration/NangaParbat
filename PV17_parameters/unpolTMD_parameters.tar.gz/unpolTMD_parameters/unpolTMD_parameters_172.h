   double precision :: N1d= 0.28369E+00
   double precision :: N1u= 0.28369E+00
   double precision :: N1s= 0.28369E+00
   double precision :: al= 0.29967E+01
   double precision :: si= 0.19759E+00
   double precision :: N3fv= 2.14223E-01
   double precision :: N3unfv= 2.14223E-01
   double precision :: N3Ks= 2.14223E-01
   double precision :: N3Ku= 2.14223E-01
   double precision :: be= 0.23431E+01
   double precision :: ga= 0.27187E+01
   double precision :: de= 0.49707E-01
   double precision :: g2= 0.12679E+00
   double precision :: lamF= 0.28529E+01
   double precision :: N4= 3.93250E-02
   double precision :: lam= 0.12670E+00

!  replica 172 (flav_dep 1)