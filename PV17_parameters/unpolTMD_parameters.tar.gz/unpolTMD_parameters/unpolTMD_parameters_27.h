   double precision :: N1d= 0.31485E+00
   double precision :: N1u= 0.31485E+00
   double precision :: N1s= 0.31485E+00
   double precision :: al= 0.29589E+01
   double precision :: si= 0.13880E+00
   double precision :: N3fv= 2.05497E-01
   double precision :: N3unfv= 2.05497E-01
   double precision :: N3Ks= 2.05497E-01
   double precision :: N3Ku= 2.05497E-01
   double precision :: be= 0.19131E+01
   double precision :: ga= 0.25939E+01
   double precision :: de= 0.10851E+00
   double precision :: g2= 0.12764E+00
   double precision :: lamF= 0.62989E+01
   double precision :: N4= 3.17850E-02
   double precision :: lam= 0.21857E+00

!  replica 27 (flav_dep 1)