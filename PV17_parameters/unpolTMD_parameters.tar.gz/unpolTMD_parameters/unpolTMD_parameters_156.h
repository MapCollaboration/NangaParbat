   double precision :: N1d= 0.30717E+00
   double precision :: N1u= 0.30717E+00
   double precision :: N1s= 0.30717E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.18230E+00
   double precision :: N3fv= 0.84013E+00
   double precision :: N3unfv= 0.84013E+00
   double precision :: N3Ks= 0.84013E+00
   double precision :: N3Ku= 0.84013E+00
   double precision :: be= 0.13327E+01
   double precision :: ga= 0.19129E+01
   double precision :: de= 0.23017E+00
   double precision :: g2= 0.11778E+00
   double precision :: lamF= 0.58130E+01
   double precision :: N4= 0.13367E+00
   double precision :: lam= 0.46009E+00

!  replica 156 (flav_dep 1)