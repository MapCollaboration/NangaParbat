   double precision :: N1d= 0.22635E+00
   double precision :: N1u= 0.22635E+00
   double precision :: N1s= 0.22635E+00
   double precision :: al= 0.29995E+01
   double precision :: si= 0.16891E+00
   double precision :: N3fv= 0.95603E+00
   double precision :: N3unfv= 0.95603E+00
   double precision :: N3Ks= 0.95603E+00
   double precision :: N3Ku= 0.95603E+00
   double precision :: be= 0.17417E+01
   double precision :: ga= 0.17504E+01
   double precision :: de= 0.18754E+00
   double precision :: g2= 0.12693E+00
   double precision :: lamF= 0.49057E+01
   double precision :: N4= 0.15371E+00
   double precision :: lam= 0.85131E-01

!  replica 148 (flav_dep 1)