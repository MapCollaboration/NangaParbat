   double precision :: N1d= 0.30466E+00
   double precision :: N1u= 0.30466E+00
   double precision :: N1s= 0.30466E+00
   double precision :: al= 0.29960E+01
   double precision :: si= 0.17328E+00
   double precision :: N3fv= 1.98980E-01
   double precision :: N3unfv= 1.98980E-01
   double precision :: N3Ks= 1.98980E-01
   double precision :: N3Ku= 1.98980E-01
   double precision :: be= 0.14618E+01
   double precision :: ga= 0.23236E+01
   double precision :: de= 0.12865E+00
   double precision :: g2= 0.13125E+00
   double precision :: lamF= 0.54732E+01
   double precision :: N4= 3.16800E-02
   double precision :: lam= 0.40452E+00

!  replica 167 (flav_dep 1)