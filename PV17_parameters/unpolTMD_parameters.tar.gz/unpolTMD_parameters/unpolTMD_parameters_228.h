   double precision :: N1d= 0.30325E+00
   double precision :: N1u= 0.30325E+00
   double precision :: N1s= 0.30325E+00
   double precision :: al= 0.29994E+01
   double precision :: si= 0.18359E+00
   double precision :: N3fv= 2.14322E-01
   double precision :: N3unfv= 2.14322E-01
   double precision :: N3Ks= 2.14322E-01
   double precision :: N3Ku= 2.14322E-01
   double precision :: be= 0.13178E+01
   double precision :: ga= 0.17927E+01
   double precision :: de= 0.25123E+00
   double precision :: g2= 0.12241E+00
   double precision :: lamF= 0.60304E+01
   double precision :: N4= 3.24575E-02
   double precision :: lam= 0.18798E+00

!  replica 228 (flav_dep 1)