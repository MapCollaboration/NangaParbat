   double precision :: N1d= 0.31725E+00
   double precision :: N1u= 0.31725E+00
   double precision :: N1s= 0.31725E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.16937E+00
   double precision :: N3fv= 1.95385E-01
   double precision :: N3unfv= 1.95385E-01
   double precision :: N3Ks= 1.95385E-01
   double precision :: N3Ku= 1.95385E-01
   double precision :: be= 0.88343E+00
   double precision :: ga= 0.19669E+01
   double precision :: de= 0.16370E+00
   double precision :: g2= 0.12953E+00
   double precision :: lamF= 0.63353E+01
   double precision :: N4= 2.97100E-02
   double precision :: lam= 0.39864E+00

!  replica 279 (flav_dep 1)