   double precision :: N1d= 0.34732E+00
   double precision :: N1u= 0.34732E+00
   double precision :: N1s= 0.34732E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.14026E+00
   double precision :: N3fv= 0.73205E+00
   double precision :: N3unfv= 0.73205E+00
   double precision :: N3Ks= 0.73205E+00
   double precision :: N3Ku= 0.73205E+00
   double precision :: be= 0.18099E+01
   double precision :: ga= 0.23487E+01
   double precision :: de= 0.29945E+00
   double precision :: g2= 0.12756E+00
   double precision :: lamF= 0.84813E+01
   double precision :: N4= 0.99969E-01
   double precision :: lam= 0.43079E+00

!  replica 30 (flav_dep 1)