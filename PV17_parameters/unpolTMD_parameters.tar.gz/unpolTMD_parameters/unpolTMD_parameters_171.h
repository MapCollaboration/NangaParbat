   double precision :: N1d= 0.30381E+00
   double precision :: N1u= 0.30381E+00
   double precision :: N1s= 0.30381E+00
   double precision :: al= 0.26530E+01
   double precision :: si= 0.14777E+00
   double precision :: N3fv= 0.81491E+00
   double precision :: N3unfv= 0.81491E+00
   double precision :: N3Ks= 0.81491E+00
   double precision :: N3Ku= 0.81491E+00
   double precision :: be= 0.14032E+01
   double precision :: ga= 0.22251E+01
   double precision :: de= 0.14018E+00
   double precision :: g2= 0.13217E+00
   double precision :: lamF= 0.57502E+01
   double precision :: N4= 0.12748E+00
   double precision :: lam= 0.22150E+00

!  replica 171 (flav_dep 1)