   double precision :: N1d= 0.26913E+00
   double precision :: N1u= 0.26913E+00
   double precision :: N1s= 0.26913E+00
   double precision :: al= 0.29973E+01
   double precision :: si= 0.15196E+00
   double precision :: N3fv= 2.21025E-01
   double precision :: N3unfv= 2.21025E-01
   double precision :: N3Ks= 2.21025E-01
   double precision :: N3Ku= 2.21025E-01
   double precision :: be= 0.20359E+01
   double precision :: ga= 0.25555E+01
   double precision :: de= 0.78187E-01
   double precision :: g2= 0.12943E+00
   double precision :: lamF= 0.51030E+01
   double precision :: N4= 3.52350E-02
   double precision :: lam= 0.85834E-01

!  replica 96 (flav_dep 1)