   double precision :: N1d= 0.13165E+00
   double precision :: N1u= 0.13165E+00
   double precision :: N1s= 0.13165E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.13349E+00
   double precision :: N3fv= 0.10189E+01
   double precision :: N3unfv= 0.10189E+01
   double precision :: N3Ks= 0.10189E+01
   double precision :: N3Ku= 0.10189E+01
   double precision :: be= 0.22464E+01
   double precision :: ga= 0.20458E+01
   double precision :: de= 0.86568E-01
   double precision :: g2= 0.13575E+00
   double precision :: lamF= 0.37835E+01
   double precision :: N4= 0.16495E+00
   double precision :: lam= 0.31688E+00

!  replica 51 (flav_dep 1)