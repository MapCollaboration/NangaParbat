   double precision :: N1d= 0.21467E+00
   double precision :: N1u= 0.21467E+00
   double precision :: N1s= 0.21467E+00
   double precision :: al= 0.29933E+01
   double precision :: si= 0.20178E+00
   double precision :: N3fv= 0.87261E+00
   double precision :: N3unfv= 0.87261E+00
   double precision :: N3Ks= 0.87261E+00
   double precision :: N3Ku= 0.87261E+00
   double precision :: be= 0.10768E+01
   double precision :: ga= 0.16175E+01
   double precision :: de= 0.24092E+00
   double precision :: g2= 0.12074E+00
   double precision :: lamF= 0.54274E+01
   double precision :: N4= 0.13360E+00
   double precision :: lam= 0.31528E+01

!  replica 137 (flav_dep 1)