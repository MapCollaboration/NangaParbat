   double precision :: N1d= 0.25424E+00
   double precision :: N1u= 0.25424E+00
   double precision :: N1s= 0.25424E+00
   double precision :: al= 0.22032E+01
   double precision :: si= 0.16325E+00
   double precision :: N3fv= 0.88876E+00
   double precision :: N3unfv= 0.88876E+00
   double precision :: N3Ks= 0.88876E+00
   double precision :: N3Ku= 0.88876E+00
   double precision :: be= 0.21346E+01
   double precision :: ga= 0.22847E+01
   double precision :: de= 0.92074E-01
   double precision :: g2= 0.12444E+00
   double precision :: lamF= 0.38492E+01
   double precision :: N4= 0.14927E+00
   double precision :: lam= 0.53150E+00

!  replica 52 (flav_dep 1)