   double precision :: N1d= 0.34364E+00
   double precision :: N1u= 0.34364E+00
   double precision :: N1s= 0.34364E+00
   double precision :: al= 0.25507E+01
   double precision :: si= 0.16865E+00
   double precision :: N3fv= 2.18353E-01
   double precision :: N3unfv= 2.18353E-01
   double precision :: N3Ks= 2.18353E-01
   double precision :: N3Ku= 2.18353E-01
   double precision :: be= 0.10366E+01
   double precision :: ga= 0.20511E+01
   double precision :: de= 0.13569E-01
   double precision :: g2= 0.10671E+00
   double precision :: lamF= 0.40839E+01
   double precision :: N4= 3.81950E-02
   double precision :: lam= 0.11438E-01

!  replica 19 (flav_dep 1)