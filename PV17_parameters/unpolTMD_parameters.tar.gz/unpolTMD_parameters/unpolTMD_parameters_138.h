   double precision :: N1d= 0.32572E+00
   double precision :: N1u= 0.32572E+00
   double precision :: N1s= 0.32572E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.18577E+00
   double precision :: N3fv= 0.79271E+00
   double precision :: N3unfv= 0.79271E+00
   double precision :: N3Ks= 0.79271E+00
   double precision :: N3Ku= 0.79271E+00
   double precision :: be= 0.11614E+01
   double precision :: ga= 0.19476E+01
   double precision :: de= 0.11239E+00
   double precision :: g2= 0.13202E+00
   double precision :: lamF= 0.38874E+01
   double precision :: N4= 0.13321E+00
   double precision :: lam= 0.20996E-01

!  replica 138 (flav_dep 1)