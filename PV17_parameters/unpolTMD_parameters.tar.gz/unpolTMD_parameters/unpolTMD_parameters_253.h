   double precision :: N1d= 0.34713E+00
   double precision :: N1u= 0.34713E+00
   double precision :: N1s= 0.34713E+00
   double precision :: al= 0.22552E+01
   double precision :: si= 0.11273E+00
   double precision :: N3fv= 0.77581E+00
   double precision :: N3unfv= 0.77581E+00
   double precision :: N3Ks= 0.77581E+00
   double precision :: N3Ku= 0.77581E+00
   double precision :: be= 0.13261E+01
   double precision :: ga= 0.21201E+01
   double precision :: de= 0.27847E+00
   double precision :: g2= 0.12910E+00
   double precision :: lamF= 0.74235E+01
   double precision :: N4= 0.11455E+00
   double precision :: lam= 0.15034E+00

!  replica 253 (flav_dep 1)