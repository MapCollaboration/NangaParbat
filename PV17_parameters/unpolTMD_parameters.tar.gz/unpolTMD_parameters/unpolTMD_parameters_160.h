   double precision :: N1d= 0.31380E+00
   double precision :: N1u= 0.31380E+00
   double precision :: N1s= 0.31380E+00
   double precision :: al= 0.29910E+01
   double precision :: si= 0.16190E+00
   double precision :: N3fv= 0.75675E+00
   double precision :: N3unfv= 0.75675E+00
   double precision :: N3Ks= 0.75675E+00
   double precision :: N3Ku= 0.75675E+00
   double precision :: be= 0.20123E+01
   double precision :: ga= 0.29785E+01
   double precision :: de= 0.63495E-01
   double precision :: g2= 0.13551E+00
   double precision :: lamF= 0.48064E+01
   double precision :: N4= 0.12402E+00
   double precision :: lam= 0.53262E+00

!  replica 160 (flav_dep 1)