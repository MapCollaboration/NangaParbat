   double precision :: N1d= 0.20693E+00
   double precision :: N1u= 0.20693E+00
   double precision :: N1s= 0.20693E+00
   double precision :: al= 0.28376E+01
   double precision :: si= 0.20019E+00
   double precision :: N3fv= 0.94317E+00
   double precision :: N3unfv= 0.94317E+00
   double precision :: N3Ks= 0.94317E+00
   double precision :: N3Ku= 0.94317E+00
   double precision :: be= 0.16296E+01
   double precision :: ga= 0.16066E+01
   double precision :: de= 0.26197E+00
   double precision :: g2= 0.12245E+00
   double precision :: lamF= 0.56792E+01
   double precision :: N4= 0.14409E+00
   double precision :: lam= 0.21158E+01

!  replica 190 (flav_dep 1)