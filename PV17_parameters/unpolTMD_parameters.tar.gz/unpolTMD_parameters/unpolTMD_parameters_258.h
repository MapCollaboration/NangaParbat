   double precision :: N1d= 0.30570E+00
   double precision :: N1u= 0.30570E+00
   double precision :: N1s= 0.30570E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.19156E+00
   double precision :: N3fv= 2.20000E-01
   double precision :: N3unfv= 2.20000E-01
   double precision :: N3Ks= 2.20000E-01
   double precision :: N3Ku= 2.20000E-01
   double precision :: be= 0.21440E+01
   double precision :: ga= 0.24986E+01
   double precision :: de= 0.10188E+00
   double precision :: g2= 0.12461E+00
   double precision :: lamF= 0.62860E+01
   double precision :: N4= 3.26525E-02
   double precision :: lam= 0.13399E-01

!  replica 258 (flav_dep 1)