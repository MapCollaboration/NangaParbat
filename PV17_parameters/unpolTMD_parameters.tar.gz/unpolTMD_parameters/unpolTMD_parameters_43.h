   double precision :: N1d= 0.30495E+00
   double precision :: N1u= 0.30495E+00
   double precision :: N1s= 0.30495E+00
   double precision :: al= 0.29828E+01
   double precision :: si= 0.15469E+00
   double precision :: N3fv= 0.70677E+00
   double precision :: N3unfv= 0.70677E+00
   double precision :: N3Ks= 0.70677E+00
   double precision :: N3Ku= 0.70677E+00
   double precision :: be= 0.28114E+01
   double precision :: ga= 0.34904E+01
   double precision :: de= 0.19938E-01
   double precision :: g2= 0.15205E+00
   double precision :: lamF= 0.11962E+00
   double precision :: N4= 0.21582E+00
   double precision :: lam= 0.15393E+00

!  replica 43 (flav_dep 1)