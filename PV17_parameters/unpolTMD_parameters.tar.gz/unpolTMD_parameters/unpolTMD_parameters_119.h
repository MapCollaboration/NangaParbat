   double precision :: N1d= 0.22173E+00
   double precision :: N1u= 0.22173E+00
   double precision :: N1s= 0.22173E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.18664E+00
   double precision :: N3fv= 2.41990E-01
   double precision :: N3unfv= 2.41990E-01
   double precision :: N3Ks= 2.41990E-01
   double precision :: N3Ku= 2.41990E-01
   double precision :: be= 0.17050E+01
   double precision :: ga= 0.15958E+01
   double precision :: de= 0.22066E+00
   double precision :: g2= 0.11573E+00
   double precision :: lamF= 0.49232E+01
   double precision :: N4= 3.76875E-02
   double precision :: lam= 0.34759E+00

!  replica 119 (flav_dep 1)