   double precision :: N1d= 0.31676E+00
   double precision :: N1u= 0.31676E+00
   double precision :: N1s= 0.31676E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.16850E+00
   double precision :: N3fv= 2.04728E-01
   double precision :: N3unfv= 2.04728E-01
   double precision :: N3Ks= 2.04728E-01
   double precision :: N3Ku= 2.04728E-01
   double precision :: be= 0.10575E+01
   double precision :: ga= 0.20104E+01
   double precision :: de= 0.13792E+00
   double precision :: g2= 0.12810E+00
   double precision :: lamF= 0.59475E+01
   double precision :: N4= 3.26925E-02
   double precision :: lam= 0.27939E+00

!  replica 40 (flav_dep 1)