   double precision :: N1d= 0.28239E+00
   double precision :: N1u= 0.28239E+00
   double precision :: N1s= 0.28239E+00
   double precision :: al= 0.27860E+01
   double precision :: si= 0.18569E+00
   double precision :: N3fv= 0.98911E+00
   double precision :: N3unfv= 0.98911E+00
   double precision :: N3Ks= 0.98911E+00
   double precision :: N3Ku= 0.98911E+00
   double precision :: be= 0.10600E+01
   double precision :: ga= 0.22065E+01
   double precision :: de= 0.16054E+00
   double precision :: g2= 0.10095E+00
   double precision :: lamF= 0.12000E+02
   double precision :: N4= 0.12535E+00
   double precision :: lam= 0.15031E+01

!  replica 126 (flav_dep 1)