   double precision :: N1d= 0.23113E+00
   double precision :: N1u= 0.23113E+00
   double precision :: N1s= 0.23113E+00
   double precision :: al= 0.29872E+01
   double precision :: si= 0.12092E+00
   double precision :: N3fv= 0.85162E+00
   double precision :: N3unfv= 0.85162E+00
   double precision :: N3Ks= 0.85162E+00
   double precision :: N3Ku= 0.85162E+00
   double precision :: be= 0.13745E+01
   double precision :: ga= 0.21561E+01
   double precision :: de= 0.17177E+00
   double precision :: g2= 0.12738E+00
   double precision :: lamF= 0.69850E+01
   double precision :: N4= 0.12614E+00
   double precision :: lam= 0.16414E+01

!  replica 260 (flav_dep 1)