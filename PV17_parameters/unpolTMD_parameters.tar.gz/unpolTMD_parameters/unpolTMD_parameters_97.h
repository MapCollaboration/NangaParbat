   double precision :: N1d= 0.37796E+00
   double precision :: N1u= 0.37796E+00
   double precision :: N1s= 0.37796E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.13808E+00
   double precision :: N3fv= 1.76577E-01
   double precision :: N3unfv= 1.76577E-01
   double precision :: N3Ks= 1.76577E-01
   double precision :: N3Ku= 1.76577E-01
   double precision :: be= 0.30248E+01
   double precision :: ga= 0.43218E+01
   double precision :: de= 0.27116E-01
   double precision :: g2= 0.13414E+00
   double precision :: lamF= 0.75052E+01
   double precision :: N4= 2.64025E-02
   double precision :: lam= 0.26015E+00

!  replica 97 (flav_dep 1)