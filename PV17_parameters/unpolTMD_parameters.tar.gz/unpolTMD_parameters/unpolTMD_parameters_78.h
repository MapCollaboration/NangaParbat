   double precision :: N1d= 0.27884E+00
   double precision :: N1u= 0.27884E+00
   double precision :: N1s= 0.27884E+00
   double precision :: al= 0.29996E+01
   double precision :: si= 0.17399E+00
   double precision :: N3fv= 0.81402E+00
   double precision :: N3unfv= 0.81402E+00
   double precision :: N3Ks= 0.81402E+00
   double precision :: N3Ku= 0.81402E+00
   double precision :: be= 0.97833E+00
   double precision :: ga= 0.18612E+01
   double precision :: de= 0.22187E+00
   double precision :: g2= 0.12477E+00
   double precision :: lamF= 0.65080E+01
   double precision :: N4= 0.12378E+00
   double precision :: lam= 0.11418E+01

!  replica 78 (flav_dep 1)