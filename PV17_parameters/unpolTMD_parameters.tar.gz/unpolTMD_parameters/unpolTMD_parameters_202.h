   double precision :: N1d= 0.17195E-07
   double precision :: N1u= 0.17195E-07
   double precision :: N1s= 0.17195E-07
   double precision :: al= 0.12259E+01
   double precision :: si= 0.28021E+01
   double precision :: N3fv= 2.86375E-01
   double precision :: N3unfv= 2.86375E-01
   double precision :: N3Ks= 2.86375E-01
   double precision :: N3Ku= 2.86375E-01
   double precision :: be= 0.27005E+01
   double precision :: ga= 0.20146E+01
   double precision :: de= 0.56860E-01
   double precision :: g2= 0.14526E+00
   double precision :: lamF= 0.27287E+01
   double precision :: N4= 4.49200E-02
   double precision :: lam= 0.45921E+00

!  replica 202 (flav_dep 1)