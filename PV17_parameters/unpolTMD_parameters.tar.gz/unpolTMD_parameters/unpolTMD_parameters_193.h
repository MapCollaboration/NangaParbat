   double precision :: N1d= 0.25232E+00
   double precision :: N1u= 0.25232E+00
   double precision :: N1s= 0.25232E+00
   double precision :: al= 0.29900E+01
   double precision :: si= 0.16671E+00
   double precision :: N3fv= 2.16500E-01
   double precision :: N3unfv= 2.16500E-01
   double precision :: N3Ks= 2.16500E-01
   double precision :: N3Ku= 2.16500E-01
   double precision :: be= 0.15083E+01
   double precision :: ga= 0.18738E+01
   double precision :: de= 0.21140E+00
   double precision :: g2= 0.13350E+00
   double precision :: lamF= 0.56400E+01
   double precision :: N4= 3.33150E-02
   double precision :: lam= 0.37872E+00

!  replica 193 (flav_dep 1)