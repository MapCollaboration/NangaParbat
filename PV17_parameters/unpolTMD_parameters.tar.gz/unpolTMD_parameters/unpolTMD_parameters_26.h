   double precision :: N1d= 0.24183E+00
   double precision :: N1u= 0.24183E+00
   double precision :: N1s= 0.24183E+00
   double precision :: al= 0.29859E+01
   double precision :: si= 0.21456E+00
   double precision :: N3fv= 2.02308E-01
   double precision :: N3unfv= 2.02308E-01
   double precision :: N3Ks= 2.02308E-01
   double precision :: N3Ku= 2.02308E-01
   double precision :: be= 0.14968E+01
   double precision :: ga= 0.20788E+01
   double precision :: de= 0.52252E-01
   double precision :: g2= 0.13903E+00
   double precision :: lamF= 0.12450E+01
   double precision :: N4= 4.35325E-02
   double precision :: lam= 0.48918E+00

!  replica 26 (flav_dep 1)