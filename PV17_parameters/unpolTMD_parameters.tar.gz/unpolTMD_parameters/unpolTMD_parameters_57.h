   double precision :: N1d= 0.28556E+00
   double precision :: N1u= 0.28556E+00
   double precision :: N1s= 0.28556E+00
   double precision :: al= 0.29068E+01
   double precision :: si= 0.15284E+00
   double precision :: N3fv= 0.81034E+00
   double precision :: N3unfv= 0.81034E+00
   double precision :: N3Ks= 0.81034E+00
   double precision :: N3Ku= 0.81034E+00
   double precision :: be= 0.88274E+00
   double precision :: ga= 0.20402E+01
   double precision :: de= 0.27327E+00
   double precision :: g2= 0.12481E+00
   double precision :: lamF= 0.91945E+01
   double precision :: N4= 0.11168E+00
   double precision :: lam= 0.13572E+01

!  replica 57 (flav_dep 1)