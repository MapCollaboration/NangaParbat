   double precision :: N1d= 0.28556E+00
   double precision :: N1u= 0.28556E+00
   double precision :: N1s= 0.28556E+00
   double precision :: al= 0.29068E+01
   double precision :: si= 0.15284E+00
   double precision :: N3fv= 2.02585E-01
   double precision :: N3unfv= 2.02585E-01
   double precision :: N3Ks= 2.02585E-01
   double precision :: N3Ku= 2.02585E-01
   double precision :: be= 0.88274E+00
   double precision :: ga= 0.20402E+01
   double precision :: de= 0.27327E+00
   double precision :: g2= 0.12481E+00
   double precision :: lamF= 0.91945E+01
   double precision :: N4= 2.79200E-02
   double precision :: lam= 0.13572E+01

!  replica 57 (flav_dep 1)