   double precision :: N1d= 0.38270E+00
   double precision :: N1u= 0.38270E+00
   double precision :: N1s= 0.38270E+00
   double precision :: al= 0.29985E+01
   double precision :: si= 0.16170E+00
   double precision :: N3fv= 1.78063E-01
   double precision :: N3unfv= 1.78063E-01
   double precision :: N3Ks= 1.78063E-01
   double precision :: N3Ku= 1.78063E-01
   double precision :: be= 0.24629E+01
   double precision :: ga= 0.36157E+01
   double precision :: de= 0.52334E-01
   double precision :: g2= 0.12977E+00
   double precision :: lamF= 0.73987E+01
   double precision :: N4= 2.63275E-02
   double precision :: lam= 0.31902E+00

!  replica 150 (flav_dep 1)