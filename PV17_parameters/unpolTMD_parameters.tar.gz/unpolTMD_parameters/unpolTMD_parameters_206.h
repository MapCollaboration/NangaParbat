   double precision :: N1d= 0.30379E+00
   double precision :: N1u= 0.30379E+00
   double precision :: N1s= 0.30379E+00
   double precision :: al= 0.29389E+01
   double precision :: si= 0.13876E+00
   double precision :: N3fv= 0.79624E+00
   double precision :: N3unfv= 0.79624E+00
   double precision :: N3Ks= 0.79624E+00
   double precision :: N3Ku= 0.79624E+00
   double precision :: be= 0.18071E+01
   double precision :: ga= 0.24285E+01
   double precision :: de= 0.11299E+00
   double precision :: g2= 0.13822E+00
   double precision :: lamF= 0.49901E+01
   double precision :: N4= 0.12694E+00
   double precision :: lam= 0.18237E+00

!  replica 206 (flav_dep 1)