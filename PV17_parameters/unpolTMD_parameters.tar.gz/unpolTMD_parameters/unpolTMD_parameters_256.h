   double precision :: N1d= 0.17627E+00
   double precision :: N1u= 0.17627E+00
   double precision :: N1s= 0.17627E+00
   double precision :: al= 0.29960E+01
   double precision :: si= 0.18095E+00
   double precision :: N3fv= 0.89891E+00
   double precision :: N3unfv= 0.89891E+00
   double precision :: N3Ks= 0.89891E+00
   double precision :: N3Ku= 0.89891E+00
   double precision :: be= 0.16892E+01
   double precision :: ga= 0.20856E+01
   double precision :: de= 0.13284E+00
   double precision :: g2= 0.12516E+00
   double precision :: lamF= 0.50291E+01
   double precision :: N4= 0.14203E+00
   double precision :: lam= 0.62401E+01

!  replica 256 (flav_dep 1)