   double precision :: N1d= 0.22255E+00
   double precision :: N1u= 0.22255E+00
   double precision :: N1s= 0.22255E+00
   double precision :: al= 0.29989E+01
   double precision :: si= 0.18178E+00
   double precision :: N3fv= 2.01272E-01
   double precision :: N3unfv= 2.01272E-01
   double precision :: N3Ks= 2.01272E-01
   double precision :: N3Ku= 2.01272E-01
   double precision :: be= 0.15163E+01
   double precision :: ga= 0.23828E+01
   double precision :: de= 0.87361E-01
   double precision :: g2= 0.13830E+00
   double precision :: lamF= 0.43343E+01
   double precision :: N4= 3.40325E-02
   double precision :: lam= 0.22676E+01

!  replica 179 (flav_dep 1)