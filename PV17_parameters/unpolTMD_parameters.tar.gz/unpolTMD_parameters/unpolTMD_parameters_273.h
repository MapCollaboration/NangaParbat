   double precision :: N1d= 0.31492E+00
   double precision :: N1u= 0.31492E+00
   double precision :: N1s= 0.31492E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.17889E+00
   double precision :: N3fv= 0.82098E+00
   double precision :: N3unfv= 0.82098E+00
   double precision :: N3Ks= 0.82098E+00
   double precision :: N3Ku= 0.82098E+00
   double precision :: be= 0.12373E+01
   double precision :: ga= 0.19735E+01
   double precision :: de= 0.15596E+00
   double precision :: g2= 0.12504E+00
   double precision :: lamF= 0.50174E+01
   double precision :: N4= 0.13235E+00
   double precision :: lam= 0.52776E-01

!  replica 273 (flav_dep 1)