   double precision :: N1d= 0.34811E+00
   double precision :: N1u= 0.34811E+00
   double precision :: N1s= 0.34811E+00
   double precision :: al= 0.29972E+01
   double precision :: si= 0.17450E+00
   double precision :: N3fv= 1.90702E-01
   double precision :: N3unfv= 1.90702E-01
   double precision :: N3Ks= 1.90702E-01
   double precision :: N3Ku= 1.90702E-01
   double precision :: be= 0.18439E+01
   double precision :: ga= 0.28947E+01
   double precision :: de= 0.98129E-01
   double precision :: g2= 0.12866E+00
   double precision :: lamF= 0.71715E+01
   double precision :: N4= 2.84300E-02
   double precision :: lam= 0.34785E+00

!  replica 104 (flav_dep 1)