   double precision :: N1d= 0.26241E+00
   double precision :: N1u= 0.26241E+00
   double precision :: N1s= 0.26241E+00
   double precision :: al= 0.29991E+01
   double precision :: si= 0.18884E+00
   double precision :: N3fv= 2.30293E-01
   double precision :: N3unfv= 2.30293E-01
   double precision :: N3Ks= 2.30293E-01
   double precision :: N3Ku= 2.30293E-01
   double precision :: be= 0.21688E+01
   double precision :: ga= 0.24492E+01
   double precision :: de= 0.78452E-01
   double precision :: g2= 0.12837E+00
   double precision :: lamF= 0.45929E+01
   double precision :: N4= 3.78375E-02
   double precision :: lam= 0.62727E-01

!  replica 169 (flav_dep 1)