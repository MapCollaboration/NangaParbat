   double precision :: N1d= 0.24306E+00
   double precision :: N1u= 0.24306E+00
   double precision :: N1s= 0.24306E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.20188E+00
   double precision :: N3fv= 0.92543E+00
   double precision :: N3unfv= 0.92543E+00
   double precision :: N3Ks= 0.92543E+00
   double precision :: N3Ku= 0.92543E+00
   double precision :: be= 0.10578E+01
   double precision :: ga= 0.13384E+01
   double precision :: de= 0.28586E+00
   double precision :: g2= 0.12096E+00
   double precision :: lamF= 0.46071E+01
   double precision :: N4= 0.14836E+00
   double precision :: lam= 0.30261E+00

!  replica 230 (flav_dep 1)