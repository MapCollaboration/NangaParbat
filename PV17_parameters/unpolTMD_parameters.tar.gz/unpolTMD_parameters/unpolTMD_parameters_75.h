   double precision :: N1d= 0.35506E+00
   double precision :: N1u= 0.35506E+00
   double precision :: N1s= 0.35506E+00
   double precision :: al= 0.29989E+01
   double precision :: si= 0.14417E+00
   double precision :: N3fv= 1.88865E-01
   double precision :: N3unfv= 1.88865E-01
   double precision :: N3Ks= 1.88865E-01
   double precision :: N3Ku= 1.88865E-01
   double precision :: be= 0.17653E+01
   double precision :: ga= 0.29168E+01
   double precision :: de= 0.11608E+00
   double precision :: g2= 0.12566E+00
   double precision :: lamF= 0.82784E+01
   double precision :: N4= 2.72075E-02
   double precision :: lam= 0.37355E+00

!  replica 75 (flav_dep 1)