   double precision :: N1d= 0.31545E+00
   double precision :: N1u= 0.31545E+00
   double precision :: N1s= 0.31545E+00
   double precision :: al= 0.12952E+01
   double precision :: si= 0.16500E+00
   double precision :: N3fv= 2.35467E-01
   double precision :: N3unfv= 2.35467E-01
   double precision :: N3Ks= 2.35467E-01
   double precision :: N3Ku= 2.35467E-01
   double precision :: be= 0.17511E+01
   double precision :: ga= 0.22927E+01
   double precision :: de= 0.99102E-01
   double precision :: g2= 0.10749E+00
   double precision :: lamF= 0.57510E+01
   double precision :: N4= 3.66025E-02
   double precision :: lam= 0.20652E+00

!  replica 248 (flav_dep 1)