   double precision :: N1d= 0.31545E+00
   double precision :: N1u= 0.31545E+00
   double precision :: N1s= 0.31545E+00
   double precision :: al= 0.12952E+01
   double precision :: si= 0.16500E+00
   double precision :: N3fv= 0.94187E+00
   double precision :: N3unfv= 0.94187E+00
   double precision :: N3Ks= 0.94187E+00
   double precision :: N3Ku= 0.94187E+00
   double precision :: be= 0.17511E+01
   double precision :: ga= 0.22927E+01
   double precision :: de= 0.99102E-01
   double precision :: g2= 0.10749E+00
   double precision :: lamF= 0.57510E+01
   double precision :: N4= 0.14641E+00
   double precision :: lam= 0.20652E+00

!  replica 248 (flav_dep 1)