   double precision :: N1d= 0.30796E+00
   double precision :: N1u= 0.30796E+00
   double precision :: N1s= 0.30796E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.16842E+00
   double precision :: N3fv= 0.78891E+00
   double precision :: N3unfv= 0.78891E+00
   double precision :: N3Ks= 0.78891E+00
   double precision :: N3Ku= 0.78891E+00
   double precision :: be= 0.10521E+01
   double precision :: ga= 0.21985E+01
   double precision :: de= 0.11625E+00
   double precision :: g2= 0.12507E+00
   double precision :: lamF= 0.64684E+01
   double precision :: N4= 0.12023E+00
   double precision :: lam= 0.66614E+00

!  replica 98 (flav_dep 1)