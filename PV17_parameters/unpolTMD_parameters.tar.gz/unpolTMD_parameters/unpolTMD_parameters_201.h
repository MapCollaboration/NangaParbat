   double precision :: N1d= 0.23316E+00
   double precision :: N1u= 0.23316E+00
   double precision :: N1s= 0.23316E+00
   double precision :: al= 0.29790E+01
   double precision :: si= 0.15759E+00
   double precision :: N3fv= 2.21358E-01
   double precision :: N3unfv= 2.21358E-01
   double precision :: N3Ks= 2.21358E-01
   double precision :: N3Ku= 2.21358E-01
   double precision :: be= 0.13713E+01
   double precision :: ga= 0.16361E+01
   double precision :: de= 0.22537E+00
   double precision :: g2= 0.12981E+00
   double precision :: lamF= 0.45408E+01
   double precision :: N4= 3.55250E-02
   double precision :: lam= 0.39923E+00

!  replica 201 (flav_dep 1)