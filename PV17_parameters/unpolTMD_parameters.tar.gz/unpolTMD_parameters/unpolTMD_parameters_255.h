   double precision :: N1d= 0.28649E+00
   double precision :: N1u= 0.28649E+00
   double precision :: N1s= 0.28649E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.14760E+00
   double precision :: N3fv= 0.80322E+00
   double precision :: N3unfv= 0.80322E+00
   double precision :: N3Ks= 0.80322E+00
   double precision :: N3Ku= 0.80322E+00
   double precision :: be= 0.18068E+01
   double precision :: ga= 0.23864E+01
   double precision :: de= 0.16096E+00
   double precision :: g2= 0.12931E+00
   double precision :: lamF= 0.67844E+01
   double precision :: N4= 0.12105E+00
   double precision :: lam= 0.87513E+00

!  replica 255 (flav_dep 1)