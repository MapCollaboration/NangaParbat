   double precision :: N1d= 0.37337E+00
   double precision :: N1u= 0.37337E+00
   double precision :: N1s= 0.37337E+00
   double precision :: al= 0.29471E+01
   double precision :: si= 0.13980E+00
   double precision :: N3fv= 0.75929E+00
   double precision :: N3unfv= 0.75929E+00
   double precision :: N3Ks= 0.75929E+00
   double precision :: N3Ku= 0.75929E+00
   double precision :: be= 0.19003E+01
   double precision :: ga= 0.27812E+01
   double precision :: de= 0.11244E+00
   double precision :: g2= 0.12546E+00
   double precision :: lamF= 0.67467E+01
   double precision :: N4= 0.11413E+00
   double precision :: lam= 0.60541E-01

!  replica 296 (flav_dep 1)