   double precision :: N1d= 0.26063E+00
   double precision :: N1u= 0.26063E+00
   double precision :: N1s= 0.26063E+00
   double precision :: al= 0.29966E+01
   double precision :: si= 0.15365E+00
   double precision :: N3fv= 0.79841E+00
   double precision :: N3unfv= 0.79841E+00
   double precision :: N3Ks= 0.79841E+00
   double precision :: N3Ku= 0.79841E+00
   double precision :: be= 0.15059E+01
   double precision :: ga= 0.23005E+01
   double precision :: de= 0.14378E+00
   double precision :: g2= 0.13465E+00
   double precision :: lamF= 0.57305E+01
   double precision :: N4= 0.12668E+00
   double precision :: lam= 0.11612E+01

!  replica 191 (flav_dep 1)