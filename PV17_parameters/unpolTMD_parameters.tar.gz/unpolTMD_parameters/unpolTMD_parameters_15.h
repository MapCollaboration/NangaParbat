   double precision :: N1d= 0.23909E+00
   double precision :: N1u= 0.23909E+00
   double precision :: N1s= 0.23909E+00
   double precision :: al= 0.29973E+01
   double precision :: si= 0.15930E+00
   double precision :: N3fv= 2.00115E-01
   double precision :: N3unfv= 2.00115E-01
   double precision :: N3Ks= 2.00115E-01
   double precision :: N3Ku= 2.00115E-01
   double precision :: be= 0.18256E+01
   double precision :: ga= 0.28107E+01
   double precision :: de= 0.82941E-01
   double precision :: g2= 0.13154E+00
   double precision :: lamF= 0.59687E+01
   double precision :: N4= 3.18650E-02
   double precision :: lam= 0.25106E+01

!  replica 15 (flav_dep 1)