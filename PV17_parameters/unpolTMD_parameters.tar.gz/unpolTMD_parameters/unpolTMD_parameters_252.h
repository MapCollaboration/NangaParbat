   double precision :: N1d= 0.34484E+00
   double precision :: N1u= 0.34484E+00
   double precision :: N1s= 0.34484E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14210E+00
   double precision :: N3fv= 1.96983E-01
   double precision :: N3unfv= 1.96983E-01
   double precision :: N3Ks= 1.96983E-01
   double precision :: N3Ku= 1.96983E-01
   double precision :: be= 0.19362E+01
   double precision :: ga= 0.27296E+01
   double precision :: de= 0.10811E+00
   double precision :: g2= 0.13249E+00
   double precision :: lamF= 0.71427E+01
   double precision :: N4= 2.90350E-02
   double precision :: lam= 0.98718E-01

!  replica 252 (flav_dep 1)