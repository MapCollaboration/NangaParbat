   double precision :: N1d= 0.20764E+00
   double precision :: N1u= 0.20764E+00
   double precision :: N1s= 0.20764E+00
   double precision :: al= 0.29944E+01
   double precision :: si= 0.16774E+00
   double precision :: N3fv= 2.35865E-01
   double precision :: N3unfv= 2.35865E-01
   double precision :: N3Ks= 2.35865E-01
   double precision :: N3Ku= 2.35865E-01
   double precision :: be= 0.16966E+01
   double precision :: ga= 0.18508E+01
   double precision :: de= 0.13533E+00
   double precision :: g2= 0.12805E+00
   double precision :: lamF= 0.40166E+01
   double precision :: N4= 3.97075E-02
   double precision :: lam= 0.36497E+00

!  replica 245 (flav_dep 1)