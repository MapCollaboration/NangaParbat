   double precision :: N1d= 0.31214E+00
   double precision :: N1u= 0.31214E+00
   double precision :: N1s= 0.31214E+00
   double precision :: al= 0.14911E+01
   double precision :: si= 0.82613E-01
   double precision :: N3fv= 1.81540E-01
   double precision :: N3unfv= 1.81540E-01
   double precision :: N3Ks= 1.81540E-01
   double precision :: N3Ku= 1.81540E-01
   double precision :: be= 0.16260E+01
   double precision :: ga= 0.23185E+01
   double precision :: de= 0.10474E+00
   double precision :: g2= 0.13805E+00
   double precision :: lamF= 0.28258E+01
   double precision :: N4= 3.21425E-02
   double precision :: lam= 0.39106E+00

!  replica 175 (flav_dep 1)