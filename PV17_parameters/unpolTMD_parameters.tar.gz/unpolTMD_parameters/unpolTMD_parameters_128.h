   double precision :: N1d= 0.34352E+00
   double precision :: N1u= 0.34352E+00
   double precision :: N1s= 0.34352E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.18170E+00
   double precision :: N3fv= 2.06455E-01
   double precision :: N3unfv= 2.06455E-01
   double precision :: N3Ks= 2.06455E-01
   double precision :: N3Ku= 2.06455E-01
   double precision :: be= 0.14476E+01
   double precision :: ga= 0.21089E+01
   double precision :: de= 0.17056E+00
   double precision :: g2= 0.12152E+00
   double precision :: lamF= 0.58266E+01
   double precision :: N4= 3.17725E-02
   double precision :: lam= 0.44021E-01

!  replica 128 (flav_dep 1)