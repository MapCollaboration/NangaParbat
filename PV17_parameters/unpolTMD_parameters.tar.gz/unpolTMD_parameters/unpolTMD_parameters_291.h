   double precision :: N1d= 0.29284E+00
   double precision :: N1u= 0.29284E+00
   double precision :: N1s= 0.29284E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.16168E+00
   double precision :: N3fv= 0.87565E+00
   double precision :: N3unfv= 0.87565E+00
   double precision :: N3Ks= 0.87565E+00
   double precision :: N3Ku= 0.87565E+00
   double precision :: be= 0.18463E+01
   double precision :: ga= 0.24696E+01
   double precision :: de= 0.96354E-01
   double precision :: g2= 0.12127E+00
   double precision :: lamF= 0.58466E+01
   double precision :: N4= 0.13708E+00
   double precision :: lam= 0.29426E+00

!  replica 291 (flav_dep 1)