   double precision :: N1d= 0.31640E+00
   double precision :: N1u= 0.31640E+00
   double precision :: N1s= 0.31640E+00
   double precision :: al= 0.29617E+01
   double precision :: si= 0.14795E+00
   double precision :: N3fv= 1.91225E-01
   double precision :: N3unfv= 1.91225E-01
   double precision :: N3Ks= 1.91225E-01
   double precision :: N3Ku= 1.91225E-01
   double precision :: be= 0.11955E+01
   double precision :: ga= 0.21692E+01
   double precision :: de= 0.24030E+00
   double precision :: g2= 0.13159E+00
   double precision :: lamF= 0.71646E+01
   double precision :: N4= 2.88900E-02
   double precision :: lam= 0.42459E+00

!  replica 295 (flav_dep 1)