   double precision :: N1d= 0.19333E+00
   double precision :: N1u= 0.19333E+00
   double precision :: N1s= 0.19333E+00
   double precision :: al= 0.25682E+01
   double precision :: si= 0.15596E+00
   double precision :: N3fv= 2.29882E-01
   double precision :: N3unfv= 2.29882E-01
   double precision :: N3Ks= 2.29882E-01
   double precision :: N3Ku= 2.29882E-01
   double precision :: be= 0.14370E+01
   double precision :: ga= 0.18204E+01
   double precision :: de= 0.19796E+00
   double precision :: g2= 0.12530E+00
   double precision :: lamF= 0.56713E+01
   double precision :: N4= 3.55450E-02
   double precision :: lam= 0.32260E+01

!  replica 48 (flav_dep 1)