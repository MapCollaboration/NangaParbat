   double precision :: N1d= 0.26817E+00
   double precision :: N1u= 0.26817E+00
   double precision :: N1s= 0.26817E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.18466E+00
   double precision :: N3fv= 2.09680E-01
   double precision :: N3unfv= 2.09680E-01
   double precision :: N3Ks= 2.09680E-01
   double precision :: N3Ku= 2.09680E-01
   double precision :: be= 0.21594E+01
   double precision :: ga= 0.26712E+01
   double precision :: de= 0.86812E-01
   double precision :: g2= 0.12338E+00
   double precision :: lamF= 0.58172E+01
   double precision :: N4= 3.29025E-02
   double precision :: lam= 0.12898E+01

!  replica 259 (flav_dep 1)