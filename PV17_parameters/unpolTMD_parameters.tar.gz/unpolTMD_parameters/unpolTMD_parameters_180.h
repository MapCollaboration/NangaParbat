   double precision :: N1d= 0.29829E+00
   double precision :: N1u= 0.29829E+00
   double precision :: N1s= 0.29829E+00
   double precision :: al= 0.29913E+01
   double precision :: si= 0.14976E+00
   double precision :: N3fv= 2.00157E-01
   double precision :: N3unfv= 2.00157E-01
   double precision :: N3Ks= 2.00157E-01
   double precision :: N3Ku= 2.00157E-01
   double precision :: be= 0.12910E+01
   double precision :: ga= 0.22223E+01
   double precision :: de= 0.18806E+00
   double precision :: g2= 0.13251E+00
   double precision :: lamF= 0.71453E+01
   double precision :: N4= 2.97700E-02
   double precision :: lam= 0.50052E+00

!  replica 180 (flav_dep 1)