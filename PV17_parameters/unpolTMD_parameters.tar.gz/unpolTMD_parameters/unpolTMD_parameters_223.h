   double precision :: N1d= 0.34816E+00
   double precision :: N1u= 0.34816E+00
   double precision :: N1s= 0.34816E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.16301E+00
   double precision :: N3fv= 0.78347E+00
   double precision :: N3unfv= 0.78347E+00
   double precision :: N3Ks= 0.78347E+00
   double precision :: N3Ku= 0.78347E+00
   double precision :: be= 0.15816E+01
   double precision :: ga= 0.27432E+01
   double precision :: de= 0.10525E+00
   double precision :: g2= 0.13029E+00
   double precision :: lamF= 0.76732E+01
   double precision :: N4= 0.11660E+00
   double precision :: lam= 0.26126E+00

!  replica 223 (flav_dep 1)