   double precision :: N1d= 0.34816E+00
   double precision :: N1u= 0.34816E+00
   double precision :: N1s= 0.34816E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.16301E+00
   double precision :: N3fv= 1.95867E-01
   double precision :: N3unfv= 1.95867E-01
   double precision :: N3Ks= 1.95867E-01
   double precision :: N3Ku= 1.95867E-01
   double precision :: be= 0.15816E+01
   double precision :: ga= 0.27432E+01
   double precision :: de= 0.10525E+00
   double precision :: g2= 0.13029E+00
   double precision :: lamF= 0.76732E+01
   double precision :: N4= 2.91500E-02
   double precision :: lam= 0.26126E+00

!  replica 223 (flav_dep 1)