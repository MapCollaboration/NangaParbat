   double precision :: N1d= 0.32706E+00
   double precision :: N1u= 0.32706E+00
   double precision :: N1s= 0.32706E+00
   double precision :: al= 0.29995E+01
   double precision :: si= 0.18553E+00
   double precision :: N3fv= 2.17415E-01
   double precision :: N3unfv= 2.17415E-01
   double precision :: N3Ks= 2.17415E-01
   double precision :: N3Ku= 2.17415E-01
   double precision :: be= 0.15835E+01
   double precision :: ga= 0.19288E+01
   double precision :: de= 0.23670E+00
   double precision :: g2= 0.11199E+00
   double precision :: lamF= 0.63913E+01
   double precision :: N4= 3.22675E-02
   double precision :: lam= 0.87247E-01

!  replica 276 (flav_dep 1)