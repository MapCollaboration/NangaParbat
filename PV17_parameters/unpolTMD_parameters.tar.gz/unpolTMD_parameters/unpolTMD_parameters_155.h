   double precision :: N1d= 0.28964E+00
   double precision :: N1u= 0.28964E+00
   double precision :: N1s= 0.28964E+00
   double precision :: al= 0.29049E+01
   double precision :: si= 0.17655E+00
   double precision :: N3fv= 1.94935E-01
   double precision :: N3unfv= 1.94935E-01
   double precision :: N3Ks= 1.94935E-01
   double precision :: N3Ku= 1.94935E-01
   double precision :: be= 0.22804E+01
   double precision :: ga= 0.28443E+01
   double precision :: de= 0.92054E-01
   double precision :: g2= 0.13134E+00
   double precision :: lamF= 0.62778E+01
   double precision :: N4= 2.94000E-02
   double precision :: lam= 0.10571E+01

!  replica 155 (flav_dep 1)