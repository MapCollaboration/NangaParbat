   double precision :: N1d= 0.31268E+00
   double precision :: N1u= 0.31268E+00
   double precision :: N1s= 0.31268E+00
   double precision :: al= 0.29982E+01
   double precision :: si= 0.15699E+00
   double precision :: N3fv= 0.80923E+00
   double precision :: N3unfv= 0.80923E+00
   double precision :: N3Ks= 0.80923E+00
   double precision :: N3Ku= 0.80923E+00
   double precision :: be= 0.19609E+01
   double precision :: ga= 0.26508E+01
   double precision :: de= 0.10452E+00
   double precision :: g2= 0.12986E+00
   double precision :: lamF= 0.60986E+01
   double precision :: N4= 0.12646E+00
   double precision :: lam= 0.30924E+00

!  replica 70 (flav_dep 1)