   double precision :: N1d= 0.23006E+00
   double precision :: N1u= 0.23006E+00
   double precision :: N1s= 0.23006E+00
   double precision :: al= 0.28635E+01
   double precision :: si= 0.16931E+00
   double precision :: N3fv= 2.06065E-01
   double precision :: N3unfv= 2.06065E-01
   double precision :: N3Ks= 2.06065E-01
   double precision :: N3Ku= 2.06065E-01
   double precision :: be= 0.16414E+01
   double precision :: ga= 0.19592E+01
   double precision :: de= 0.24914E+00
   double precision :: g2= 0.13875E+00
   double precision :: lamF= 0.57716E+01
   double precision :: N4= 3.16600E-02
   double precision :: lam= 0.14164E+01

!  replica 267 (flav_dep 1)