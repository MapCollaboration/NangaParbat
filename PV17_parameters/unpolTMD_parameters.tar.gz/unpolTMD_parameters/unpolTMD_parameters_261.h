   double precision :: N1d= 0.29664E+00
   double precision :: N1u= 0.29664E+00
   double precision :: N1s= 0.29664E+00
   double precision :: al= 0.29849E+01
   double precision :: si= 0.19227E+00
   double precision :: N3fv= 0.77298E+00
   double precision :: N3unfv= 0.77298E+00
   double precision :: N3Ks= 0.77298E+00
   double precision :: N3Ku= 0.77298E+00
   double precision :: be= 0.47688E+00
   double precision :: ga= 0.15398E+01
   double precision :: de= 0.15922E+00
   double precision :: g2= 0.12362E+00
   double precision :: lamF= 0.59910E+01
   double precision :: N4= 0.11591E+00
   double precision :: lam= 0.95923E+00

!  replica 261 (flav_dep 1)