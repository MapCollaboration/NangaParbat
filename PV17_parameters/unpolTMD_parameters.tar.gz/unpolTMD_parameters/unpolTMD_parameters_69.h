   double precision :: N1d= 0.44749E+00
   double precision :: N1u= 0.44749E+00
   double precision :: N1s= 0.44749E+00
   double precision :: al= 0.29566E+01
   double precision :: si= 0.17804E+00
   double precision :: N3fv= 1.79355E-01
   double precision :: N3unfv= 1.79355E-01
   double precision :: N3Ks= 1.79355E-01
   double precision :: N3Ku= 1.79355E-01
   double precision :: be= 0.28100E+01
   double precision :: ga= 0.37703E+01
   double precision :: de= 0.46324E-01
   double precision :: g2= 0.12365E+00
   double precision :: lamF= 0.79904E+01
   double precision :: N4= 2.56575E-02
   double precision :: lam= 0.27562E-02

!  replica 69 (flav_dep 1)