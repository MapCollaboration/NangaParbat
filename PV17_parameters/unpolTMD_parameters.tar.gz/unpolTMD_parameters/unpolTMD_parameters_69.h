   double precision :: N1d= 0.44749E+00
   double precision :: N1u= 0.44749E+00
   double precision :: N1s= 0.44749E+00
   double precision :: al= 0.29566E+01
   double precision :: si= 0.17804E+00
   double precision :: N3fv= 0.71742E+00
   double precision :: N3unfv= 0.71742E+00
   double precision :: N3Ks= 0.71742E+00
   double precision :: N3Ku= 0.71742E+00
   double precision :: be= 0.28100E+01
   double precision :: ga= 0.37703E+01
   double precision :: de= 0.46324E-01
   double precision :: g2= 0.12365E+00
   double precision :: lamF= 0.79904E+01
   double precision :: N4= 0.10263E+00
   double precision :: lam= 0.27562E-02

!  replica 69 (flav_dep 1)