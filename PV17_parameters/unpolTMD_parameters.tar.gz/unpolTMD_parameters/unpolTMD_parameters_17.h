   double precision :: N1d= 0.29632E+00
   double precision :: N1u= 0.29632E+00
   double precision :: N1s= 0.29632E+00
   double precision :: al= 0.29809E+01
   double precision :: si= 0.17199E+00
   double precision :: N3fv= 1.98605E-01
   double precision :: N3unfv= 1.98605E-01
   double precision :: N3Ks= 1.98605E-01
   double precision :: N3Ku= 1.98605E-01
   double precision :: be= 0.13553E+01
   double precision :: ga= 0.25300E+01
   double precision :: de= 0.10122E+00
   double precision :: g2= 0.12332E+00
   double precision :: lamF= 0.66220E+01
   double precision :: N4= 3.04425E-02
   double precision :: lam= 0.89873E+00

!  replica 17 (flav_dep 1)