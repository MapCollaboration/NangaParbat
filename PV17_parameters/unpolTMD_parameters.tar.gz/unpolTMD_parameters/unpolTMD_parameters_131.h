   double precision :: N1d= 0.20448E+00
   double precision :: N1u= 0.20448E+00
   double precision :: N1s= 0.20448E+00
   double precision :: al= 0.29812E+01
   double precision :: si= 0.18390E+00
   double precision :: N3fv= 2.35767E-01
   double precision :: N3unfv= 2.35767E-01
   double precision :: N3Ks= 2.35767E-01
   double precision :: N3Ku= 2.35767E-01
   double precision :: be= 0.26064E+01
   double precision :: ga= 0.27729E+01
   double precision :: de= 0.50625E-01
   double precision :: g2= 0.12639E+00
   double precision :: lamF= 0.44958E+01
   double precision :: N4= 3.84500E-02
   double precision :: lam= 0.15837E+01

!  replica 131 (flav_dep 1)