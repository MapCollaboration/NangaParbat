   double precision :: N1d= 0.29684E+00
   double precision :: N1u= 0.29684E+00
   double precision :: N1s= 0.29684E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.18377E+00
   double precision :: N3fv= 2.11023E-01
   double precision :: N3unfv= 2.11023E-01
   double precision :: N3Ks= 2.11023E-01
   double precision :: N3Ku= 2.11023E-01
   double precision :: be= 0.17960E+01
   double precision :: ga= 0.21684E+01
   double precision :: de= 0.21485E+00
   double precision :: g2= 0.11718E+00
   double precision :: lamF= 0.73256E+01
   double precision :: N4= 3.05450E-02
   double precision :: lam= 0.84167E+00

!  replica 221 (flav_dep 1)