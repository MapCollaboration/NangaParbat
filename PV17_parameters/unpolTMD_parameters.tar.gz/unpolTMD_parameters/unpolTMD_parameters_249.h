   double precision :: N1d= 0.26177E+00
   double precision :: N1u= 0.26177E+00
   double precision :: N1s= 0.26177E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14454E+00
   double precision :: N3fv= 1.95972E-01
   double precision :: N3unfv= 1.95972E-01
   double precision :: N3Ks= 1.95972E-01
   double precision :: N3Ku= 1.95972E-01
   double precision :: be= 0.21440E+01
   double precision :: ga= 0.26891E+01
   double precision :: de= 0.83329E-01
   double precision :: g2= 0.14134E+00
   double precision :: lamF= 0.43972E+01
   double precision :: N4= 3.28550E-02
   double precision :: lam= 0.80275E+00

!  replica 249 (flav_dep 1)