   double precision :: N1d= 0.34636E+00
   double precision :: N1u= 0.34636E+00
   double precision :: N1s= 0.34636E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.15340E+00
   double precision :: N3fv= 1.79968E-01
   double precision :: N3unfv= 1.79968E-01
   double precision :: N3Ks= 1.79968E-01
   double precision :: N3Ku= 1.79968E-01
   double precision :: be= 0.10166E+01
   double precision :: ga= 0.25893E+01
   double precision :: de= 0.37440E-01
   double precision :: g2= 0.13019E+00
   double precision :: lamF= 0.60919E+01
   double precision :: N4= 2.85450E-02
   double precision :: lam= 0.29575E+00

!  replica 93 (flav_dep 1)