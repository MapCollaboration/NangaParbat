   double precision :: N1d= 0.21609E+00
   double precision :: N1u= 0.21609E+00
   double precision :: N1s= 0.21609E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.18269E+00
   double precision :: N3fv= 0.89851E+00
   double precision :: N3unfv= 0.89851E+00
   double precision :: N3Ks= 0.89851E+00
   double precision :: N3Ku= 0.89851E+00
   double precision :: be= 0.20328E+01
   double precision :: ga= 0.22562E+01
   double precision :: de= 0.11067E+00
   double precision :: g2= 0.13347E+00
   double precision :: lamF= 0.49777E+01
   double precision :: N4= 0.14228E+00
   double precision :: lam= 0.13983E+01

!  replica 250 (flav_dep 1)