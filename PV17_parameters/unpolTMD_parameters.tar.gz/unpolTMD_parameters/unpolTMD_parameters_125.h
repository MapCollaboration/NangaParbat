   double precision :: N1d= 0.36676E+00
   double precision :: N1u= 0.36676E+00
   double precision :: N1s= 0.36676E+00
   double precision :: al= 0.29987E+01
   double precision :: si= 0.19740E+00
   double precision :: N3fv= 1.95458E-01
   double precision :: N3unfv= 1.95458E-01
   double precision :: N3Ks= 1.95458E-01
   double precision :: N3Ku= 1.95458E-01
   double precision :: be= 0.14588E+01
   double precision :: ga= 0.25152E+01
   double precision :: de= 0.14336E+00
   double precision :: g2= 0.11656E+00
   double precision :: lamF= 0.74622E+01
   double precision :: N4= 2.86775E-02
   double precision :: lam= 0.33657E+00

!  replica 125 (flav_dep 1)