   double precision :: N1d= 0.22076E+00
   double precision :: N1u= 0.22076E+00
   double precision :: N1s= 0.22076E+00
   double precision :: al= 0.29559E+01
   double precision :: si= 0.19567E+00
   double precision :: N3fv= 2.21387E-01
   double precision :: N3unfv= 2.21387E-01
   double precision :: N3Ks= 2.21387E-01
   double precision :: N3Ku= 2.21387E-01
   double precision :: be= 0.98290E+00
   double precision :: ga= 0.13406E+01
   double precision :: de= 0.22271E+00
   double precision :: g2= 0.13295E+00
   double precision :: lamF= 0.37628E+01
   double precision :: N4= 3.57175E-02
   double precision :: lam= 0.36331E+00

!  replica 200 (flav_dep 1)