   double precision :: N1d= 0.37893E+00
   double precision :: N1u= 0.37893E+00
   double precision :: N1s= 0.37893E+00
   double precision :: al= 0.29982E+01
   double precision :: si= 0.17231E+00
   double precision :: N3fv= 0.72019E+00
   double precision :: N3unfv= 0.72019E+00
   double precision :: N3Ks= 0.72019E+00
   double precision :: N3Ku= 0.72019E+00
   double precision :: be= 0.17067E+01
   double precision :: ga= 0.26988E+01
   double precision :: de= 0.17612E+00
   double precision :: g2= 0.12630E+00
   double precision :: lamF= 0.82832E+01
   double precision :: N4= 0.10285E+00
   double precision :: lam= 0.37595E+00

!  replica 12 (flav_dep 1)