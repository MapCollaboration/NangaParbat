   double precision :: N1d= 0.11270E+00
   double precision :: N1u= 0.11270E+00
   double precision :: N1s= 0.11270E+00
   double precision :: al= 0.29914E+01
   double precision :: si= 0.14537E+00
   double precision :: N3fv= 2.40680E-01
   double precision :: N3unfv= 2.40680E-01
   double precision :: N3Ks= 2.40680E-01
   double precision :: N3Ku= 2.40680E-01
   double precision :: be= 0.16229E+01
   double precision :: ga= 0.17070E+01
   double precision :: de= 0.15877E+00
   double precision :: g2= 0.13222E+00
   double precision :: lamF= 0.40871E+01
   double precision :: N4= 4.01275E-02
   double precision :: lam= 0.14789E+02

!  replica 185 (flav_dep 1)