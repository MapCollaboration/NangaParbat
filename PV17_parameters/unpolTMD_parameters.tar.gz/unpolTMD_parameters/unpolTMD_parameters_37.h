   double precision :: N1d= 0.18802E+00
   double precision :: N1u= 0.18802E+00
   double precision :: N1s= 0.18802E+00
   double precision :: al= 0.21079E+01
   double precision :: si= 0.14016E+00
   double precision :: N3fv= 0.93173E+00
   double precision :: N3unfv= 0.93173E+00
   double precision :: N3Ks= 0.93173E+00
   double precision :: N3Ku= 0.93173E+00
   double precision :: be= 0.18720E+01
   double precision :: ga= 0.20154E+01
   double precision :: de= 0.12119E+00
   double precision :: g2= 0.12460E+00
   double precision :: lamF= 0.43129E+01
   double precision :: N4= 0.15131E+00
   double precision :: lam= 0.24198E+01

!  replica 37 (flav_dep 1)