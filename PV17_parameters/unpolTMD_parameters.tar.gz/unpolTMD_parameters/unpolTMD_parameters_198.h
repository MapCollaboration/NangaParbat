   double precision :: N1d= 0.18474E+00
   double precision :: N1u= 0.18474E+00
   double precision :: N1s= 0.18474E+00
   double precision :: al= 0.29896E+01
   double precision :: si= 0.17870E+00
   double precision :: N3fv= 2.27950E-01
   double precision :: N3unfv= 2.27950E-01
   double precision :: N3Ks= 2.27950E-01
   double precision :: N3Ku= 2.27950E-01
   double precision :: be= 0.17799E+01
   double precision :: ga= 0.20284E+01
   double precision :: de= 0.13518E+00
   double precision :: g2= 0.12171E+00
   double precision :: lamF= 0.48343E+01
   double precision :: N4= 3.58150E-02
   double precision :: lam= 0.41727E+01

!  replica 198 (flav_dep 1)