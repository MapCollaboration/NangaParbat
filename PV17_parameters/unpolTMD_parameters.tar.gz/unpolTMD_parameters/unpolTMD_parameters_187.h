   double precision :: N1d= 0.30402E+00
   double precision :: N1u= 0.30402E+00
   double precision :: N1s= 0.30402E+00
   double precision :: al= 0.29996E+01
   double precision :: si= 0.14920E+00
   double precision :: N3fv= 2.18408E-01
   double precision :: N3unfv= 2.18408E-01
   double precision :: N3Ks= 2.18408E-01
   double precision :: N3Ku= 2.18408E-01
   double precision :: be= 0.18923E+01
   double precision :: ga= 0.20327E+01
   double precision :: de= 0.28116E+00
   double precision :: g2= 0.11935E+00
   double precision :: lamF= 0.83410E+01
   double precision :: N4= 3.00750E-02
   double precision :: lam= 0.29875E+00

!  replica 187 (flav_dep 1)