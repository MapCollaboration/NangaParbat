   double precision :: N1d= 0.16756E+00
   double precision :: N1u= 0.16756E+00
   double precision :: N1s= 0.16756E+00
   double precision :: al= 0.29877E+01
   double precision :: si= 0.16667E+00
   double precision :: N3fv= 0.87342E+00
   double precision :: N3unfv= 0.87342E+00
   double precision :: N3Ks= 0.87342E+00
   double precision :: N3Ku= 0.87342E+00
   double precision :: be= 0.13806E+01
   double precision :: ga= 0.19627E+01
   double precision :: de= 0.99617E-01
   double precision :: g2= 0.13475E+00
   double precision :: lamF= 0.36844E+01
   double precision :: N4= 0.14766E+00
   double precision :: lam= 0.63048E+01

!  replica 108 (flav_dep 1)