   double precision :: N1d= 0.34184E+00
   double precision :: N1u= 0.34184E+00
   double precision :: N1s= 0.34184E+00
   double precision :: al= 0.29421E+01
   double precision :: si= 0.17030E+00
   double precision :: N3fv= 1.94018E-01
   double precision :: N3unfv= 1.94018E-01
   double precision :: N3Ks= 1.94018E-01
   double precision :: N3Ku= 1.94018E-01
   double precision :: be= 0.19654E+01
   double precision :: ga= 0.29749E+01
   double precision :: de= 0.82445E-01
   double precision :: g2= 0.12243E+00
   double precision :: lamF= 0.68024E+01
   double precision :: N4= 2.94025E-02
   double precision :: lam= 0.43879E+00

!  replica 197 (flav_dep 1)