   double precision :: N1d= 0.33621E+00
   double precision :: N1u= 0.33621E+00
   double precision :: N1s= 0.33621E+00
   double precision :: al= 0.29950E+01
   double precision :: si= 0.16170E+00
   double precision :: N3fv= 1.92420E-01
   double precision :: N3unfv= 1.92420E-01
   double precision :: N3Ks= 1.92420E-01
   double precision :: N3Ku= 1.92420E-01
   double precision :: be= 0.28480E+01
   double precision :: ga= 0.38511E+01
   double precision :: de= 0.32530E-01
   double precision :: g2= 0.12513E+00
   double precision :: lamF= 0.63610E+01
   double precision :: N4= 2.93825E-02
   double precision :: lam= 0.49113E+00

!  replica 3 (flav_dep 1)