   double precision :: N1d= 0.19846E+00
   double precision :: N1u= 0.19846E+00
   double precision :: N1s= 0.19846E+00
   double precision :: al= 0.29939E+01
   double precision :: si= 0.15043E+00
   double precision :: N3fv= 0.93740E+00
   double precision :: N3unfv= 0.93740E+00
   double precision :: N3Ks= 0.93740E+00
   double precision :: N3Ku= 0.93740E+00
   double precision :: be= 0.18606E+01
   double precision :: ga= 0.18070E+01
   double precision :: de= 0.20243E+00
   double precision :: g2= 0.12757E+00
   double precision :: lamF= 0.56230E+01
   double precision :: N4= 0.14123E+00
   double precision :: lam= 0.11693E+01

!  replica 33 (flav_dep 1)