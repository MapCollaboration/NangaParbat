   double precision :: N1d= 0.29486E+00
   double precision :: N1u= 0.29486E+00
   double precision :: N1s= 0.29486E+00
   double precision :: al= 0.29995E+01
   double precision :: si= 0.17038E+00
   double precision :: N3fv= 0.84490E+00
   double precision :: N3unfv= 0.84490E+00
   double precision :: N3Ks= 0.84490E+00
   double precision :: N3Ku= 0.84490E+00
   double precision :: be= 0.15200E+01
   double precision :: ga= 0.21556E+01
   double precision :: de= 0.11666E+00
   double precision :: g2= 0.12597E+00
   double precision :: lamF= 0.48240E+01
   double precision :: N4= 0.13433E+00
   double precision :: lam= 0.18146E+00

!  replica 178 (flav_dep 1)