   double precision :: N1d= 0.37077E+00
   double precision :: N1u= 0.37077E+00
   double precision :: N1s= 0.37077E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.18379E+00
   double precision :: N3fv= 1.96153E-01
   double precision :: N3unfv= 1.96153E-01
   double precision :: N3Ks= 1.96153E-01
   double precision :: N3Ku= 1.96153E-01
   double precision :: be= 0.12917E+01
   double precision :: ga= 0.24173E+01
   double precision :: de= 0.15714E+00
   double precision :: g2= 0.12227E+00
   double precision :: lamF= 0.78205E+01
   double precision :: N4= 2.84325E-02
   double precision :: lam= 0.17393E+00

!  replica 132 (flav_dep 1)