   double precision :: N1d= 0.30293E+00
   double precision :: N1u= 0.30293E+00
   double precision :: N1s= 0.30293E+00
   double precision :: al= 0.29277E+01
   double precision :: si= 0.16071E+00
   double precision :: N3fv= 2.17300E-01
   double precision :: N3unfv= 2.17300E-01
   double precision :: N3Ks= 2.17300E-01
   double precision :: N3Ku= 2.17300E-01
   double precision :: be= 0.13234E+01
   double precision :: ga= 0.19237E+01
   double precision :: de= 0.22148E+00
   double precision :: g2= 0.11277E+00
   double precision :: lamF= 0.66555E+01
   double precision :: N4= 3.24100E-02
   double precision :: lam= 0.39550E+00

!  replica 94 (flav_dep 1)