   double precision :: N1d= 0.37952E+00
   double precision :: N1u= 0.37952E+00
   double precision :: N1s= 0.37952E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.16070E+00
   double precision :: N3fv= 1.84450E-01
   double precision :: N3unfv= 1.84450E-01
   double precision :: N3Ks= 1.84450E-01
   double precision :: N3Ku= 1.84450E-01
   double precision :: be= 0.22970E+01
   double precision :: ga= 0.37434E+01
   double precision :: de= 0.52709E-01
   double precision :: g2= 0.12613E+00
   double precision :: lamF= 0.85943E+01
   double precision :: N4= 2.68475E-02
   double precision :: lam= 0.26640E+00

!  replica 7 (flav_dep 1)