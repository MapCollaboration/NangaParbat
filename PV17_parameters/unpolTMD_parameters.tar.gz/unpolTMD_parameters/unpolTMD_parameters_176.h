   double precision :: N1d= 0.22225E+00
   double precision :: N1u= 0.22225E+00
   double precision :: N1s= 0.22225E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.21014E+00
   double precision :: N3fv= 0.89895E+00
   double precision :: N3unfv= 0.89895E+00
   double precision :: N3Ks= 0.89895E+00
   double precision :: N3Ku= 0.89895E+00
   double precision :: be= 0.89203E+00
   double precision :: ga= 0.14429E+01
   double precision :: de= 0.24848E+00
   double precision :: g2= 0.12305E+00
   double precision :: lamF= 0.52148E+01
   double precision :: N4= 0.14301E+00
   double precision :: lam= 0.15012E+01

!  replica 176 (flav_dep 1)