   double precision :: N1d= 0.10198E+00
   double precision :: N1u= 0.10198E+00
   double precision :: N1s= 0.10198E+00
   double precision :: al= 0.25486E+01
   double precision :: si= 0.84717E-01
   double precision :: N3fv= 2.37437E-01
   double precision :: N3unfv= 2.37437E-01
   double precision :: N3Ks= 2.37437E-01
   double precision :: N3Ku= 2.37437E-01
   double precision :: be= 0.12541E+01
   double precision :: ga= 0.15941E+01
   double precision :: de= 0.22257E+00
   double precision :: g2= 0.14062E+00
   double precision :: lamF= 0.52585E+01
   double precision :: N4= 3.61275E-02
   double precision :: lam= 0.18856E+02

!  replica 216 (flav_dep 1)