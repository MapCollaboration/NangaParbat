   double precision :: N1d= 0.31432E+00
   double precision :: N1u= 0.31432E+00
   double precision :: N1s= 0.31432E+00
   double precision :: al= 0.29493E+01
   double precision :: si= 0.18922E+00
   double precision :: N3fv= 0.82677E+00
   double precision :: N3unfv= 0.82677E+00
   double precision :: N3Ks= 0.82677E+00
   double precision :: N3Ku= 0.82677E+00
   double precision :: be= 0.16266E+01
   double precision :: ga= 0.22038E+01
   double precision :: de= 0.13728E+00
   double precision :: g2= 0.12652E+00
   double precision :: lamF= 0.50907E+01
   double precision :: N4= 0.13124E+00
   double precision :: lam= 0.77299E-01

!  replica 254 (flav_dep 1)