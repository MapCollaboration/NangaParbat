   double precision :: N1d= 0.24863E+00
   double precision :: N1u= 0.24863E+00
   double precision :: N1s= 0.24863E+00
   double precision :: al= 0.29959E+01
   double precision :: si= 0.12448E+00
   double precision :: N3fv= 0.87291E+00
   double precision :: N3unfv= 0.87291E+00
   double precision :: N3Ks= 0.87291E+00
   double precision :: N3Ku= 0.87291E+00
   double precision :: be= 0.24365E+01
   double precision :: ga= 0.28367E+01
   double precision :: de= 0.57632E-01
   double precision :: g2= 0.13242E+00
   double precision :: lamF= 0.45547E+01
   double precision :: N4= 0.14252E+00
   double precision :: lam= 0.37491E+00

!  replica 79 (flav_dep 1)