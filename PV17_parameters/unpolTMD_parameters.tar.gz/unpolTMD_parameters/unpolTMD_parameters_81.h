   double precision :: N1d= 0.22152E+00
   double precision :: N1u= 0.22152E+00
   double precision :: N1s= 0.22152E+00
   double precision :: al= 0.29973E+01
   double precision :: si= 0.14857E+00
   double precision :: N3fv= 2.26065E-01
   double precision :: N3unfv= 2.26065E-01
   double precision :: N3Ks= 2.26065E-01
   double precision :: N3Ku= 2.26065E-01
   double precision :: be= 0.18398E+01
   double precision :: ga= 0.20382E+01
   double precision :: de= 0.10853E+00
   double precision :: g2= 0.13159E+00
   double precision :: lamF= 0.40033E+01
   double precision :: N4= 3.63775E-02
   double precision :: lam= 0.48528E+00

!  replica 81 (flav_dep 1)