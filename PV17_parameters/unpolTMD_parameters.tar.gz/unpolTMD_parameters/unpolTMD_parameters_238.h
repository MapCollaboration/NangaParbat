   double precision :: N1d= 0.25079E+00
   double precision :: N1u= 0.25079E+00
   double precision :: N1s= 0.25079E+00
   double precision :: al= 0.29819E+01
   double precision :: si= 0.15616E+00
   double precision :: N3fv= 0.78690E+00
   double precision :: N3unfv= 0.78690E+00
   double precision :: N3Ks= 0.78690E+00
   double precision :: N3Ku= 0.78690E+00
   double precision :: be= 0.12212E+01
   double precision :: ga= 0.25997E+01
   double precision :: de= 0.63904E-01
   double precision :: g2= 0.13207E+00
   double precision :: lamF= 0.66177E+01
   double precision :: N4= 0.12546E+00
   double precision :: lam= 0.24499E+01

!  replica 238 (flav_dep 1)