   double precision :: N1d= 0.28268E+00
   double precision :: N1u= 0.28268E+00
   double precision :: N1s= 0.28268E+00
   double precision :: al= 0.29588E+01
   double precision :: si= 0.16744E+00
   double precision :: N3fv= 2.12638E-01
   double precision :: N3unfv= 2.12638E-01
   double precision :: N3Ks= 2.12638E-01
   double precision :: N3Ku= 2.12638E-01
   double precision :: be= 0.12110E+01
   double precision :: ga= 0.18289E+01
   double precision :: de= 0.23663E+00
   double precision :: g2= 0.12641E+00
   double precision :: lamF= 0.59273E+01
   double precision :: N4= 3.28575E-02
   double precision :: lam= 0.34817E+00

!  replica 235 (flav_dep 1)