   double precision :: N1d= 0.39190E+00
   double precision :: N1u= 0.39190E+00
   double precision :: N1s= 0.39190E+00
   double precision :: al= 0.28925E+01
   double precision :: si= 0.15972E+00
   double precision :: N3fv= 0.69500E+00
   double precision :: N3unfv= 0.69500E+00
   double precision :: N3Ks= 0.69500E+00
   double precision :: N3Ku= 0.69500E+00
   double precision :: be= 0.15355E+01
   double precision :: ga= 0.28191E+01
   double precision :: de= 0.92118E-01
   double precision :: g2= 0.12919E+00
   double precision :: lamF= 0.54638E+01
   double precision :: N4= 0.11191E+00
   double precision :: lam= 0.11494E+00

!  replica 231 (flav_dep 1)