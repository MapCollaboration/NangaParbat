   double precision :: N1d= 0.25905E+00
   double precision :: N1u= 0.25905E+00
   double precision :: N1s= 0.25905E+00
   double precision :: al= 0.29964E+01
   double precision :: si= 0.17283E+00
   double precision :: N3fv= 2.01830E-01
   double precision :: N3unfv= 2.01830E-01
   double precision :: N3Ks= 2.01830E-01
   double precision :: N3Ku= 2.01830E-01
   double precision :: be= 0.11950E+01
   double precision :: ga= 0.23549E+01
   double precision :: de= 0.45075E-01
   double precision :: g2= 0.13226E+00
   double precision :: lamF= 0.46659E+01
   double precision :: N4= 3.44550E-02
   double precision :: lam= 0.12480E+01

!  replica 34 (flav_dep 1)