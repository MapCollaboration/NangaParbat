   double precision :: N1d= 0.32600E+00
   double precision :: N1u= 0.32600E+00
   double precision :: N1s= 0.32600E+00
   double precision :: al= 0.27960E+01
   double precision :: si= 0.18168E+00
   double precision :: N3fv= 2.15147E-01
   double precision :: N3unfv= 2.15147E-01
   double precision :: N3Ks= 2.15147E-01
   double precision :: N3Ku= 2.15147E-01
   double precision :: be= 0.14015E+01
   double precision :: ga= 0.19379E+01
   double precision :: de= 0.17144E+00
   double precision :: g2= 0.11253E+00
   double precision :: lamF= 0.50635E+01
   double precision :: N4= 3.42275E-02
   double precision :: lam= 0.18036E-01

!  replica 152 (flav_dep 1)