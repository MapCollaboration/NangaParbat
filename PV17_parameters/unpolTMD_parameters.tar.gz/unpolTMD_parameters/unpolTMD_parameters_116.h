   double precision :: N1d= 0.20153E+00
   double precision :: N1u= 0.20153E+00
   double precision :: N1s= 0.20153E+00
   double precision :: al= 0.24289E+01
   double precision :: si= 0.12838E+00
   double precision :: N3fv= 0.87582E+00
   double precision :: N3unfv= 0.87582E+00
   double precision :: N3Ks= 0.87582E+00
   double precision :: N3Ku= 0.87582E+00
   double precision :: be= 0.24250E+01
   double precision :: ga= 0.28473E+01
   double precision :: de= 0.49127E-01
   double precision :: g2= 0.13242E+00
   double precision :: lamF= 0.40483E+01
   double precision :: N4= 0.14215E+00
   double precision :: lam= 0.23976E+01

!  replica 116 (flav_dep 1)