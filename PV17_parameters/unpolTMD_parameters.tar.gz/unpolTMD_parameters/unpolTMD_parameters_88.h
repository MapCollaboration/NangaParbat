   double precision :: N1d= 0.21483E+00
   double precision :: N1u= 0.21483E+00
   double precision :: N1s= 0.21483E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.15111E+00
   double precision :: N3fv= 2.13732E-01
   double precision :: N3unfv= 2.13732E-01
   double precision :: N3Ks= 2.13732E-01
   double precision :: N3Ku= 2.13732E-01
   double precision :: be= 0.22620E+01
   double precision :: ga= 0.28294E+01
   double precision :: de= 0.65989E-01
   double precision :: g2= 0.13005E+00
   double precision :: lamF= 0.51938E+01
   double precision :: N4= 3.45000E-02
   double precision :: lam= 0.28931E+01

!  replica 88 (flav_dep 1)