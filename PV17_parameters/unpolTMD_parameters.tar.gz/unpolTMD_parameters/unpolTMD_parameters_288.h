   double precision :: N1d= 0.22628E+00
   double precision :: N1u= 0.22628E+00
   double precision :: N1s= 0.22628E+00
   double precision :: al= 0.29162E+01
   double precision :: si= 0.22028E+00
   double precision :: N3fv= 0.92255E+00
   double precision :: N3unfv= 0.92255E+00
   double precision :: N3Ks= 0.92255E+00
   double precision :: N3Ku= 0.92255E+00
   double precision :: be= 0.25064E+01
   double precision :: ga= 0.26340E+01
   double precision :: de= 0.58762E-01
   double precision :: g2= 0.14006E+00
   double precision :: lamF= 0.42189E+01
   double precision :: N4= 0.14880E+00
   double precision :: lam= 0.16952E-01

!  replica 288 (flav_dep 1)