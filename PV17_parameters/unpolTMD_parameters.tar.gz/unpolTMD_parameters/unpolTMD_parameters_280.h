   double precision :: N1d= 0.27672E+00
   double precision :: N1u= 0.27672E+00
   double precision :: N1s= 0.27672E+00
   double precision :: al= 0.29998E+01
   double precision :: si= 0.17387E+00
   double precision :: N3fv= 0.89786E+00
   double precision :: N3unfv= 0.89786E+00
   double precision :: N3Ks= 0.89786E+00
   double precision :: N3Ku= 0.89786E+00
   double precision :: be= 0.23143E+01
   double precision :: ga= 0.26264E+01
   double precision :: de= 0.78973E-01
   double precision :: g2= 0.12078E+00
   double precision :: lamF= 0.55921E+01
   double precision :: N4= 0.13890E+00
   double precision :: lam= 0.30645E+00

!  replica 280 (flav_dep 1)