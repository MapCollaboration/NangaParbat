   double precision :: N1d= 0.33487E+00
   double precision :: N1u= 0.33487E+00
   double precision :: N1s= 0.33487E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.18632E+00
   double precision :: N3fv= 2.00653E-01
   double precision :: N3unfv= 2.00653E-01
   double precision :: N3Ks= 2.00653E-01
   double precision :: N3Ku= 2.00653E-01
   double precision :: be= 0.17085E+01
   double precision :: ga= 0.24159E+01
   double precision :: de= 0.98665E-01
   double precision :: g2= 0.12670E+00
   double precision :: lamF= 0.43827E+01
   double precision :: N4= 3.36425E-02
   double precision :: lam= 0.26501E-02

!  replica 209 (flav_dep 1)