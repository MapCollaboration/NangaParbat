   double precision :: N1d= 0.37311E+00
   double precision :: N1u= 0.37311E+00
   double precision :: N1s= 0.37311E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.22803E+00
   double precision :: N3fv= 0.79144E+00
   double precision :: N3unfv= 0.79144E+00
   double precision :: N3Ks= 0.79144E+00
   double precision :: N3Ku= 0.79144E+00
   double precision :: be= 0.15311E+01
   double precision :: ga= 0.20770E+01
   double precision :: de= 0.15472E+00
   double precision :: g2= 0.11892E+00
   double precision :: lamF= 0.41179E+01
   double precision :: N4= 0.13200E+00
   double precision :: lam= 0.59834E-02

!  replica 236 (flav_dep 1)