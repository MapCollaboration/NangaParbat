   double precision :: N1d= 0.33363E+00
   double precision :: N1u= 0.33363E+00
   double precision :: N1s= 0.33363E+00
   double precision :: al= 0.29829E+01
   double precision :: si= 0.14199E+00
   double precision :: N3fv= 0.76018E+00
   double precision :: N3unfv= 0.76018E+00
   double precision :: N3Ks= 0.76018E+00
   double precision :: N3Ku= 0.76018E+00
   double precision :: be= 0.12520E+01
   double precision :: ga= 0.22068E+01
   double precision :: de= 0.24838E+00
   double precision :: g2= 0.13343E+00
   double precision :: lamF= 0.73693E+01
   double precision :: N4= 0.11263E+00
   double precision :: lam= 0.28710E+00

!  replica 292 (flav_dep 1)