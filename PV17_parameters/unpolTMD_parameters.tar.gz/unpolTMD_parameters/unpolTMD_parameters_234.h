   double precision :: N1d= 0.18756E+00
   double precision :: N1u= 0.18756E+00
   double precision :: N1s= 0.18756E+00
   double precision :: al= 0.26979E+01
   double precision :: si= 0.15693E+00
   double precision :: N3fv= 0.87519E+00
   double precision :: N3unfv= 0.87519E+00
   double precision :: N3Ks= 0.87519E+00
   double precision :: N3Ku= 0.87519E+00
   double precision :: be= 0.14171E+01
   double precision :: ga= 0.18754E+01
   double precision :: de= 0.22420E+00
   double precision :: g2= 0.13286E+00
   double precision :: lamF= 0.60782E+01
   double precision :: N4= 0.13199E+00
   double precision :: lam= 0.42061E+01

!  replica 234 (flav_dep 1)