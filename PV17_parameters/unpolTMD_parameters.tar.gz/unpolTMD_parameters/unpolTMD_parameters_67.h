   double precision :: N1d= 0.39379E+00
   double precision :: N1u= 0.39379E+00
   double precision :: N1s= 0.39379E+00
   double precision :: al= 0.29819E+01
   double precision :: si= 0.20712E+00
   double precision :: N3fv= 1.96410E-01
   double precision :: N3unfv= 1.96410E-01
   double precision :: N3Ks= 1.96410E-01
   double precision :: N3Ku= 1.96410E-01
   double precision :: be= 0.10596E+01
   double precision :: ga= 0.20876E+01
   double precision :: de= 0.27983E+00
   double precision :: g2= 0.11780E+00
   double precision :: lamF= 0.83666E+01
   double precision :: N4= 2.78400E-02
   double precision :: lam= 0.17339E+00

!  replica 67 (flav_dep 1)