   double precision :: N1d= 0.29643E+00
   double precision :: N1u= 0.29643E+00
   double precision :: N1s= 0.29643E+00
   double precision :: al= 0.28965E+01
   double precision :: si= 0.17324E+00
   double precision :: N3fv= 2.12245E-01
   double precision :: N3unfv= 2.12245E-01
   double precision :: N3Ks= 2.12245E-01
   double precision :: N3Ku= 2.12245E-01
   double precision :: be= 0.18111E+01
   double precision :: ga= 0.21233E+01
   double precision :: de= 0.15381E+00
   double precision :: g2= 0.12437E+00
   double precision :: lamF= 0.50713E+01
   double precision :: N4= 3.40350E-02
   double precision :: lam= 0.31706E+00

!  replica 18 (flav_dep 1)