   double precision :: N1d= 0.16923E+00
   double precision :: N1u= 0.16923E+00
   double precision :: N1s= 0.16923E+00
   double precision :: al= 0.29124E+01
   double precision :: si= 0.18710E+00
   double precision :: N3fv= 2.29272E-01
   double precision :: N3unfv= 2.29272E-01
   double precision :: N3Ks= 2.29272E-01
   double precision :: N3Ku= 2.29272E-01
   double precision :: be= 0.10189E+01
   double precision :: ga= 0.13401E+01
   double precision :: de= 0.23368E+00
   double precision :: g2= 0.12694E+00
   double precision :: lamF= 0.41096E+01
   double precision :: N4= 3.76400E-02
   double precision :: lam= 0.36925E+01

!  replica 239 (flav_dep 1)