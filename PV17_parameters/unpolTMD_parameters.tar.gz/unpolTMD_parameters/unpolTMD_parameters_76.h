   double precision :: N1d= 0.20736E+00
   double precision :: N1u= 0.20736E+00
   double precision :: N1s= 0.20736E+00
   double precision :: al= 0.29561E+01
   double precision :: si= 0.17821E+00
   double precision :: N3fv= 0.88560E+00
   double precision :: N3unfv= 0.88560E+00
   double precision :: N3Ks= 0.88560E+00
   double precision :: N3Ku= 0.88560E+00
   double precision :: be= 0.14547E+01
   double precision :: ga= 0.18656E+01
   double precision :: de= 0.10501E+00
   double precision :: g2= 0.14192E+00
   double precision :: lamF= 0.30406E+01
   double precision :: N4= 0.15260E+00
   double precision :: lam= 0.25734E+00

!  replica 76 (flav_dep 1)