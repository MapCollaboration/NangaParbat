   double precision :: N1d= 0.29700E+00
   double precision :: N1u= 0.29700E+00
   double precision :: N1s= 0.29700E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.17034E+00
   double precision :: N3fv= 0.76736E+00
   double precision :: N3unfv= 0.76736E+00
   double precision :: N3Ks= 0.76736E+00
   double precision :: N3Ku= 0.76736E+00
   double precision :: be= 0.11665E+01
   double precision :: ga= 0.25070E+01
   double precision :: de= 0.75967E-01
   double precision :: g2= 0.13177E+00
   double precision :: lamF= 0.63266E+01
   double precision :: N4= 0.12081E+00
   double precision :: lam= 0.93157E+00

!  replica 90 (flav_dep 1)