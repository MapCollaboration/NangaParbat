   double precision :: N1d= 0.22175E+00
   double precision :: N1u= 0.22175E+00
   double precision :: N1s= 0.22175E+00
   double precision :: al= 0.29625E+01
   double precision :: si= 0.14490E+00
   double precision :: N3fv= 0.91503E+00
   double precision :: N3unfv= 0.91503E+00
   double precision :: N3Ks= 0.91503E+00
   double precision :: N3Ku= 0.91503E+00
   double precision :: be= 0.17627E+01
   double precision :: ga= 0.20634E+01
   double precision :: de= 0.10573E+00
   double precision :: g2= 0.13112E+00
   double precision :: lamF= 0.41657E+01
   double precision :: N4= 0.15086E+00
   double precision :: lam= 0.28845E+00

!  replica 84 (flav_dep 1)