   double precision :: N1d= 0.33166E+00
   double precision :: N1u= 0.33166E+00
   double precision :: N1s= 0.33166E+00
   double precision :: al= 0.29958E+01
   double precision :: si= 0.17466E+00
   double precision :: N3fv= 0.79341E+00
   double precision :: N3unfv= 0.79341E+00
   double precision :: N3Ks= 0.79341E+00
   double precision :: N3Ku= 0.79341E+00
   double precision :: be= 0.12613E+01
   double precision :: ga= 0.22062E+01
   double precision :: de= 0.21326E+00
   double precision :: g2= 0.12506E+00
   double precision :: lamF= 0.72419E+01
   double precision :: N4= 0.11747E+00
   double precision :: lam= 0.37854E+00

!  replica 1 (flav_dep 1)