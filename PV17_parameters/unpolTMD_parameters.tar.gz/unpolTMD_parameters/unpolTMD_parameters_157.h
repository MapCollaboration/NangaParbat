   double precision :: N1d= 0.30794E+00
   double precision :: N1u= 0.30794E+00
   double precision :: N1s= 0.30794E+00
   double precision :: al= 0.29996E+01
   double precision :: si= 0.14766E+00
   double precision :: N3fv= 0.83890E+00
   double precision :: N3unfv= 0.83890E+00
   double precision :: N3Ks= 0.83890E+00
   double precision :: N3Ku= 0.83890E+00
   double precision :: be= 0.10493E+01
   double precision :: ga= 0.18781E+01
   double precision :: de= 0.21522E+00
   double precision :: g2= 0.13040E+00
   double precision :: lamF= 0.65281E+01
   double precision :: N4= 0.12638E+00
   double precision :: lam= 0.97559E-01

!  replica 157 (flav_dep 1)