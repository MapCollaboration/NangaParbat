   double precision :: N1d= 0.22269E+00
   double precision :: N1u= 0.22269E+00
   double precision :: N1s= 0.22269E+00
   double precision :: al= 0.29948E+01
   double precision :: si= 0.18095E+00
   double precision :: N3fv= 2.36127E-01
   double precision :: N3unfv= 2.36127E-01
   double precision :: N3Ks= 2.36127E-01
   double precision :: N3Ku= 2.36127E-01
   double precision :: be= 0.21936E+01
   double precision :: ga= 0.22321E+01
   double precision :: de= 0.82786E-01
   double precision :: g2= 0.12559E+00
   double precision :: lamF= 0.37181E+01
   double precision :: N4= 3.95925E-02
   double precision :: lam= 0.46098E-01

!  replica 71 (flav_dep 1)