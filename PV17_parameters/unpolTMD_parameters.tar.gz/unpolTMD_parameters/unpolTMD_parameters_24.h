   double precision :: N1d= 0.28886E+00
   double precision :: N1u= 0.28886E+00
   double precision :: N1s= 0.28886E+00
   double precision :: al= 0.29987E+01
   double precision :: si= 0.16173E+00
   double precision :: N3fv= 2.13322E-01
   double precision :: N3unfv= 2.13322E-01
   double precision :: N3Ks= 2.13322E-01
   double precision :: N3Ku= 2.13322E-01
   double precision :: be= 0.21363E+01
   double precision :: ga= 0.26507E+01
   double precision :: de= 0.75864E-01
   double precision :: g2= 0.12794E+00
   double precision :: lamF= 0.49357E+01
   double precision :: N4= 3.35850E-02
   double precision :: lam= 0.13736E+00

!  replica 24 (flav_dep 1)