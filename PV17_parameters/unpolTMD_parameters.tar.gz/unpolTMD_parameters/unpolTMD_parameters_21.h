   double precision :: N1d= 0.28749E+00
   double precision :: N1u= 0.28749E+00
   double precision :: N1s= 0.28749E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.19156E+00
   double precision :: N3fv= 0.79060E+00
   double precision :: N3unfv= 0.79060E+00
   double precision :: N3Ks= 0.79060E+00
   double precision :: N3Ku= 0.79060E+00
   double precision :: be= 0.12010E+01
   double precision :: ga= 0.21816E+01
   double precision :: de= 0.17859E+00
   double precision :: g2= 0.12184E+00
   double precision :: lamF= 0.67090E+01
   double precision :: N4= 0.12032E+00
   double precision :: lam= 0.13933E+01

!  replica 21 (flav_dep 1)