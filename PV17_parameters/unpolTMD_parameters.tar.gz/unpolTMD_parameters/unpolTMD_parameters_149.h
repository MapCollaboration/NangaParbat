   double precision :: N1d= 0.20196E+00
   double precision :: N1u= 0.20196E+00
   double precision :: N1s= 0.20196E+00
   double precision :: al= 0.29959E+01
   double precision :: si= 0.11543E+00
   double precision :: N3fv= 0.96047E+00
   double precision :: N3unfv= 0.96047E+00
   double precision :: N3Ks= 0.96047E+00
   double precision :: N3Ku= 0.96047E+00
   double precision :: be= 0.17679E+01
   double precision :: ga= 0.19449E+01
   double precision :: de= 0.11659E+00
   double precision :: g2= 0.13090E+00
   double precision :: lamF= 0.43877E+01
   double precision :: N4= 0.15816E+00
   double precision :: lam= 0.88320E-01

!  replica 149 (flav_dep 1)