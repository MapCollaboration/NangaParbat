   double precision :: N1d= 0.20196E+00
   double precision :: N1u= 0.20196E+00
   double precision :: N1s= 0.20196E+00
   double precision :: al= 0.29959E+01
   double precision :: si= 0.11543E+00
   double precision :: N3fv= 2.40118E-01
   double precision :: N3unfv= 2.40118E-01
   double precision :: N3Ks= 2.40118E-01
   double precision :: N3Ku= 2.40118E-01
   double precision :: be= 0.17679E+01
   double precision :: ga= 0.19449E+01
   double precision :: de= 0.11659E+00
   double precision :: g2= 0.13090E+00
   double precision :: lamF= 0.43877E+01
   double precision :: N4= 3.95400E-02
   double precision :: lam= 0.88320E-01

!  replica 149 (flav_dep 1)