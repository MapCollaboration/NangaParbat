   double precision :: N1d= 0.29775E+00
   double precision :: N1u= 0.29775E+00
   double precision :: N1s= 0.29775E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.22757E+00
   double precision :: N3fv= 2.10380E-01
   double precision :: N3unfv= 2.10380E-01
   double precision :: N3Ks= 2.10380E-01
   double precision :: N3Ku= 2.10380E-01
   double precision :: be= 0.16319E+01
   double precision :: ga= 0.23181E+01
   double precision :: de= 0.12685E+00
   double precision :: g2= 0.11142E+00
   double precision :: lamF= 0.60037E+01
   double precision :: N4= 3.22825E-02
   double precision :: lam= 0.11181E+01

!  replica 215 (flav_dep 1)