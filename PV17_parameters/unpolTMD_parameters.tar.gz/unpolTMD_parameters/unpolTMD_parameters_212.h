   double precision :: N1d= 0.22313E+00
   double precision :: N1u= 0.22313E+00
   double precision :: N1s= 0.22313E+00
   double precision :: al= 0.29674E+01
   double precision :: si= 0.13564E+00
   double precision :: N3fv= 2.28148E-01
   double precision :: N3unfv= 2.28148E-01
   double precision :: N3Ks= 2.28148E-01
   double precision :: N3Ku= 2.28148E-01
   double precision :: be= 0.11937E+01
   double precision :: ga= 0.17106E+01
   double precision :: de= 0.15245E+00
   double precision :: g2= 0.13136E+00
   double precision :: lamF= 0.48003E+01
   double precision :: N4= 3.63050E-02
   double precision :: lam= 0.29320E+00

!  replica 212 (flav_dep 1)