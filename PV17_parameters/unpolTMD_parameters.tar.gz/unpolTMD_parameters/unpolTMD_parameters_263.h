   double precision :: N1d= 0.21908E+00
   double precision :: N1u= 0.21908E+00
   double precision :: N1s= 0.21908E+00
   double precision :: al= 0.29995E+01
   double precision :: si= 0.22034E+00
   double precision :: N3fv= 0.89282E+00
   double precision :: N3unfv= 0.89282E+00
   double precision :: N3Ks= 0.89282E+00
   double precision :: N3Ku= 0.89282E+00
   double precision :: be= 0.95446E+00
   double precision :: ga= 0.16467E+01
   double precision :: de= 0.16865E+00
   double precision :: g2= 0.12252E+00
   double precision :: lamF= 0.55302E+01
   double precision :: N4= 0.13819E+00
   double precision :: lam= 0.20747E+01

!  replica 263 (flav_dep 1)