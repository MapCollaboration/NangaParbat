   double precision :: N1d= 0.26058E+00
   double precision :: N1u= 0.26058E+00
   double precision :: N1s= 0.26058E+00
   double precision :: al= 0.27673E+01
   double precision :: si= 0.17712E+00
   double precision :: N3fv= 2.16817E-01
   double precision :: N3unfv= 2.16817E-01
   double precision :: N3Ks= 2.16817E-01
   double precision :: N3Ku= 2.16817E-01
   double precision :: be= 0.71116E+00
   double precision :: ga= 0.16239E+01
   double precision :: de= 0.14516E+00
   double precision :: g2= 0.11868E+00
   double precision :: lamF= 0.62438E+01
   double precision :: N4= 3.29050E-02
   double precision :: lam= 0.13785E+01

!  replica 203 (flav_dep 1)