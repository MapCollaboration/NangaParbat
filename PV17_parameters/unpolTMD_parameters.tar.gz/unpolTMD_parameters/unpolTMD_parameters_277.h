   double precision :: N1d= 0.19269E+00
   double precision :: N1u= 0.19269E+00
   double precision :: N1s= 0.19269E+00
   double precision :: al= 0.29992E+01
   double precision :: si= 0.14355E+00
   double precision :: N3fv= 0.89259E+00
   double precision :: N3unfv= 0.89259E+00
   double precision :: N3Ks= 0.89259E+00
   double precision :: N3Ku= 0.89259E+00
   double precision :: be= 0.14853E+01
   double precision :: ga= 0.19442E+01
   double precision :: de= 0.16711E+00
   double precision :: g2= 0.13208E+00
   double precision :: lamF= 0.54848E+01
   double precision :: N4= 0.14240E+00
   double precision :: lam= 0.31150E+01

!  replica 277 (flav_dep 1)