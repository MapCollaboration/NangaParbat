   double precision :: N1d= 0.31310E+00
   double precision :: N1u= 0.31310E+00
   double precision :: N1s= 0.31310E+00
   double precision :: al= 0.29908E+01
   double precision :: si= 0.17942E+00
   double precision :: N3fv= 0.85176E+00
   double precision :: N3unfv= 0.85176E+00
   double precision :: N3Ks= 0.85176E+00
   double precision :: N3Ku= 0.85176E+00
   double precision :: be= 0.21407E+01
   double precision :: ga= 0.28750E+01
   double precision :: de= 0.75105E-01
   double precision :: g2= 0.12199E+00
   double precision :: lamF= 0.66148E+01
   double precision :: N4= 0.12962E+00
   double precision :: lam= 0.49581E+00

!  replica 196 (flav_dep 1)