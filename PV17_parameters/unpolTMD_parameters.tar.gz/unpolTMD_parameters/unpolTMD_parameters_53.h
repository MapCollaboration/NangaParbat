   double precision :: N1d= 0.40673E+00
   double precision :: N1u= 0.40673E+00
   double precision :: N1s= 0.40673E+00
   double precision :: al= 0.29997E+01
   double precision :: si= 0.14989E+00
   double precision :: N3fv= 0.71441E+00
   double precision :: N3unfv= 0.71441E+00
   double precision :: N3Ks= 0.71441E+00
   double precision :: N3Ku= 0.71441E+00
   double precision :: be= 0.30286E+01
   double precision :: ga= 0.42877E+01
   double precision :: de= 0.25766E-01
   double precision :: g2= 0.13134E+00
   double precision :: lamF= 0.70029E+01
   double precision :: N4= 0.10966E+00
   double precision :: lam= 0.14287E+00

!  replica 53 (flav_dep 1)