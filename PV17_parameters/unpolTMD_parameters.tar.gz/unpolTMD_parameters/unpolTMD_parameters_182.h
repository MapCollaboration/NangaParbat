   double precision :: N1d= 0.32525E+00
   double precision :: N1u= 0.32525E+00
   double precision :: N1s= 0.32525E+00
   double precision :: al= 0.29983E+01
   double precision :: si= 0.18697E+00
   double precision :: N3fv= 1.91680E-01
   double precision :: N3unfv= 1.91680E-01
   double precision :: N3Ks= 1.91680E-01
   double precision :: N3Ku= 1.91680E-01
   double precision :: be= 0.21724E+01
   double precision :: ga= 0.31477E+01
   double precision :: de= 0.78634E-01
   double precision :: g2= 0.12004E+00
   double precision :: lamF= 0.74288E+01
   double precision :: N4= 2.79825E-02
   double precision :: lam= 0.98224E+00

!  replica 182 (flav_dep 1)