   double precision :: N1d= 0.30183E+00
   double precision :: N1u= 0.30183E+00
   double precision :: N1s= 0.30183E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14394E+00
   double precision :: N3fv= 2.05703E-01
   double precision :: N3unfv= 2.05703E-01
   double precision :: N3Ks= 2.05703E-01
   double precision :: N3Ku= 2.05703E-01
   double precision :: be= 0.99726E+00
   double precision :: ga= 0.21189E+01
   double precision :: de= 0.10625E+00
   double precision :: g2= 0.12514E+00
   double precision :: lamF= 0.65778E+01
   double precision :: N4= 3.15900E-02
   double precision :: lam= 0.47624E+00

!  replica 45 (flav_dep 1)