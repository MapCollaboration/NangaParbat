   double precision :: N1d= 0.24281E+00
   double precision :: N1u= 0.24281E+00
   double precision :: N1s= 0.24281E+00
   double precision :: al= 0.29441E+01
   double precision :: si= 0.20002E+00
   double precision :: N3fv= 0.86466E+00
   double precision :: N3unfv= 0.86466E+00
   double precision :: N3Ks= 0.86466E+00
   double precision :: N3Ku= 0.86466E+00
   double precision :: be= 0.25347E+01
   double precision :: ga= 0.29715E+01
   double precision :: de= 0.62637E-01
   double precision :: g2= 0.11930E+00
   double precision :: lamF= 0.63357E+01
   double precision :: N4= 0.13141E+00
   double precision :: lam= 0.30009E+01

!  replica 298 (flav_dep 1)