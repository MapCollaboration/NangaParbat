   double precision :: N1d= 0.24824E+00
   double precision :: N1u= 0.24824E+00
   double precision :: N1s= 0.24824E+00
   double precision :: al= 0.29742E+01
   double precision :: si= 0.16752E+00
   double precision :: N3fv= 2.06280E-01
   double precision :: N3unfv= 2.06280E-01
   double precision :: N3Ks= 2.06280E-01
   double precision :: N3Ku= 2.06280E-01
   double precision :: be= 0.22260E+01
   double precision :: ga= 0.26393E+01
   double precision :: de= 0.52440E-01
   double precision :: g2= 0.14348E+00
   double precision :: lamF= 0.23171E+01
   double precision :: N4= 3.80900E-02
   double precision :: lam= 0.23457E+00

!  replica 189 (flav_dep 1)