   double precision :: N1d= 0.33009E+00
   double precision :: N1u= 0.33009E+00
   double precision :: N1s= 0.33009E+00
   double precision :: al= 0.29985E+01
   double precision :: si= 0.15849E+00
   double precision :: N3fv= 1.89925E-01
   double precision :: N3unfv= 1.89925E-01
   double precision :: N3Ks= 1.89925E-01
   double precision :: N3Ku= 1.89925E-01
   double precision :: be= 0.12664E+01
   double precision :: ga= 0.23379E+01
   double precision :: de= 0.22661E+00
   double precision :: g2= 0.12973E+00
   double precision :: lamF= 0.81979E+01
   double precision :: N4= 2.69275E-02
   double precision :: lam= 0.47500E+00

!  replica 91 (flav_dep 1)