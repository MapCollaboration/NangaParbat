   double precision :: N1d= 0.32709E+00
   double precision :: N1u= 0.32709E+00
   double precision :: N1s= 0.32709E+00
   double precision :: al= 0.29994E+01
   double precision :: si= 0.19180E+00
   double precision :: N3fv= 1.96005E-01
   double precision :: N3unfv= 1.96005E-01
   double precision :: N3Ks= 1.96005E-01
   double precision :: N3Ku= 1.96005E-01
   double precision :: be= 0.15195E+01
   double precision :: ga= 0.24815E+01
   double precision :: de= 0.95971E-01
   double precision :: g2= 0.13444E+00
   double precision :: lamF= 0.52950E+01
   double precision :: N4= 3.13375E-02
   double precision :: lam= 0.21653E+00

!  replica 247 (flav_dep 1)