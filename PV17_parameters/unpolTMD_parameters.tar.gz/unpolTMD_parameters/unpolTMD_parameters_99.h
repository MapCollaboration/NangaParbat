   double precision :: N1d= 0.24782E+00
   double precision :: N1u= 0.24782E+00
   double precision :: N1s= 0.24782E+00
   double precision :: al= 0.29987E+01
   double precision :: si= 0.16066E+00
   double precision :: N3fv= 2.03528E-01
   double precision :: N3unfv= 2.03528E-01
   double precision :: N3Ks= 2.03528E-01
   double precision :: N3Ku= 2.03528E-01
   double precision :: be= 0.18011E+01
   double precision :: ga= 0.26543E+01
   double precision :: de= 0.74643E-01
   double precision :: g2= 0.12703E+00
   double precision :: lamF= 0.49631E+01
   double precision :: N4= 3.26700E-02
   double precision :: lam= 0.16642E+01

!  replica 99 (flav_dep 1)