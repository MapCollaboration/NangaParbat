   double precision :: N1d= 0.19857E+00
   double precision :: N1u= 0.19857E+00
   double precision :: N1s= 0.19857E+00
   double precision :: al= 0.29999E+01
   double precision :: si= 0.21695E+00
   double precision :: N3fv= 0.89999E+00
   double precision :: N3unfv= 0.89999E+00
   double precision :: N3Ks= 0.89999E+00
   double precision :: N3Ku= 0.89999E+00
   double precision :: be= 0.25649E+01
   double precision :: ga= 0.29344E+01
   double precision :: de= 0.51196E-01
   double precision :: g2= 0.11929E+00
   double precision :: lamF= 0.48336E+01
   double precision :: N4= 0.14311E+00
   double precision :: lam= 0.52221E+01

!  replica 264 (flav_dep 1)