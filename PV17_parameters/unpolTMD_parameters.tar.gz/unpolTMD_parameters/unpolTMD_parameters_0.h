   double precision :: N1d=  0.28000E+00
   double precision :: N1u=  0.28000E+00
   double precision :: N1s=  0.28000E+00
   double precision :: al= 0.29500+01
   double precision :: si= 0.17000E+00
   double precision :: N3fv= 5.25000E-02
   double precision :: N3unfv= 5.25000E-02
   double precision :: N3Ks= 5.25000E-02
   double precision :: N3Ku= 5.25000E-02
   double precision :: be= 0.16500E+01
   double precision :: ga= 0.22800E+01
   double precision :: de= 0.14000E+00
   double precision :: g2= 0.12506E+00
   double precision :: lamF= 0.55000E+01
   double precision :: N4= 3.25000E-02
   double precision :: lam= 0.86000E+00

!  replica 0: best fit parameters (flav_dep 1)
