   double precision :: N1d= 0.28332E+00
   double precision :: N1u= 0.28332E+00
   double precision :: N1s= 0.28332E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.12474E+00
   double precision :: N3fv= 2.09473E-01
   double precision :: N3unfv= 2.09473E-01
   double precision :: N3Ks= 2.09473E-01
   double precision :: N3Ku= 2.09473E-01
   double precision :: be= 0.13080E+01
   double precision :: ga= 0.21199E+01
   double precision :: de= 0.94452E-01
   double precision :: g2= 0.13455E+00
   double precision :: lamF= 0.45327E+01
   double precision :: N4= 3.49425E-02
   double precision :: lam= 0.12631E-02

!  replica 50 (flav_dep 1)