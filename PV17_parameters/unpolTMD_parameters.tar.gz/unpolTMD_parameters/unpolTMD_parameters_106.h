   double precision :: N1d= 0.39460E+00
   double precision :: N1u= 0.39460E+00
   double precision :: N1s= 0.39460E+00
   double precision :: al= 0.29452E+01
   double precision :: si= 0.12866E+00
   double precision :: N3fv= 0.73419E+00
   double precision :: N3unfv= 0.73419E+00
   double precision :: N3Ks= 0.73419E+00
   double precision :: N3Ku= 0.73419E+00
   double precision :: be= 0.11288E+01
   double precision :: ga= 0.25909E+01
   double precision :: de= 0.20111E+00
   double precision :: g2= 0.12856E+00
   double precision :: lamF= 0.10112E+02
   double precision :: N4= 0.97888E-01
   double precision :: lam= 0.66105E-01

!  replica 106 (flav_dep 1)