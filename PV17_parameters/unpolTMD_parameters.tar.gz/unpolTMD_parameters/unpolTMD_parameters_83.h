   double precision :: N1d= 0.25868E+00
   double precision :: N1u= 0.25868E+00
   double precision :: N1s= 0.25868E+00
   double precision :: al= 0.28882E+01
   double precision :: si= 0.92731E-01
   double precision :: N3fv= 2.09650E-01
   double precision :: N3unfv= 2.09650E-01
   double precision :: N3Ks= 2.09650E-01
   double precision :: N3Ku= 2.09650E-01
   double precision :: be= 0.15829E+01
   double precision :: ga= 0.20382E+01
   double precision :: de= 0.22960E+00
   double precision :: g2= 0.14111E+00
   double precision :: lamF= 0.63547E+01
   double precision :: N4= 3.21900E-02
   double precision :: lam= 0.25215E+00

!  replica 83 (flav_dep 1)