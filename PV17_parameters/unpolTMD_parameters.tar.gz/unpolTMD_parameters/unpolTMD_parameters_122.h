   double precision :: N1d= 0.30842E+00
   double precision :: N1u= 0.30842E+00
   double precision :: N1s= 0.30842E+00
   double precision :: al= 0.29418E+01
   double precision :: si= 0.17737E+00
   double precision :: N3fv= 1.99272E-01
   double precision :: N3unfv= 1.99272E-01
   double precision :: N3Ks= 1.99272E-01
   double precision :: N3Ku= 1.99272E-01
   double precision :: be= 0.95177E+00
   double precision :: ga= 0.18331E+01
   double precision :: de= 0.26696E+00
   double precision :: g2= 0.13182E+00
   double precision :: lamF= 0.65141E+01
   double precision :: N4= 3.01800E-02
   double precision :: lam= 0.36065E+00

!  replica 122 (flav_dep 1)