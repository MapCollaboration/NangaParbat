   double precision :: N1d= 0.34279E+00
   double precision :: N1u= 0.34279E+00
   double precision :: N1s= 0.34279E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.13796E+00
   double precision :: N3fv= 0.80192E+00
   double precision :: N3unfv= 0.80192E+00
   double precision :: N3Ks= 0.80192E+00
   double precision :: N3Ku= 0.80192E+00
   double precision :: be= 0.11945E+01
   double precision :: ga= 0.21728E+01
   double precision :: de= 0.20764E+00
   double precision :: g2= 0.12956E+00
   double precision :: lamF= 0.72764E+01
   double precision :: N4= 0.12049E+00
   double precision :: lam= 0.43928E-01

!  replica 151 (flav_dep 1)