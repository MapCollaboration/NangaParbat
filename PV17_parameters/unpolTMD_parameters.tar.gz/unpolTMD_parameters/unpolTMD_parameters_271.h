   double precision :: N1d= 0.22135E+00
   double precision :: N1u= 0.22135E+00
   double precision :: N1s= 0.22135E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.15372E+00
   double precision :: N3fv= 2.03533E-01
   double precision :: N3unfv= 2.03533E-01
   double precision :: N3Ks= 2.03533E-01
   double precision :: N3Ku= 2.03533E-01
   double precision :: be= 0.15492E+01
   double precision :: ga= 0.23266E+01
   double precision :: de= 0.10111E+00
   double precision :: g2= 0.12767E+00
   double precision :: lamF= 0.45813E+01
   double precision :: N4= 3.31525E-02
   double precision :: lam= 0.32032E+01

!  replica 271 (flav_dep 1)