   double precision :: N1d= 0.29381E+00
   double precision :: N1u= 0.29381E+00
   double precision :: N1s= 0.29381E+00
   double precision :: al= 0.29494E+01
   double precision :: si= 0.19276E+00
   double precision :: N3fv= 0.83114E+00
   double precision :: N3unfv= 0.83114E+00
   double precision :: N3Ks= 0.83114E+00
   double precision :: N3Ku= 0.83114E+00
   double precision :: be= 0.11850E+01
   double precision :: ga= 0.20349E+01
   double precision :: de= 0.15599E+00
   double precision :: g2= 0.12555E+00
   double precision :: lamF= 0.57495E+01
   double precision :: N4= 0.13085E+00
   double precision :: lam= 0.44365E+00

!  replica 65 (flav_dep 1)