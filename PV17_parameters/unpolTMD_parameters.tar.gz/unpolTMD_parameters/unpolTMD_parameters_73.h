   double precision :: N1d= 0.26260E+00
   double precision :: N1u= 0.26260E+00
   double precision :: N1s= 0.26260E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.17572E+00
   double precision :: N3fv= 2.21287E-01
   double precision :: N3unfv= 2.21287E-01
   double precision :: N3Ks= 2.21287E-01
   double precision :: N3Ku= 2.21287E-01
   double precision :: be= 0.23284E+01
   double precision :: ga= 0.28273E+01
   double precision :: de= 0.55411E-01
   double precision :: g2= 0.12754E+00
   double precision :: lamF= 0.46330E+01
   double precision :: N4= 3.53925E-02
   double precision :: lam= 0.23123E+00

!  replica 73 (flav_dep 1)