   double precision :: N1d= 0.26962E+00
   double precision :: N1u= 0.26962E+00
   double precision :: N1s= 0.26962E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.17681E+00
   double precision :: N3fv= 0.81062E+00
   double precision :: N3unfv= 0.81062E+00
   double precision :: N3Ks= 0.81062E+00
   double precision :: N3Ku= 0.81062E+00
   double precision :: be= 0.17474E+01
   double precision :: ga= 0.26127E+01
   double precision :: de= 0.11096E+00
   double precision :: g2= 0.12937E+00
   double precision :: lamF= 0.65782E+01
   double precision :: N4= 0.12599E+00
   double precision :: lam= 0.13110E+01

!  replica 72 (flav_dep 1)