   double precision :: N1d= 0.27367E+00
   double precision :: N1u= 0.27367E+00
   double precision :: N1s= 0.27367E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.14488E+00
   double precision :: N3fv= 2.04588E-01
   double precision :: N3unfv= 2.04588E-01
   double precision :: N3Ks= 2.04588E-01
   double precision :: N3Ku= 2.04588E-01
   double precision :: be= 0.25072E+01
   double precision :: ga= 0.30188E+01
   double precision :: de= 0.44652E-01
   double precision :: g2= 0.13135E+00
   double precision :: lamF= 0.35461E+01
   double precision :: N4= 3.44750E-02
   double precision :: lam= 0.45156E+00

!  replica 161 (flav_dep 1)