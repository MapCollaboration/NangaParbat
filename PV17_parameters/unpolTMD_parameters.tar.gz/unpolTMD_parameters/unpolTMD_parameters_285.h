   double precision :: N1d= 0.99331E-01
   double precision :: N1u= 0.99331E-01
   double precision :: N1s= 0.99331E-01
   double precision :: al= 0.90071E+00
   double precision :: si= 0.84838E-01
   double precision :: N3fv= 2.43715E-01
   double precision :: N3unfv= 2.43715E-01
   double precision :: N3Ks= 2.43715E-01
   double precision :: N3Ku= 2.43715E-01
   double precision :: be= 0.15547E+01
   double precision :: ga= 0.16665E+01
   double precision :: de= 0.14126E+00
   double precision :: g2= 0.13693E+00
   double precision :: lamF= 0.37496E+01
   double precision :: N4= 3.93325E-02
   double precision :: lam= 0.19582E+02

!  replica 285 (flav_dep 1)