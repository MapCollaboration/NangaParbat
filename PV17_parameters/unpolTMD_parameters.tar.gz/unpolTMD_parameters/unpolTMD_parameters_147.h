   double precision :: N1d= 0.38129E+00
   double precision :: N1u= 0.38129E+00
   double precision :: N1s= 0.38129E+00
   double precision :: al= 0.29875E+01
   double precision :: si= 0.15376E+00
   double precision :: N3fv= 1.97673E-01
   double precision :: N3unfv= 1.97673E-01
   double precision :: N3Ks= 1.97673E-01
   double precision :: N3Ku= 1.97673E-01
   double precision :: be= 0.21125E+01
   double precision :: ga= 0.25514E+01
   double precision :: de= 0.22367E+00
   double precision :: g2= 0.12184E+00
   double precision :: lamF= 0.10136E+02
   double precision :: N4= 2.62400E-02
   double precision :: lam= 0.95988E-01

!  replica 147 (flav_dep 1)