   double precision :: N1d= 0.18989E+00
   double precision :: N1u= 0.18989E+00
   double precision :: N1s= 0.18989E+00
   double precision :: al= 0.29871E+01
   double precision :: si= 0.21574E+00
   double precision :: N3fv= 0.89682E+00
   double precision :: N3unfv= 0.89682E+00
   double precision :: N3Ks= 0.89682E+00
   double precision :: N3Ku= 0.89682E+00
   double precision :: be= 0.80699E+00
   double precision :: ga= 0.14833E+01
   double precision :: de= 0.71640E-01
   double precision :: g2= 0.11927E+00
   double precision :: lamF= 0.37205E+01
   double precision :: N4= 0.15447E+00
   double precision :: lam= 0.40892E+01

!  replica 205 (flav_dep 1)