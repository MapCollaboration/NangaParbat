   double precision :: N1d= 0.29396E+00
   double precision :: N1u= 0.29396E+00
   double precision :: N1s= 0.29396E+00
   double precision :: al= 0.29859E+01
   double precision :: si= 0.16957E+00
   double precision :: N3fv= 0.86899E+00
   double precision :: N3unfv= 0.86899E+00
   double precision :: N3Ks= 0.86899E+00
   double precision :: N3Ku= 0.86899E+00
   double precision :: be= 0.22945E+01
   double precision :: ga= 0.24976E+01
   double precision :: de= 0.82847E-01
   double precision :: g2= 0.12218E+00
   double precision :: lamF= 0.46148E+01
   double precision :: N4= 0.14195E+00
   double precision :: lam= 0.22416E+00

!  replica 127 (flav_dep 1)