   double precision :: N1d= 0.28516E+00
   double precision :: N1u= 0.28516E+00
   double precision :: N1s= 0.28516E+00
   double precision :: al= 0.29755E+01
   double precision :: si= 0.17293E+00
   double precision :: N3fv= 2.12062E-01
   double precision :: N3unfv= 2.12062E-01
   double precision :: N3Ks= 2.12062E-01
   double precision :: N3Ku= 2.12062E-01
   double precision :: be= 0.21012E+01
   double precision :: ga= 0.25246E+01
   double precision :: de= 0.93554E-01
   double precision :: g2= 0.12840E+00
   double precision :: lamF= 0.52915E+01
   double precision :: N4= 3.37975E-02
   double precision :: lam= 0.39432E+00

!  replica 105 (flav_dep 1)
