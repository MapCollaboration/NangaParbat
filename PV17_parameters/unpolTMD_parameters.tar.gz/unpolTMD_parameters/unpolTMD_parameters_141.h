   double precision :: N1d= 0.24988E+00
   double precision :: N1u= 0.24988E+00
   double precision :: N1s= 0.24988E+00
   double precision :: al= 0.24308E+01
   double precision :: si= 0.10048E+00
   double precision :: N3fv= 0.86006E+00
   double precision :: N3unfv= 0.86006E+00
   double precision :: N3Ks= 0.86006E+00
   double precision :: N3Ku= 0.86006E+00
   double precision :: be= 0.16600E+01
   double precision :: ga= 0.23209E+01
   double precision :: de= 0.91235E-01
   double precision :: g2= 0.13045E+00
   double precision :: lamF= 0.45766E+01
   double precision :: N4= 0.14147E+00
   double precision :: lam= 0.41352E+00

!  replica 141 (flav_dep 1)