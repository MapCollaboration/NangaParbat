   double precision :: N1d= 0.14992E+00
   double precision :: N1u= 0.14992E+00
   double precision :: N1s= 0.14992E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.19151E+00
   double precision :: N3fv= 2.32052E-01
   double precision :: N3unfv= 2.32052E-01
   double precision :: N3Ks= 2.32052E-01
   double precision :: N3Ku= 2.32052E-01
   double precision :: be= 0.28066E+01
   double precision :: ga= 0.29338E+01
   double precision :: de= 0.42619E-01
   double precision :: g2= 0.12972E+00
   double precision :: lamF= 0.42012E+01
   double precision :: N4= 3.73325E-02
   double precision :: lam= 0.97080E+01

!  replica 244 (flav_dep 1)