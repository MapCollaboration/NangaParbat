   double precision :: N1d= 0.35243E+00
   double precision :: N1u= 0.35243E+00
   double precision :: N1s= 0.35243E+00
   double precision :: al= 0.30000E+01
   double precision :: si= 0.15904E+00
   double precision :: N3fv= 0.73679E+00
   double precision :: N3unfv= 0.73679E+00
   double precision :: N3Ks= 0.73679E+00
   double precision :: N3Ku= 0.73679E+00
   double precision :: be= 0.82026E+00
   double precision :: ga= 0.24819E+01
   double precision :: de= 0.21100E-01
   double precision :: g2= 0.12550E+00
   double precision :: lamF= 0.74316E+01
   double precision :: N4= 0.11059E+00
   double precision :: lam= 0.46113E+00

!  replica 219 (flav_dep 1)