   double precision :: N1d= 0.31201E+00
   double precision :: N1u= 0.31201E+00
   double precision :: N1s= 0.31201E+00
   double precision :: al= 0.29495E+01
   double precision :: si= 0.14053E+00
   double precision :: N3fv= 1.96492E-01
   double precision :: N3unfv= 1.96492E-01
   double precision :: N3Ks= 1.96492E-01
   double precision :: N3Ku= 1.96492E-01
   double precision :: be= 0.17995E+01
   double precision :: ga= 0.27077E+01
   double precision :: de= 0.88605E-01
   double precision :: g2= 0.13036E+00
   double precision :: lamF= 0.57293E+01
   double precision :: N4= 3.12825E-02
   double precision :: lam= 0.49034E+00

!  replica 237 (flav_dep 1)